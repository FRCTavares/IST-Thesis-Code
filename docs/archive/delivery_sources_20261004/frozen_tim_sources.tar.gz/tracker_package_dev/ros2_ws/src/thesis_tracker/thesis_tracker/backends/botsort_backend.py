"""BoT-SORT backend for the local tracker interface (campaign 3 October 2026; default off, only used when tracker_type 'botsort' is requested).

Implementation: Ultralytics 8.3.227 `BOTSORT` (BoT-SORT: Aharon et al., 2022: ByteTrack-style association, Kalman filter with width/height state, camera-motion compensation by
sparse optical flow `gmc_method: sparseOptFlow`; appearance re-identification disabled, `with_reid: False`, as in the Ultralytics default configuration). Parameters are the Ultralytics defaults,
unchanged and not tuned: track_high_thresh 0.25, track_low_thresh 0.1, new_track_thresh 0.25, track_buffer 30, match_thresh 0.8, fuse_score True, gmc_method sparseOptFlow,
proximity_thresh 0.5, appearance_thresh 0.8, with_reid False; frame_rate 30 (frame-based buffer, like the other local trackers).
Dependency handling without installation: the Ultralytics tracker utilities import the optional `lap` package, which is not installed on the Pi and must not be installed for this campaign. A stub `lap`
module is registered in memory only so that the import succeeds, and the Ultralytics assignment helper is switched to its own documented SciPy branch (`use_lap=False`, scipy.optimize.linear_sum_assignment with
the same cost threshold). Ultralytics auto-install is disabled (YOLO_AUTOINSTALL=False). Assignments can differ from LAPJV only in exactly tied costs.
Interface: update(dets_xyxy, scores, frame_time_ns) -> list[TrackOutput]; update_latest_image(Image msg) buffers the BGR source image used by the camera-motion estimator (matched by stamp,
else the latest buffered image no older than `max_image_age_ms`).
"""
from __future__ import annotations

import functools
import os
import sys
import types
from collections import OrderedDict
from typing import List, Optional

import numpy as np

from . import BBox, TrackOutput

os.environ.setdefault("YOLO_AUTOINSTALL", "False")
_ULTRALYTICS_VERSION = None


def _load_botsort():
    global _ULTRALYTICS_VERSION
    if "lap" not in sys.modules:
        stub = types.ModuleType("lap")
        stub.__version__ = "0.5.12"

        def _lapjv(*_a, **_k):
            raise RuntimeError("lap stub: the SciPy assignment branch must be used")

        stub.lapjv = _lapjv
        sys.modules["lap"] = stub
    from ultralytics.trackers.bot_sort import BOTSORT, BOTrack
    from ultralytics.trackers.utils import matching
    from ultralytics.utils import IterableSimpleNamespace
    import ultralytics

    _ULTRALYTICS_VERSION = ultralytics.__version__
    if not getattr(matching.linear_assignment, "_campaign_scipy", False):
        patched = functools.partial(matching.linear_assignment, use_lap=False)
        patched._campaign_scipy = True
        matching.linear_assignment = patched
    return BOTSORT, BOTrack, IterableSimpleNamespace


class _Dets:
    """Minimal Ultralytics Boxes-like container (xywh centre format, confidence, class)."""

    def __init__(self, xyxy: np.ndarray, conf: np.ndarray):
        self.conf = conf.astype(np.float32)
        self.cls = np.zeros(len(conf), dtype=np.float32)
        w = xyxy[:, 2] - xyxy[:, 0]
        h = xyxy[:, 3] - xyxy[:, 1]
        self.xywh = np.stack([xyxy[:, 0] + w / 2.0, xyxy[:, 1] + h / 2.0, w, h], axis=1).astype(np.float32)
        self.xyxy = xyxy.astype(np.float32)

    def __len__(self):
        return len(self.conf)

    def __getitem__(self, idx):
        out = _Dets.__new__(_Dets)
        out.conf, out.cls, out.xywh, out.xyxy = self.conf[idx], self.cls[idx], self.xywh[idx], self.xyxy[idx]
        return out


DEFAULTS = dict(tracker_type="botsort", track_high_thresh=0.25, track_low_thresh=0.1, new_track_thresh=0.25, track_buffer=30, match_thresh=0.8, fuse_score=True,
                gmc_method="sparseOptFlow", proximity_thresh=0.5, appearance_thresh=0.8, with_reid=False, model="auto")


class BotSortBackend:
    def __init__(self, frame_rate: int = 30, image_buffer_size: int = 64, max_image_age_ms: float = 250.0, **overrides):
        self._BOTSORT, self._BOTrack, self._NS = _load_botsort()
        self._cfg = {**DEFAULTS, **overrides}
        self._frame_rate = int(frame_rate)
        self._images: "OrderedDict[int, np.ndarray]" = OrderedDict()
        self._image_buffer_size = int(image_buffer_size)
        self._max_image_age_ns = int(float(max_image_age_ms) * 1e6)
        self._tracker = None
        self.reset()

    @property
    def config(self) -> dict:
        return dict(self._cfg, frame_rate=self._frame_rate, ultralytics_version=_ULTRALYTICS_VERSION)

    def reset(self) -> None:
        self._tracker = self._BOTSORT(self._NS(**self._cfg), frame_rate=self._frame_rate)
        self._tracker.reset()
        self._BOTrack.reset_id()
        self._images.clear()

    def update_latest_image(self, image_msg) -> None:
        enc = str(image_msg.encoding).lower()
        if enc not in ("bgr8", "rgb8"):
            return
        h, w = int(image_msg.height), int(image_msg.width)
        if h <= 0 or w <= 0 or int(image_msg.step) != w * 3 or len(image_msg.data) != h * w * 3:
            return
        img = np.frombuffer(image_msg.data, dtype=np.uint8).reshape(h, w, 3)
        if enc == "rgb8":
            img = img[:, :, ::-1]
        stamp = int(image_msg.header.stamp.sec) * 1_000_000_000 + int(image_msg.header.stamp.nanosec)
        self._images[stamp] = np.ascontiguousarray(img)
        while len(self._images) > self._image_buffer_size:
            self._images.popitem(last=False)

    def _image_for(self, stamp_ns: int) -> Optional[np.ndarray]:
        if stamp_ns in self._images:
            return self._images[stamp_ns]
        older = [s for s in self._images if 0 <= stamp_ns - s <= self._max_image_age_ns]
        return self._images[max(older)] if older else None

    def update(self, dets_xyxy: List[BBox], scores: List[float], frame_time_ns: int) -> List[TrackOutput]:
        xyxy = np.asarray(dets_xyxy, dtype=np.float64).reshape(-1, 4)
        conf = np.asarray(scores, dtype=np.float64).reshape(-1)
        img = self._image_for(int(frame_time_ns))
        if img is None:
            img = np.zeros((2, 2, 3), dtype=np.uint8)     # no causal image: the camera-motion estimator sees a blank frame (identity motion)
        tracks = self._tracker.update(_Dets(xyxy, conf), img)
        out: List[TrackOutput] = []
        for row in tracks:
            x1, y1, x2, y2, tid, score = (float(row[0]), float(row[1]), float(row[2]), float(row[3]), int(row[4]), float(row[5]))
            if x2 > x1 and y2 > y1 and tid > 0:
                out.append(TrackOutput(track_id=tid, bbox_xyxy=(x1, y1, x2, y2), score=score))
        return out
