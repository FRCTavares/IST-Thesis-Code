#!/usr/bin/env python3
"""Bounded join of TIM-MARS target messages with their status messages (pure Python, injected clock).

TIM publishes the controller-facing target and, separately, a status JSON (state, reason, selection
generation and session). Either may arrive first; async ReID re-publishes augmented status for a frame; a
clear publishes a frame-less reset target; messages from a previous selection can arrive late. The bridge may
only make a decision for a frame when both halves are present and belong to the same authority epoch.

Rules
  * Join key: frame_id, and the source stamp when both messages carry one (a mismatch never joins).
  * Epoch = (selection_session_id, selection_generation). A status that starts a new epoch, or reports
    NO_TARGET/revoked, produces an immediate `revocation` event (before any join) and drops every pending
    target of the old epoch. A status from an OLDER epoch is discarded as `stale_epoch`.
  * A reset target (frame_id 0, src stamp 0) is an immediate `revocation`.
  * Pending targets expire after `expiry_ns` and are reported as `expired` (the caller fails closed).
  * Targets older than the newest joined/seen frame stamp are dropped as `out_of_order`.
  * Duplicate statuses for a frame are idempotent: the first complete join wins; later statuses are only
    inspected for epoch changes and revocation.
  * Buffers are bounded.
"""
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, List, Optional

REVOKED_REASON_PREFIXES = ("no_operator_selected_target", "operator_clear", "operator_select", "selection_reset",
                           "authority_revoked")


@dataclass(frozen=True)
class StatusRecord:
    frame_id: int
    stamp_ns: int
    generation: int
    session_id: str
    state: str
    reason: str
    payload: Any = None


@dataclass(frozen=True)
class TargetRecord:
    frame_id: int
    stamp_ns: int
    payload: Any
    arrived_ns: int
    is_reset: bool = False


@dataclass(frozen=True)
class JoinEvent:
    kind: str                       # join | expired | revocation | discard
    code: str
    target: Optional[TargetRecord] = None
    status: Optional[StatusRecord] = None


def revokes(status: StatusRecord) -> bool:
    return status.state == "NO_TARGET" or (status.reason or "").startswith(REVOKED_REASON_PREFIXES)


class FrameJoiner:
    def __init__(self, expiry_ns: int = 100_000_000, max_pending: int = 64, max_statuses: int = 64):
        self.expiry_ns = int(expiry_ns)
        self.max_pending = int(max_pending)
        self.max_statuses = int(max_statuses)
        self.session = None
        self.generation = None
        self.seen_sessions = []
        self.revoked_active = False
        self.pending: "OrderedDict[int, TargetRecord]" = OrderedDict()
        self.statuses: "OrderedDict[int, tuple]" = OrderedDict()      # frame_id -> (StatusRecord, arrived_ns)
        self.joined_frames: "OrderedDict[int, bool]" = OrderedDict()
        self.newest_stamp = 0
        self.counters = {"joined": 0, "expired": 0, "revocation": 0, "stale_epoch": 0, "out_of_order": 0,
                         "stamp_mismatch": 0, "dropped_pending_epoch_change": 0, "duplicate_status": 0}

    # -------------------------------------------------------------------------------- helpers
    def _match(self, target: TargetRecord, status: StatusRecord) -> bool:
        if target.frame_id != status.frame_id:
            return False
        if target.stamp_ns > 0 and status.stamp_ns > 0 and target.stamp_ns != status.stamp_ns:
            self.counters["stamp_mismatch"] += 1
            return False
        return True

    def _new_epoch(self, status: StatusRecord) -> bool:
        if self.session is None:
            return False
        if status.session_id != self.session:
            return status.session_id not in self.seen_sessions        # an already-seen older session is stale, not new
        return status.generation > (self.generation or 0)

    def _epoch_events(self, status: StatusRecord) -> Optional[List[JoinEvent]]:
        """Handle epoch/revocation semantics. Returns None when the status is stale and must be discarded."""
        events: List[JoinEvent] = []
        if self.session is None:
            self.session, self.generation = status.session_id, status.generation
            self.seen_sessions.append(status.session_id)
        elif (status.session_id == self.session and status.generation < (self.generation or 0)) or (
                status.session_id != self.session and status.session_id in self.seen_sessions):
            self.counters["stale_epoch"] += 1
            return None
        elif self._new_epoch(status):
            self.counters["revocation"] += 1
            events.append(JoinEvent("revocation", "epoch_changed", status=status))
            for t in list(self.pending.values()):
                self.counters["dropped_pending_epoch_change"] += 1
                events.append(JoinEvent("discard", "pending_target_of_previous_epoch", target=t))
            self.pending.clear()
            self.statuses.clear()
            self.joined_frames.clear()
            self.session, self.generation = status.session_id, status.generation
            if status.session_id not in self.seen_sessions:
                self.seen_sessions.append(status.session_id)
                del self.seen_sessions[:-16]
        self.newest_stamp = max(self.newest_stamp, status.stamp_ns)
        if any(e.kind == "revocation" for e in events):
            self.revoked_active = revokes(status)
        elif revokes(status):
            if not self.revoked_active:                    # one revocation per revoked episode, not one per status
                self.revoked_active = True
                self.counters["revocation"] += 1
                events.append(JoinEvent("revocation", "status_revokes", status=status))
        else:
            self.revoked_active = False
        return events

    # -------------------------------------------------------------------------------- inputs
    def on_target(self, target: TargetRecord, now_ns: int) -> List[JoinEvent]:
        if target.is_reset or (target.frame_id == 0 and target.stamp_ns == 0):
            self.counters["revocation"] += 1
            self.pending.clear()
            self.revoked_active = True
            return [JoinEvent("revocation", "target_reset_message", target=target)]
        if target.stamp_ns > 0 and target.stamp_ns < self.newest_stamp:
            self.counters["out_of_order"] += 1
            return [JoinEvent("discard", "out_of_order", target=target)]
        got = self.statuses.pop(target.frame_id, None)
        if got is not None and self._match(target, got[0]):
            return self._complete(target, got[0])
        if got is not None:
            self.statuses[target.frame_id] = got
        self.pending[target.frame_id] = target
        while len(self.pending) > self.max_pending:
            _, old = self.pending.popitem(last=False)
            self.counters["expired"] += 1
            return [JoinEvent("expired", "pending_overflow", target=old)]
        return []

    def on_status(self, status: StatusRecord, now_ns: int) -> List[JoinEvent]:
        events = self._epoch_events(status)
        if events is None:
            return [JoinEvent("discard", "stale_epoch", status=status)]
        if status.frame_id in self.joined_frames:
            self.counters["duplicate_status"] += 1
            return events
        target = self.pending.get(status.frame_id)
        if target is not None and self._match(target, status):
            self.pending.pop(status.frame_id)
            return events + self._complete(target, status)
        self.statuses[status.frame_id] = (status, now_ns)
        while len(self.statuses) > self.max_statuses:
            self.statuses.popitem(last=False)
        return events

    def expire(self, now_ns: int) -> List[JoinEvent]:
        events: List[JoinEvent] = []
        for fid, t in list(self.pending.items()):
            if now_ns - t.arrived_ns >= self.expiry_ns:
                self.pending.pop(fid)
                self.counters["expired"] += 1
                events.append(JoinEvent("expired", "status_missing", target=t))
        for fid, (_, arrived) in list(self.statuses.items()):
            if now_ns - arrived >= 4 * self.expiry_ns:
                self.statuses.pop(fid)
        return events

    def _complete(self, target: TargetRecord, status: StatusRecord) -> List[JoinEvent]:
        self.counters["joined"] += 1
        self.joined_frames[target.frame_id] = True
        while len(self.joined_frames) > 256:
            self.joined_frames.popitem(last=False)
        self.newest_stamp = max(self.newest_stamp, target.stamp_ns)
        return [JoinEvent("join", "joined", target=target, status=status)]
