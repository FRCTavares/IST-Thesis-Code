#!/usr/bin/env python3
"""Development-only ROS 2 node: visual-track bridge behind TIM-MARS (not part of any launch file).

Subscribes to /camera/image_raw (latest image only), /tracks and /target_memory_mars. For every TIM
target message it looks up the cached image whose source timestamp equals the message's src_stamp_ns
(mismatches are counted, never guessed), and publishes the controller-facing stream on
/target_bridged:
  * TIM output when it is control-valid (id > 0);
  * otherwise the visual-track bridge box, ONLY when the authority contract
    (visual_track_bridge_authority.py) permits it: ordinary detection loss, same selection generation,
    fresh authority, continuous evidence, no candidate at the predicted location and no just-rejected
    candidate nearby. TIM's status JSON (/target_memory_mars/status) supplies state, reason, generation and
    freshness; any missing evidence (status, tracks or image for the frame's source stamp) fails closed;
  * otherwise a zero target (id 0).
Two latencies are recorded for every output: callback_to_output_ms (host-monotonic, from the perception
callback observing the frame) and source_age_ms (from the frame's source timestamp; schedule-referenced
when the stamps are not on the ROS clock, e.g. a replayed bag).
All published boxes are source-image pixels; the bridge runs on an aspect-preserving copy of at most
`bridge_width` pixels, mapped with the contract ImageTransform. The output keeps the source stamp of the
frame it belongs to and the host-monotonic camera-callback stamp, so end-to-end latency can be measured.
`shadow_always` runs the bridge on every frame regardless of TIM validity (worst-case CPU load test).
Per-frame records go to --log (JSON lines).
"""
import argparse
import json
import sys
import threading
import time
from collections import OrderedDict
from pathlib import Path

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from sensor_msgs.msg import Image
from std_msgs.msg import String
from std_msgs.msg import Empty, UInt32
from thesis_msgs.msg import TargetAuthorityOutput, TargetState, Track2DArray

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parents[1] / "ros2_ws/src/thesis_bringup"))
from visual_track_bridge import StreamingBridge  # noqa: E402
from visual_track_bridge_authority import BridgeAuthority, TimFrame, classify_reason  # noqa: E402
from visual_track_bridge_join import FrameJoiner, StatusRecord, TargetRecord  # noqa: E402
from relink_stage import RelinkStage  # noqa: E402
from thesis_bringup.perception.preprocessing import ImageTransform  # noqa: E402


class BridgeCore:
    """All bridge logic. Embeddable: pass any rclpy Node (e.g. the perception process) and feed frames in-process."""

    def __init__(self, node, a, subscribe_images=True):
        self.node = node
        self.a = a
        self.lock = threading.Lock()
        self.cache = OrderedDict()          # stamp_ns -> (gray_bridge_image, other_boxes_bridge_px)
        self.transform = None
        self.tracks_by_stamp = OrderedDict()   # stamp_ns -> list of (box_src, track_id)
        # `max_age_ms` (default None = unchanged frame-count rule): the 1000 ms time contract of the retained reference (candidate_v1), enforced inside the authority
        self.authority = BridgeAuthority(max_age_frames=a.max_age_frames, period_ns=int(1e9 / a.expected_hz), max_age_ms=getattr(a, "max_age_ms", None))
        # Development, default off: `relink_mode` 'e5' replaces the optical-flow bridge by the causal short-gap relink stage (bridge never starts).
        self.relink_mode = getattr(a, "relink_mode", "off")
        self.relink = RelinkStage(period_ns=int(1e9 / a.expected_hz)) if self.relink_mode == "e5" else None
        self.first_arrival_ns = None
        self.first_stamp_ns = None
        self.image_stamps = []
        self.last_valid = None              # dict(stamp, id, box_src)
        self.bridge = None
        self.bridge_steps = 0
        self.last_valid_stamp = None
        self.records = []
        self.counters = {"tim_valid": 0, "bridged_out": 0, "zero_out": 0, "missing_image": 0, "missing_status": 0, "missing_tracks": 0, "steps": 0, "join_expired": 0, "revocations": 0, "relinked_out": 0}
        image_qos = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT, history=HistoryPolicy.KEEP_LAST, depth=1)
        reliable = QoSProfile(reliability=ReliabilityPolicy.RELIABLE, history=HistoryPolicy.KEEP_LAST, depth=10)
        if subscribe_images:
            node.create_subscription(Image, a.image_topic, self.on_image, image_qos)
        node.create_subscription(Track2DArray, a.tracks_topic, self.on_tracks, reliable)
        node.create_subscription(TargetAuthorityOutput, getattr(a, "authority_topic", "/target_memory_mars/authority"),
                                 self.on_target, reliable)
        node.create_subscription(String, a.status_topic, self.on_status, reliable)
        # Operator deselection/selection revokes the bridge at once, from the operator's own topics, without waiting
        # for TIM to finish the frame it is processing (a TIM callback can take several hundred ms with CPU MARS).
        node.create_subscription(Empty, getattr(a, "clear_topic", "/target_memory_mars/clear"), self.on_clear, reliable)
        node.create_subscription(UInt32, getattr(a, "select_topic", "/target_memory_mars/select"), self.on_select, reliable)
        self.pub = node.create_publisher(TargetAuthorityOutput, a.out_topic, reliable)
        self.joiner = FrameJoiner(expiry_ns=int(a.join_expiry_ms * 1e6))
        node.create_timer(0.02, self._expire_tick)

    # ---------------------------------------------------------------- inputs
    def on_tracks(self, msg):
        stamp = int(msg.src_stamp_ns)
        with self.lock:
            self.tracks_by_stamp[stamp] = [((t.cx - t.w / 2, t.cy - t.h / 2, t.cx + t.w / 2, t.cy + t.h / 2), int(t.id))
                                           for t in msg.tracks]
            while len(self.tracks_by_stamp) > 64:
                self.tracks_by_stamp.popitem(last=False)

    def on_status(self, msg):
        try:
            payload = json.loads(msg.data)
        except ValueError:
            return
        rec = StatusRecord(frame_id=int(payload.get("frame_id", 0)), stamp_ns=int(payload.get("track_timestamp_ns") or 0),
                           generation=int(payload.get("selection_generation", 0)),
                           session_id=str(payload.get("selection_session_id", "")), state=str(payload.get("state", "")),
                           reason=str(payload.get("reason", "")), payload=payload)
        self._handle(self.joiner.on_status(rec, time.monotonic_ns()))

    def _expire_tick(self):
        self._handle(self.joiner.expire(time.monotonic_ns()))

    def _handle(self, events):
        for e in events:
            if e.kind == "join":
                self._decide(e.target.payload, e.status.payload)
            elif e.kind == "expired":
                self.counters["join_expired"] += 1
                self._decide(e.target.payload, None)
            elif e.kind == "revocation":
                self._revoke(e.code)
            elif e.kind == "discard":
                self.counters["join_discard_" + e.code] = self.counters.get("join_discard_" + e.code, 0) + 1

    def _revoke(self, code):
        """Selection reset / deselection / new epoch: revoke at once, never revive the old target."""
        with self.lock:
            self.authority.revoke()
            self.bridge = None
            self.last_valid_stamp = None
            self.counters["revocations"] += 1
            if self.relink is not None:
                self.relink.revoke(code)
        out = TargetAuthorityOutput()
        ot = out.target
        ot.id, ot.cx, ot.cy, ot.w, ot.h, ot.score, ot.quality = 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
        out.authority = TargetAuthorityOutput.AUTHORITY_NONE
        out.evidence_class = TargetAuthorityOutput.EVIDENCE_NONE
        out.evidence_age_ms = -1.0
        out.selection_generation = int(self.joiner.generation or 0)
        out.selection_session_id = str(self.joiner.session or "")
        ot.t_target_cb_start_ns = ot.t_target_cb_end_ns = time.monotonic_ns()
        self.pub.publish(out)
        self.records.append({"kind": "revocation", "code": code, "t_ns": ot.t_target_cb_end_ns})

    def on_clear(self, _msg):
        self._revoke("operator_clear_topic")

    def on_select(self, _msg):
        self._revoke("operator_select_topic")

    def on_image(self, msg):
        h, w = int(msg.height), int(msg.width)
        if msg.encoding not in ("bgr8", "rgb8"):
            return
        img = np.frombuffer(msg.data, dtype=np.uint8).reshape(h, w, 3)
        stamp = int(msg.header.stamp.sec) * 1_000_000_000 + int(msg.header.stamp.nanosec)
        self.feed_frame(stamp, img, rgb=(msg.encoding == "rgb8"))

    def feed_frame(self, stamp_ns, img, rgb=False):
        """Feed one source frame (HxWx3 uint8) with its source stamp. Called by the owner of the frames in-process."""
        t0 = time.perf_counter()
        if self.relink is not None:
            with self.lock:
                arrived = time.monotonic_ns()
                if self.first_arrival_ns is None:
                    self.first_arrival_ns, self.first_stamp_ns = arrived, int(stamp_ns)
                self.image_stamps.append((int(stamp_ns), arrived))
            self.records.append({"kind": "image", "stamp": int(stamp_ns), "prep_ms": 0.0})
            return
        h, w = img.shape[:2]
        bw = min(int(self.a.bridge_width), w)
        bh = int(round(h * bw / w))
        if self.transform is None or (self.transform.source_width, self.transform.source_height) != (w, h):
            self.transform = ImageTransform.direct_resize(w, h, bw, bh)
        small = img if (bw, bh) == (w, h) else cv2.resize(img, (bw, bh), interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(small, cv2.COLOR_RGB2GRAY if rgb else cv2.COLOR_BGR2GRAY)
        stamp = int(stamp_ns)
        arrived = time.monotonic_ns()
        with self.lock:
            if self.first_arrival_ns is None:
                self.first_arrival_ns, self.first_stamp_ns = arrived, stamp
            self.image_stamps.append((stamp, arrived))
            self.cache[stamp] = (gray, None)
            while len(self.cache) > 16:
                self.cache.popitem(last=False)
        self.records.append({"kind": "image", "stamp": stamp, "prep_ms": (time.perf_counter() - t0) * 1000.0})

    # --------------------------------------------------------------- decision
    def _others_bridge_px(self, stamp):
        boxes = self.tracks_by_stamp.get(stamp)
        if boxes is None:
            return None
        return [list(self.transform.source_xyxy_to_inference(b)) for b, _ in boxes]

    def _start_bridge(self, stamp, box_src):
        gray0, _ = self.cache[stamp]
        start = list(self.transform.source_xyxy_to_inference(box_src))
        self.bridge = StreamingBridge(gray0, start, allow_coast=False)

    def on_target(self, wrapped):
        tim = wrapped.target
        is_reset = int(tim.frame_id) == 0 and int(tim.src_stamp_ns) == 0 and int(tim.id) == 0
        rec = TargetRecord(frame_id=int(tim.frame_id), stamp_ns=int(tim.src_stamp_ns), payload=wrapped,
                           arrived_ns=time.monotonic_ns(), is_reset=is_reset)
        self._handle(self.joiner.on_target(rec, rec.arrived_ns))

    def _decide(self, tim_w, status):
        t_cb = time.monotonic_ns()
        tim = tim_w.target
        stamp = int(tim.src_stamp_ns)
        out = TargetAuthorityOutput()
        ot = out.target
        ot.header = tim.header
        ot.frame_id = tim.frame_id
        ot.src_stamp_ns = tim.src_stamp_ns
        ot.t_cam_msg_seen_ns = tim.t_cam_msg_seen_ns
        ot.t_target_cb_start_ns = t_cb
        valid = int(tim.id) > 0 and int(tim_w.authority) == TargetAuthorityOutput.AUTHORITY_TIM
        out.selection_generation = int(tim_w.selection_generation)
        out.selection_session_id = str(tim_w.selection_session_id)
        out.authority = TargetAuthorityOutput.AUTHORITY_NONE
        out.evidence_class = TargetAuthorityOutput.EVIDENCE_NONE
        out.evidence_age_ms = -1.0
        step_ms = 0.0
        decision_code = "tim_authority" if valid else "none"
        reason_class = "control_valid" if valid else ""
        proposal = None
        relink_dec = None
        relink_ms = 0.0
        with self.lock:
            have_image = stamp in self.cache
            tracks = self.tracks_by_stamp.get(stamp)
            evidence_ok = status is not None and have_image and tracks is not None
            if not have_image:
                self.counters["missing_image"] += 1
            if status is None:
                self.counters["missing_status"] += 1
            if tracks is None:
                self.counters["missing_tracks"] += 1
            box_src = None
            if valid:
                box_src = (tim.cx - tim.w / 2, tim.cy - tim.h / 2, tim.cx + tim.w / 2, tim.cy + tim.h / 2)
            state = (status or {}).get("state", "")
            reason = (status or {}).get("reason", "")
            gen = int((status or {}).get("selection_generation", -1)) if status else -1
            fresh = bool((status or {}).get("freshness_is_fresh", True)) if status else False
            cand_boxes = [b for b, _ in (tracks or [])]
            klass = classify_reason(reason, state)
            rejected = []
            best = (status or {}).get("best") or {}
            cid = best.get("track_id", (status or {}).get("candidate_track_id"))
            if klass in ("identity_rejection", "hard_negative_conflict", "pending_confirmation") and cid is not None:
                rejected = [b for b, tid in (tracks or []) if int(tid) == int(cid)]
            frame = TimFrame(stamp_ns=stamp, control_valid=valid, state=state, reason=reason, selection_generation=gen,
                             fresh=fresh, track_id=int(tim.id) if valid else None, box_xyxy=box_src,
                             rejected_candidate_boxes=tuple(rejected))
            if self.relink is not None:
                r0 = time.perf_counter()
                if valid:
                    self.counters["tim_valid"] += 1
                    self.last_valid_stamp = stamp
                relink_dec = self.relink.decide(stamp, valid, box_src, int(tim.id) if valid else None, gen if status else int(tim_w.selection_generation),
                                                str((status or {}).get("selection_session_id", tim_w.selection_session_id)), status,
                                                None if tracks is None else [(int(tid), b) for b, tid in tracks])
                relink_ms = (time.perf_counter() - r0) * 1000.0
                decision_code, reason_class = relink_dec.code, klass
                if relink_dec.relinked:
                    proposal = relink_dec.box
            elif valid and status is None:
                self.authority.reset()          # a valid frame without status can never seed the bridge
                self.bridge = None
            elif valid:
                self.counters["tim_valid"] += 1
                self.authority.observe(frame, cand_boxes, None)
                self.last_valid_stamp = stamp
                if self.a.shadow_always and have_image:
                    if self.bridge is None or self.bridge_steps >= 30:
                        self._start_bridge(stamp, box_src)
                        self.bridge_steps = 0
                    else:
                        r = self.bridge.step(self.cache[stamp][0], self._others_bridge_px(stamp) or [])
                        self.bridge_steps += 1
                        self.counters["steps"] += 1
                        if r is None:
                            self.bridge = None
                else:
                    self.bridge = None
            elif not evidence_ok or not self.authority.can_start() and self.authority.seed_generation is None:
                decision_code = "fail_closed_missing_evidence" if not evidence_ok else "no_seed"
                if not evidence_ok and self.authority.seed_generation is not None:
                    self.authority.reset()
                    self.bridge = None
            else:
                if self.bridge is None and self.authority.can_start() and getattr(self, "last_valid_stamp", None) in self.cache:
                    box0 = self.authority.seed_box
                    if box0 is not None:
                        self._start_bridge(self.last_valid_stamp, box0)
                        for st in [k for k in self.cache if self.last_valid_stamp < k < stamp]:   # causal catch-up
                            if self.bridge is None:
                                break
                            if self.bridge.step(self.cache[st][0], self._others_bridge_px(st) or []) is None:
                                self.bridge = None
                if self.bridge is not None:
                    s0 = time.perf_counter()
                    r = self.bridge.step(self.cache[stamp][0], self._others_bridge_px(stamp))
                    step_ms = (time.perf_counter() - s0) * 1000.0
                    self.counters["steps"] += 1
                    if r is None:
                        self.bridge = None
                    else:
                        proposal = self.transform.inference_xyxy_to_source(tuple(r[0]))
                decision = self.authority.observe(frame, cand_boxes, proposal)
                decision_code, reason_class = decision.code, decision.reason_class
                if decision.terminated:
                    self.bridge = None
                if not decision.allow:
                    proposal = None
        mode = "tim" if valid else "none"
        if valid:
            ot.id, ot.cx, ot.cy, ot.w, ot.h = tim.id, tim.cx, tim.cy, tim.w, tim.h
            ot.score, ot.quality = tim.score, tim.quality
            out.authority = TargetAuthorityOutput.AUTHORITY_TIM
            out.evidence_class = tim_w.evidence_class
            out.evidence_age_ms = tim_w.evidence_age_ms
        elif proposal is not None and relink_dec is not None:
            # lowest non-TIM authority: no new authority value is introduced without a flight-contract decision; the log and evidence class say 'relink'
            out.authority = TargetAuthorityOutput.AUTHORITY_VISUAL_BRIDGE
            out.evidence_class = TargetAuthorityOutput.EVIDENCE_APPEARANCE
            out.evidence_age_ms = float(relink_dec.evidence_age_ms)
            period_ns = 1e9 / float(self.a.expected_hz)
            if self.last_valid_stamp is not None:
                out.bridge_age_frames = max(1, int(round((stamp - self.last_valid_stamp) / period_ns)))
            ot.id = int(relink_dec.track_id)
            ot.cx, ot.cy = (proposal[0] + proposal[2]) / 2, (proposal[1] + proposal[3]) / 2
            ot.w, ot.h = proposal[2] - proposal[0], proposal[3] - proposal[1]
            ot.score, ot.quality = 0.0, 0.0
            mode = "relink"
            self.counters["relinked_out"] += 1
        elif proposal is not None:
            out.authority = TargetAuthorityOutput.AUTHORITY_VISUAL_BRIDGE
            out.evidence_class = TargetAuthorityOutput.EVIDENCE_VISUAL_CONTINUITY
            period_ns = 1e9 / float(self.a.expected_hz)
            if self.last_valid_stamp is not None:
                out.bridge_age_frames = max(1, int(round((stamp - self.last_valid_stamp) / period_ns)))
            ot.id = self.authority.seed_id
            ot.cx, ot.cy = (proposal[0] + proposal[2]) / 2, (proposal[1] + proposal[3]) / 2
            ot.w, ot.h = proposal[2] - proposal[0], proposal[3] - proposal[1]
            ot.score, ot.quality = 0.0, 0.0
            mode = "bridge"
            self.counters["bridged_out"] += 1
        else:
            ot.id, ot.cx, ot.cy, ot.w, ot.h, ot.score, ot.quality = 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
            self.counters["zero_out"] += 1
        ot.t_target_cb_end_ns = time.monotonic_ns()
        self.pub.publish(out)
        done = time.monotonic_ns()
        seen = int(tim.t_cam_msg_seen_ns)
        cb_to_out = (done - seen) / 1e6 if seen > 0 else None
        # source/capture age: ROS-clock based when the stamps are on this node's clock, otherwise referenced to the
        # frame's scheduled capture time (first arrival + stamp offset) -- stated per record
        now_ros = self.node.get_clock().now().nanoseconds
        on_ros_clock = abs(now_ros - stamp) < 3600 * 10**9
        if on_ros_clock:
            source_age, basis = (now_ros - stamp) / 1e6, "ros_clock"
        elif self.first_arrival_ns is not None:
            source_age, basis = (done - (self.first_arrival_ns + (stamp - self.first_stamp_ns))) / 1e6, "schedule_referenced"
        else:
            source_age, basis = None, "unavailable"
        self.records.append({"kind": "target", "stamp": stamp, "frame": int(tim.frame_id), "mode": mode,
                             "decision": decision_code, "reason_class": reason_class, "tim_valid": valid,
                             "image_found": have_image, "step_ms": step_ms, "relink_ms": relink_ms,
                             "relink_evidence_age_ms": None if relink_dec is None or not relink_dec.relinked else relink_dec.evidence_age_ms,
                             "relink_similarity": None if relink_dec is None else relink_dec.similarity,
                             "embedding_age_ms_max": (lambda m: max(m.values()) if m else None)((status or {}).get("appearance_embedding_age_ms_by_track_id") or {}), "node_ms": (done - t_cb) / 1e6,
                             "callback_to_output_ms": cb_to_out, "source_age_ms": source_age, "source_age_basis": basis,
                             "t_done_ns": done})

    def dump(self):
        Path(self.a.log).parent.mkdir(parents=True, exist_ok=True)
        with open(self.a.log, "w") as fh:
            for r in self.records:
                fh.write(json.dumps(r) + "\n")
            uniq = len({st for st, _ in self.image_stamps})
            span = (self.image_stamps[-1][1] - self.image_stamps[0][1]) / 1e9 if len(self.image_stamps) > 1 else 0.0
            fh.write(json.dumps({"kind": "image_input", "unique_stamps": uniq, "callbacks": len(self.image_stamps),
                                 "span_s": span, "unique_hz": (uniq - 1) / span if span > 0 else None}) + "\n")
            fh.write(json.dumps({"kind": "counters", **self.counters}) + "\n")


class BridgeNode(Node):
    """Standalone wrapper (subscribes to an image topic). Prefer feeding BridgeCore in-process: separate-process image
    subscriptions lose frames at 15 Hz VGA (see the replay findings)."""

    def __init__(self, a):
        super().__init__("visual_track_bridge_node")
        self.core = BridgeCore(self, a, subscribe_images=True)

    def dump(self):
        self.core.dump()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image-topic", default="/camera/image_raw")
    ap.add_argument("--tracks-topic", default="/tracks")
    ap.add_argument("--target-topic", default="/target_memory_mars")
    ap.add_argument("--status-topic", default="/target_memory_mars/status")
    ap.add_argument("--out-topic", default="/target_bridged")
    ap.add_argument("--expected-hz", type=float, default=15.0)
    ap.add_argument("--join-expiry-ms", type=float, default=100.0)
    ap.add_argument("--bridge-width", type=int, default=640)
    ap.add_argument("--max-age-frames", type=int, default=30)
    ap.add_argument("--max-age-ms", type=float, default=None)
    ap.add_argument("--shadow-always", action="store_true")
    ap.add_argument("--relink-mode", default="off", choices=["off", "e5"])
    ap.add_argument("--log", required=True)
    a, ros_args = ap.parse_known_args()
    rclpy.init(args=ros_args)
    node = BridgeNode(a)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.dump()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
