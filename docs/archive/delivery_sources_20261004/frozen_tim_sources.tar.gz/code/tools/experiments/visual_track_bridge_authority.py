#!/usr/bin/env python3
"""Authority contract for the visual-track bridge (pure Python, no ROS, no OpenCV).

"TIM-MARS output invalid" alone never authorises the bridge. The bridge is a lower-authority gap filler
for ORDINARY DETECTION LOSS only. It may never undo a safety rejection by TIM-MARS, revive a deselected or
reset target, or publish a person TIM-MARS has just declined.

The bridge may publish a frame only if ALL of the following hold (otherwise it is denied and, in every
denial except 'no_seed', it is TERMINATED for the rest of the loss episode; it can only start again from a
new control-valid TIM-MARS output):

  A1  Seeded: the previous authority for this selection was a control-valid TIM-MARS output.
  A2  Same authority epoch: TIM's selection_generation equals the generation of the seeding output, TIM's
      state is not NO_TARGET, and the reason is not an operator select/clear/reset. Deselection, a new
      selection or a reset ends the bridge at once and the old target is never revived.
  A3  Fresh authority: TIM's freshness flag is not stale.
  A4  Continuous evidence: source stamps strictly increase and the gap between consecutive frames is at
      most `max_stamp_gap_periods` periods.
  A5  Bounded age: at most `max_age_frames` frames since the last control-valid output.
  A6  The bridge itself still has trackable features (coasting is disabled).
  A7  Ordinary loss at the predicted location: no tracker candidate overlaps the bridged box
      (IoU >= overlap_iou, or either box contains the other's centre), and no candidate that TIM has just
      rejected (identity rejection, hard-negative conflict, hijack, appearance gate, ...) lies within
      `rejected_near_heights` box heights of it. Where a candidate stands, TIM-MARS decides.

Reason classes (from TIM's own reason string) are only used for accounting and for A2; permission to
bridge never rests on the reason string alone.
"""
from dataclasses import dataclass, field
from typing import Optional, Sequence

ORDINARY_LOSS = ("no_candidates", "best_below_threshold")
REVOKED_PREFIXES = ("no_operator_selected_target", "operator_clear", "operator_select", "selection_reset",
                    "authority_revoked")
HARD_NEGATIVE_PREFIXES = ("hard_negative_reject", "rank_aware_hard_negative_reject", "risk_hard_negative")
PENDING_PREFIXES = ("recovery_persistence_pending",)
STALE_PREFIXES = ("stale", "freshness", "output_stale")
IDENTITY_REJECTION_PREFIXES = (
    "same_id_hijack_reject", "same_id_fresh_challenge_reject", "same_id_reacquisition_reject",
    "global_identity_recovery_reject", "protected_gallery_reacquisition_reject", "id_switch_recovery_reject",
    "rank_aware_id_switch_recovery_reject", "appearance_conservative_reject", "ambiguous_best_candidate",
    "short_gap_new_id_suppressed", "absence_recovery_reject", "cannot_link_reject", "switch_proximity_reject",
    "nearest_eligible_reject", "birth_continuity_reject", "unanchored_", "probation_", "id_switch_gap_reject",
    "id_switch_local_ambiguity_reject")


def classify_reason(reason: str, state: str = "") -> str:
    text = (reason or "").strip()
    if state == "NO_TARGET" or text.startswith(REVOKED_PREFIXES):
        return "revoked_or_reset"
    if text.startswith(STALE_PREFIXES):
        return "stale_evidence"
    if text.startswith(HARD_NEGATIVE_PREFIXES):
        return "hard_negative_conflict"
    if text.startswith(PENDING_PREFIXES):
        return "pending_confirmation"
    if text.startswith(IDENTITY_REJECTION_PREFIXES):
        return "identity_rejection"
    if text.startswith(ORDINARY_LOSS):
        return "ordinary_loss"
    return "other"


def _iou(a, b):
    x1, y1, x2, y2 = max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3])
    inter = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / union if union > 0 else 0.0


def _contains_centre(outer, inner):
    cx, cy = (inner[0] + inner[2]) / 2, (inner[1] + inner[3]) / 2
    return outer[0] <= cx <= outer[2] and outer[1] <= cy <= outer[3]


@dataclass(frozen=True)
class TimFrame:
    """What TIM-MARS published for one frame (state/reason come from its status payload)."""
    stamp_ns: int
    control_valid: bool
    state: str = ""
    reason: str = ""
    selection_generation: int = 0
    fresh: bool = True
    track_id: Optional[int] = None
    box_xyxy: Optional[Sequence[float]] = None        # TIM's box when control_valid (source pixels)
    rejected_candidate_boxes: Sequence[Sequence[float]] = field(default_factory=tuple)


@dataclass(frozen=True)
class Decision:
    allow: bool
    terminated: bool
    code: str
    reason_class: str
    track_id: Optional[int] = None


class BridgeAuthority:
    def __init__(self, max_age_frames=30, overlap_iou=0.3, rejected_near_heights=1.0, max_stamp_gap_periods=2.5,
                 period_ns=66_666_667, max_age_ms=None):
        # `max_age_ms` (default None = unchanged frame-count rule): the bridge budget as source-stamp time since the last TIM-verified frame,
        # evaluated for the frame being published, inside observe(), before its output exists. When given it REPLACES the frame-count rule.
        self.max_age_ns = None if max_age_ms is None else int(round(float(max_age_ms) * 1_000_000))
        self.max_age = int(max_age_frames)
        self.overlap_iou = float(overlap_iou)
        self.near = float(rejected_near_heights)
        self.max_gap_ns = int(max_stamp_gap_periods * period_ns)
        self.reset()

    def reset(self):
        self.seed_generation = None
        self.seed_id = None
        self.seed_box = None
        self.age = 0
        self.terminated = True
        self.last_stamp = None
        self.verified_stamp = None

    def revoke(self, code: str = "authority_revoked_or_reset") -> Decision:
        """Immediate revocation (selection reset, deselection, new epoch): the old target can never be revived."""
        return self._terminate(code, "revoked_or_reset", clear_seed=True)

    def can_start(self) -> bool:
        return self.seed_generation is not None and not self.terminated

    def _terminate(self, code, reason_class, clear_seed=False):
        self.terminated = True
        if clear_seed:
            self.seed_generation = None
            self.seed_id = None
        return Decision(False, True, code, reason_class, None)

    def observe(self, tim: TimFrame, candidate_boxes: Sequence[Sequence[float]],
                bridged_box: Optional[Sequence[float]]) -> Decision:
        """One call per frame, in order. `bridged_box` is the bridge's proposal in source pixels (or None)."""
        reason_class = classify_reason(tim.reason, tim.state)
        if tim.control_valid:
            self.seed_generation = int(tim.selection_generation)
            self.seed_id = tim.track_id
            self.seed_box = tuple(tim.box_xyxy) if tim.box_xyxy is not None else None
            self.age = 0
            self.terminated = False
            self.last_stamp = int(tim.stamp_ns)
            self.verified_stamp = int(tim.stamp_ns)
            return Decision(False, False, "tim_authority", "control_valid", tim.track_id)
        if self.seed_generation is None:
            return Decision(False, False, "no_seed", reason_class)
        if reason_class == "revoked_or_reset" or int(tim.selection_generation) != self.seed_generation:
            return self._terminate("authority_revoked_or_reset", reason_class, clear_seed=True)
        if self.terminated:
            return Decision(False, True, "terminated", reason_class)
        if not tim.fresh or reason_class == "stale_evidence":
            return self._terminate("stale_authority", reason_class)
        if self.last_stamp is not None:
            gap = int(tim.stamp_ns) - self.last_stamp
            if gap <= 0 or gap > self.max_gap_ns:
                return self._terminate("evidence_discontinuity", reason_class)
        self.last_stamp = int(tim.stamp_ns)
        self.age += 1
        if self.max_age_ns is not None:
            age_ns = int(tim.stamp_ns) - int(self.verified_stamp)
            if age_ns <= 0 or age_ns > self.max_age_ns:
                return self._terminate("age_limit", reason_class)
        elif self.age > self.max_age:
            return self._terminate("age_limit", reason_class)
        if bridged_box is None:
            return self._terminate("bridge_lost_features", reason_class)
        height = max(1.0, bridged_box[3] - bridged_box[1])
        for c in candidate_boxes:
            if _iou(bridged_box, c) >= self.overlap_iou or _contains_centre(bridged_box, c) or _contains_centre(c, bridged_box):
                return self._terminate("candidate_at_predicted_location", reason_class)
        bx, by = (bridged_box[0] + bridged_box[2]) / 2, (bridged_box[1] + bridged_box[3]) / 2
        for r in tim.rejected_candidate_boxes:
            rx, ry = (r[0] + r[2]) / 2, (r[1] + r[3]) / 2
            if ((rx - bx) ** 2 + (ry - by) ** 2) ** 0.5 <= self.near * height:
                return self._terminate("near_rejected_candidate", reason_class)
        return Decision(True, False, "ordinary_loss_gap" if reason_class == "ordinary_loss" else "gap_with_candidates_elsewhere",
                        reason_class, self.seed_id)
