#!/usr/bin/env python3
"""Visual-track bridge: an independent RGB track of one person with background camera-motion compensation.

Pure functions (OpenCV + NumPy only, no benchmark dependencies). While the controller-facing identity
output is silent, the last published box is propagated with sparse Lucas-Kanade optical flow on the
person; the camera motion is estimated by a RANSAC partial-affine fit on features outside all tracked
persons and used only to coast for a short, bounded time when person features are lost.

Causality: the step for frame k reads only images at positions <= k. Boxes are in the pixels of the image
passed in; callers map to and from source pixels with the contract `ImageTransform`
(tim_mars_source_pixels_resize_v1). The bridge never writes appearance memory.
"""
import cv2
import numpy as np

cv2.setNumThreads(1)

MAX_AGE = 60
COAST_MAX = 10
LK = dict(winSize=(21, 21), maxLevel=3,
          criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 20, 0.03))

# name -> (max_age, allow_coast)


def gray(img):
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def box_mask(shape, boxes, pad=4):
    mask = np.full(shape[:2], 255, np.uint8)
    for x1, y1, x2, y2 in boxes:
        mask[max(0, int(y1) - pad):int(y2) + pad, max(0, int(x1) - pad):int(x2) + pad] = 0
    return mask


def person_features(g, box, max_corners=40):
    x1, y1, x2, y2 = box
    w, h = x2 - x1, y2 - y1
    rx1, ry1 = int(x1 + 0.1 * w), int(y1 + 0.05 * h)
    rx2, ry2 = int(x2 - 0.1 * w), int(y1 + 0.75 * h)
    if rx2 - rx1 < 4 or ry2 - ry1 < 4:
        return None
    mask = np.zeros(g.shape, np.uint8)
    mask[max(0, ry1):ry2, max(0, rx1):rx2] = 255
    pts = cv2.goodFeaturesToTrack(g, max_corners, 0.01, 3, mask=mask)
    return None if pts is None or len(pts) < 4 else pts.reshape(-1, 1, 2).astype(np.float32)


def lk_forward_backward(g0, g1, pts, fb_thresh=1.5):
    nxt, st, _ = cv2.calcOpticalFlowPyrLK(g0, g1, pts, None, **LK)
    back, st2, _ = cv2.calcOpticalFlowPyrLK(g1, g0, nxt, None, **LK)
    err = np.linalg.norm((pts - back).reshape(-1, 2), axis=1)
    ok = (st.ravel() == 1) & (st2.ravel() == 1) & (err < fb_thresh)
    return nxt, ok


def camera_motion(g0, g1, exclude_boxes):
    """Partial-affine image motion of the background between two frames (2x3) or None."""
    h, w = g0.shape
    mask = box_mask(g0.shape, exclude_boxes)
    ys, xs = np.mgrid[24:h - 24:40, 24:w - 24:40]
    pts = np.stack([xs.ravel(), ys.ravel()], 1).astype(np.float32)
    keep = mask[pts[:, 1].astype(int), pts[:, 0].astype(int)] > 0
    pts = pts[keep].reshape(-1, 1, 2)
    if len(pts) < 8:
        return None
    nxt, ok = lk_forward_backward(g0, g1, pts)
    if ok.sum() < 8:
        return None
    m, inl = cv2.estimateAffinePartial2D(pts[ok], nxt[ok], method=cv2.RANSAC, ransacReprojThreshold=2.0)
    if m is None or inl is None or inl.sum() < 6:
        return None
    return m


def apply_affine(m, box):
    corners = np.array([[box[0], box[1]], [box[2], box[1]], [box[2], box[3]], [box[0], box[3]]], np.float32)
    out = corners @ m[:, :2].T + m[:, 2]
    return [float(out[:, 0].min()), float(out[:, 1].min()), float(out[:, 0].max()), float(out[:, 1].max())]


def _box_iou(a, b):
    x1, y1, x2, y2 = max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3])
    inter = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / union if union > 0 else 0.0


class StreamingBridge:
    """One person's visual track, advanced one frame at a time (the deployable form).

    Create it from the last frame in which the controller-facing output was backed by a detection and the
    last published box; call `step(gray, other_boxes)` for every following frame. `step` returns
    `(box, mode)` or `None` when the track must end (features lost with coasting disabled, coast budget
    exhausted, camera motion unavailable, or the box left the image). Coasting is off unless requested.
    """

    def __init__(self, gray_start, box0, allow_coast=True, compute_background_motion=None, no_overlap_replenish=False):
        # Background (camera) motion only feeds the coasting prediction. With coasting disabled it cannot
        # change any output, so it is skipped unless a reference run asks for it explicitly.
        self.compute_background_motion = allow_coast if compute_background_motion is None else bool(compute_background_motion)
        self.g_prev = gray_start
        self.h, self.w = gray_start.shape
        self.box = list(box0)
        self.pts = person_features(gray_start, self.box)
        self.n_init = len(self.pts) if self.pts is not None else 0
        self.velocity = np.zeros(2, np.float32)  # target motion relative to the background, pixels/frame
        self.coast_used = 0
        self.allow_coast = allow_coast
        # Identity witness: never replenish this person's features from a crop another person overlaps.
        self.no_overlap_replenish = bool(no_overlap_replenish)

    def step(self, g, other_boxes):
        box = self.box
        m_bg = camera_motion(self.g_prev, g, list(other_boxes) + [box]) if self.compute_background_motion else None
        mode = None
        new_box = None
        if self.pts is not None and self.n_init >= 4:
            nxt, ok = lk_forward_backward(self.g_prev, g, self.pts)
            if ok.sum() >= 4 and ok.sum() >= 0.3 * self.n_init:
                t, inl = cv2.estimateAffinePartial2D(self.pts[ok], nxt[ok], method=cv2.RANSAC, ransacReprojThreshold=2.0)
                scale = 1.0 if t is None else float(np.sqrt(abs(np.linalg.det(t[:, :2]))))
                if t is not None and 0.85 <= scale <= 1.15:
                    new_box = apply_affine(t, box)
                else:
                    d = np.median((nxt[ok] - self.pts[ok]).reshape(-1, 2), axis=0)
                    new_box = [box[0] + d[0], box[1] + d[1], box[2] + d[0], box[3] + d[1]]
                mode = "track"
                if m_bg is not None:
                    c0 = np.array([(box[0] + box[2]) / 2, (box[1] + box[3]) / 2, 1.0])
                    c1 = np.array([(new_box[0] + new_box[2]) / 2, (new_box[1] + new_box[3]) / 2])
                    self.velocity = 0.7 * self.velocity + 0.3 * (c1 - m_bg @ c0)
                self.pts = nxt[ok].reshape(-1, 1, 2)
                overlapped = self.no_overlap_replenish and any(_box_iou(new_box, o) >= 0.1 for o in other_boxes)
                if len(self.pts) < 0.5 * self.n_init and not overlapped:
                    fresh = person_features(g, new_box)
                    if fresh is not None:
                        self.pts = fresh
                        self.n_init = len(self.pts)
        if new_box is None:
            if (not self.allow_coast) or m_bg is None or self.coast_used >= COAST_MAX:
                return None
            c = np.array([(box[0] + box[2]) / 2, (box[1] + box[3]) / 2, 1.0])
            shift = (m_bg @ c) - c[:2] + self.velocity
            new_box = [box[0] + shift[0], box[1] + shift[1], box[2] + shift[0], box[3] + shift[1]]
            self.coast_used += 1
            mode = "coast"
            self.pts = person_features(g, new_box)
            self.n_init = len(self.pts) if self.pts is not None else 0
        cx, cy = (new_box[0] + new_box[2]) / 2, (new_box[1] + new_box[3]) / 2
        if not (0 <= cx < self.w and 0 <= cy < self.h) or new_box[2] - new_box[0] < 4 or new_box[3] - new_box[1] < 8:
            return None
        self.box = new_box
        self.g_prev = g
        return new_box, mode


def simulate_bridge(images, frames, start_pos, box0, other_boxes_for, allow_coast=True, compute_background_motion=None):
    """Batch form used by the offline evaluations: propagate box0 from frame start_pos.

    images: callable(i)->BGR for tracker-frame position i; frames: tracker frames.
    Returns a list of (position, box, mode) with mode in {'track','coast'}; stops at the first failure.
    """
    bridge = StreamingBridge(gray(images(start_pos)), box0, allow_coast=allow_coast,
                             compute_background_motion=compute_background_motion)
    out = []
    for age in range(1, MAX_AGE + 1):
        pos = start_pos + age
        if pos >= len(frames):
            break
        result = bridge.step(gray(images(pos)), other_boxes_for(pos - 1))
        if result is None:
            break
        out.append((pos, result[0], result[1]))
    return out


def bridged_maps(frames, base_boxes, base_ids, runs, max_age, allow_coast):
    boxes = dict(base_boxes)
    ids = dict(base_ids)
    modes = {}
    for run_tid, run in runs:
        for k, (pos, box, mode) in enumerate(run, start=1):
            if k > max_age:
                break
            if mode == "coast" and not allow_coast:
                break
            fi = int(frames[pos]["normalized_frame_index"])
            if boxes.get(fi) is None:
                boxes[fi] = tuple(box)
                ids[fi] = run_tid
                modes[fi] = mode
    return boxes, ids, modes
