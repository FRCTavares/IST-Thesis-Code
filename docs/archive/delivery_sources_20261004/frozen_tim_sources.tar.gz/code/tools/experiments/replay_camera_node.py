#!/usr/bin/env python3
"""Development-only replay of recorded frames through the SAME processing path as the integrated camera.

`PerceptionCameraNode` ingests a V4L2 frame in `_camera_loop` and then runs, in this order: frame -> Image
message (`_frame_to_msg`), `_maybe_publish_dashboard_frame`, `_maybe_publish_fps`, `on_image(msg)` (the shared
perception pipeline: bounded latest-frame queue, preprocessing, Hailo detector, /detections, /timing). This
node subclasses it and replaces ONLY the camera pieces (binary/device checks, sensor configuration, device
open/reopen and the capture loop) so recorded frames enter at exactly that seam. No raw-image topic is
published and `on_image` is called in-process, so there is no raw-image DDS fan-out; the only image topic is
/camera/dashboard, as in the live stack.

Timestamps: every frame keeps its RECORDED inter-frame timing. Published header stamps are the recorded stamps
re-based onto the ROS clock at start (stamp_k = ros_start + (recorded_k - recorded_0)); the mapping from
recorded to published stamps is written to the replay log, so source-timestamp latency is well defined and
TIM's freshness logic (which compares source stamps with the ROS clock) behaves as it would live.

Modes (env REPLAY_MODE):
  paced    chronological playback: frame k is released at its scheduled time. If the pipeline is more than
           REPLAY_DROP_AFTER_S behind the schedule, the frame is skipped and counted as a replay drop (the
           live V4L2 queue would also lose it).
  unpaced  offline processing speed: a frame is released only when the perception queue has caught up, so
           nothing is dropped; this measures capacity, not real-time behaviour.

Config via environment: REPLAY_PLAN (JSON: frames[{path, recorded_stamp_ns}]), REPLAY_MODE, REPLAY_LOG,
REPLAY_START_DELAY_S, REPLAY_DROP_AFTER_S, REPLAY_LOOPS.
"""
import json
import os
import sys
import time
from types import SimpleNamespace

import cv2
import rclpy
from rclpy.executors import ExternalShutdownException

from thesis_bringup.perception.perception_camera_node import PerceptionCameraNode


class ReplayCameraNode(PerceptionCameraNode):
    def __init__(self) -> None:
        plan = json.load(open(os.environ["REPLAY_PLAN"]))
        self._plan = plan["frames"]
        self._mode = os.environ.get("REPLAY_MODE", "paced")
        self._log_path = os.environ["REPLAY_LOG"]
        self._start_delay_s = float(os.environ.get("REPLAY_START_DELAY_S", "8"))
        self._drop_after_s = float(os.environ.get("REPLAY_DROP_AFTER_S", "0.15"))
        self._replay_stamp_ns = 0
        self._replay_records = []
        self._frames_cache = []
        self._bridge_core = None
        super().__init__()
        if os.environ.get("REPLAY_INPROC_BRIDGE") == "1":
            # The bridge lives inside the perception process: it is fed every frame in-process (no image topic
            # subscription, no extra DDS image transport) and talks to TIM only through target/status/tracks.
            from visual_track_bridge_node import BridgeCore
            args = SimpleNamespace(image_topic="", tracks_topic="/tracks", target_topic="/target_memory_mars",
                                   status_topic="/target_memory_mars/status", out_topic="/target_bridged",
                                   bridge_width=int(os.environ.get("REPLAY_BRIDGE_WIDTH", "1344")), max_age_frames=30,
                                   shadow_always=os.environ.get("REPLAY_BRIDGE_SHADOW") == "1", expected_hz=15.0,
                                   join_expiry_ms=100.0, log=os.environ["REPLAY_BRIDGE_LOG"],
                                   relink_mode=os.environ.get("REPLAY_RELINK", "off"),
                                   max_age_ms=(float(os.environ["REPLAY_BRIDGE_MAX_AGE_MS"]) if os.environ.get("REPLAY_BRIDGE_MAX_AGE_MS") else None))
            self._bridge_core = BridgeCore(self, args, subscribe_images=False)

    # ------------------------------------------------------------- camera pieces replaced
    def _check_binaries(self) -> None:
        pass

    def _check_devices(self) -> None:
        pass

    def _configure_camera(self) -> None:
        # Preload every frame so disk reads cannot disturb the playback schedule.
        for item in self._plan:
            frame = cv2.imread(item["path"], cv2.IMREAD_COLOR)
            if frame is None:
                raise RuntimeError(f"unreadable replay frame {item['path']}")
            self._frames_cache.append(frame)
        self.get_logger().info(f"replay: preloaded {len(self._frames_cache)} frames, mode={self._mode}")

    def _open_camera(self) -> None:
        pass

    def _retry_reopen(self) -> None:
        pass

    def _frame_to_msg(self, frame):
        msg = super()._frame_to_msg(frame)
        msg.header.stamp.sec = int(self._replay_stamp_ns // 1_000_000_000)
        msg.header.stamp.nanosec = int(self._replay_stamp_ns % 1_000_000_000)
        return msg

    # --------------------------------------------------------------------- capture loop
    def _camera_loop(self) -> None:
        recorded0 = int(self._plan[0]["recorded_stamp_ns"])
        t_start = time.monotonic() + self._start_delay_s
        ros_start_ns = self.get_clock().now().nanoseconds + int(self._start_delay_s * 1e9)
        stamps = {}
        for k, item in enumerate(self._plan):
            stamps[k] = ros_start_ns + (int(item["recorded_stamp_ns"]) - recorded0)
        with open(self._log_path + ".stamps.json", "w") as fh:
            json.dump({"ros_start_ns": ros_start_ns, "mode": self._mode, "published_stamp_ns": stamps,
                       "recorded_stamp_ns": [int(i["recorded_stamp_ns"]) for i in self._plan]}, fh)
        while time.monotonic() < t_start and not self._camera_stop.is_set():
            self._camera_stop.wait(timeout=0.05)
        done = False
        for k, frame in enumerate(self._frames_cache):
            if self._camera_stop.is_set() or not rclpy.ok():
                break
            sched = t_start + (int(self._plan[k]["recorded_stamp_ns"]) - recorded0) / 1e9
            now = time.monotonic()
            late_s = 0.0
            dropped = False
            if self._mode == "paced":
                if now < sched:
                    self._camera_stop.wait(timeout=sched - now)
                    now = time.monotonic()
                late_s = now - sched
                if late_s > self._drop_after_s:
                    dropped = True
            else:
                # offline speed: wait until at most one frame is in flight in the perception worker
                while (self.frames_received - self.frames_processed - self.frames_overwritten) >= 1 \
                        and not self._camera_stop.is_set():
                    time.sleep(0.0005)
                now = time.monotonic()
            rec = {"k": k, "recorded_stamp_ns": int(self._plan[k]["recorded_stamp_ns"]), "published_stamp_ns": stamps[k],
                   "scheduled_mono_s": sched, "ingest_mono_s": now, "late_ms": late_s * 1000.0, "dropped": dropped}
            if not dropped:
                self._replay_stamp_ns = stamps[k]
                self._last_frame_monotonic = now
                self._camera_frame_id += 1
                msg = self._frame_to_msg(frame)
                self._maybe_publish_dashboard_frame(msg, now_monotonic=time.monotonic())
                self._maybe_publish_fps()
                if self._bridge_core is not None:
                    self._bridge_core.feed_frame(stamps[k], frame)
                self.on_image(msg)
                rec["after_on_image_mono_s"] = time.monotonic()
            self._replay_records.append(rec)
        done = True
        self.get_logger().info(f"replay: finished feeding {len(self._frames_cache)} frames")
        # let the worker drain, then leave the node alive so late publications are recorded
        time.sleep(3.0)
        if self._bridge_core is not None:
            self._bridge_core.dump()
        with open(self._log_path, "w") as fh:
            for r in self._replay_records:
                fh.write(json.dumps(r) + "\n")
            fh.write(json.dumps({"kind": "perception_counters", "frames_received": self.frames_received,
                                 "frames_enqueued": self.frames_enqueued, "frames_overwritten": self.frames_overwritten,
                                 "frames_processed": self.frames_processed, "frames_timeouts": self.frames_timeouts,
                                 "frames_in_plan": len(self._plan), "mode": self._mode}) + "\n")
        os.environ["REPLAY_DONE"] = "1"
        open(self._log_path + ".done", "w").write("done")


def main(args=None) -> None:
    rclpy.init(args=args)
    node = None
    try:
        node = ReplayCameraNode()
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
