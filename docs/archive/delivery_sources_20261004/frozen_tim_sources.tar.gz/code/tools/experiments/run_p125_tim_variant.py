#!/usr/bin/env python3
"""Development-only: score canonical ByteTrack + a TIM-MARS variant on frozen #125 episodes.

Reads frozen inputs from the main Issue #125 checkout (read-only) and writes only
to --output-root. Not part of the frozen benchmark; results are exploratory.
"""
import argparse, copy, json, sys
from dataclasses import replace
from pathlib import Path
DEV=Path(__file__).resolve().parents[2]
MAIN=Path("/home/francisco/Desktop/Thesis-Code")
sys.path.insert(0,str(MAIN/"tools/issues/p125"))
sys.path.insert(0,str(DEV/"tools/analysis")); sys.path.insert(0,str(DEV/"tools/experiments"))
sys.path.insert(0,str(DEV/"ros2_ws/src/thesis_bringup")); sys.path.insert(0,str(DEV/"ros2_ws/src/thesis_tracker"))
import thesis_bringup.tim_mars.types as _dev_types  # bind the dev worktree copy before helpers import the main one
assert str(DEV) in _dev_types.__file__, _dev_types.__file__
from audit_visdrone_selected_person_corpus import load_sequence_rows
from score_raw_tracker_sequence import validate_raw_replay
from shared_detector_cache import read_committed_frozen_inputs
from write_raw_tracker_replay import ARM_CONFIGS, sha256_file
from write_shared_detector_cache import image_paths_by_source_frame
import write_tim_mars_sequence as _wts
from write_tim_mars_sequence import score_tim_mars_episodes
import controller_output_adapter as _coa
from target_reid_episode import track_message as _track_message
TRACE=[]

def _traced_authority_maps(*, tracker_frames, initialization, runtime_factory, image_for_frame):
    indices=[int(f["normalized_frame_index"]) for f in tracker_frames]
    if not initialization.success:
        return _coa.observation_maps((i,_coa.NO_OUTPUT) for i in indices)
    conf=initialization.initialization_frame_index; sid=int(initialization.initial_tracker_identity)
    rt=runtime_factory(sid); obs=[]; rows=[]
    for fr,i in zip(tracker_frames,indices):
        if i<conf: obs.append((i,_coa.NO_OUTPUT)); continue
        rt.add_image(int(fr["logical_frame_stamp_ns"]),image_for_frame(fr))
        res=rt.process_tracks(_track_message(fr)); o=res.output; bs=o.best_score
        rows.append(dict(f=i,state=str(o.state).split(".")[-1],cv=bool(o.control_valid),tid=o.target_track_id,reason=o.reason,
            anchor=o.protected_anchor_available,gal=o.trusted_gallery_size,cand=getattr(bs,"track_id",None),
            app=getattr(bs,"appearance",None),geo=getattr(bs,"geometry_score",None),
            tracks=[(int(t["track_id"]),[round(float(x),1) for x in t["bbox_xyxy"]]) for t in fr["tracks"]]))
        obs.append((i,_coa.from_tim_mars(res)))
    TRACE.append(dict(selected=sid,conf=conf,rows=rows,
        outputs={int(i): ([round(float(v),1) for v in o.bbox_xyxy]+[int(o.tracker_identity)] if o.bbox_xyxy is not None else None) for i,o in obs},
        counters=rt.memory.dev_counters()))
    return _coa.observation_maps(obs)

import cv2
from run_deterministic_tim_replay import build_runtime, load_canonical_parameters
from thesis_bringup.tim_mars.runtime import TimMarsRuntime

_B = {"dev_unanchored_guard": True, "dev_id_switch_gap_crowd_gate": True,
      "dev_id_switch_max_gap_frames": 30, "dev_same_id_resume": True,
      "dev_same_id_resume_max_gap": 30}
_EX = {**_B, "dev_same_id_resume_global_gap_limit": True}
_FX = {**_EX, "dev_cannot_link": True, "dev_cannot_link_trusted_only": True}
_HX = {**_FX, "dev_nearest_eligible": True, "dev_nearest_max_gap": 30}
MAPPED_FIELDS = {
    "id_switch_min_appearance_similarity": 0.78, "appearance_min_similarity": 0.35,
    "appearance_gallery_min_anchor_similarity": 0.75, "hard_negative_min_candidate_similarity": 0.70,
    "hard_negative_max_positive_similarity": 0.95, "hard_negative_reject_similarity": 0.80,
    "appearance_conservative_min_similarity": 0.65, "absence_min_similarity": 0.65,
    "dev_id_switch_min_similarity": 0.85, "dev_same_id_global_min_similarity": 0.60,
    "dev_unanchored_weak_min_similarity": 0.60,
}


class HailoRepVggBackend:
    """Replay-only appearance backend: Hailo RepVGG-A0 512-d embeddings for TIM-MARS."""

    def __init__(self):
        from thesis_bringup.perception.hailo_shared_runtime import HailoSharedRuntime
        from thesis_bringup.tim_mars.repvgg_reid_adapter import (
            REPVGG_OUTPUT_NAME, postprocess_repvgg_embedding, prepare_repvgg_crop, repvgg_batch_tensor)
        self._fns = (REPVGG_OUTPUT_NAME, postprocess_repvgg_embedding, prepare_repvgg_crop, repvgg_batch_tensor)
        self.rt = HailoSharedRuntime(
            detector_hef_path=str(MAIN / "models/hef/yolov8s.hef"), infer_timeout_ms=300,
            reid_hef_path=str(MAIN / "models/reid/repvgg_a0_person_reid_512.hef"))

    def encode(self, image_bgr, boxes_xyxy):
        name, post, prep, tensor = self._fns
        h, w = image_bgr.shape[:2]
        out = []
        for b in boxes_xyxy:
            x1, y1, x2, y2 = max(0, int(b[0])), max(0, int(b[1])), min(w, int(b[2])), min(h, int(b[3]))
            if x2 - x1 < 4 or y2 - y1 < 8:
                out.append(None)
                continue
            raw = self.rt.infer_reid(tensor(prep(image_bgr[y1:y2, x1:x2].copy())))
            out.append(post(raw[name]))
        return out

    def close(self):
        self.rt.close()


VARIANTS = {
    "baseline": {},
    "vA_guard": {"dev_unanchored_guard": True, "dev_id_switch_gap_crowd_gate": True, "dev_id_switch_max_gap_frames": 30},
    "vE_orig_id": dict(_B),
    "vEx_gaplimit": dict(_EX),
    "vFx_cl_trusted": dict(_FX),
    "vHx_nearest": dict(_HX),
    "vFG2x": {**_FX, "dev_switch_proximity": True, "dev_switch_max_dist_heights": 2.0},
    "vHx_ego": {**_HX, "dev_switch_ego_compensation": True},
    "vBW_window30": {**_FX, "dev_backward_window_frames": 30},
    "vBC_birth2": {**_FX, "dev_birth_continuity": True, "dev_birth_max_dist_heights": 2.0, "dev_birth_max_gap_updates": 30},
    "vBCH_birth_nearest": {**_HX, "dev_birth_continuity": True, "dev_birth_max_dist_heights": 2.0, "dev_birth_max_gap_updates": 30},
    "vR_repvgg_FG2x": {**_FX, "dev_switch_proximity": True, "dev_switch_max_dist_heights": 2.0, "__encoder__": "repvgg"},
    "vF_cl": {**_B, "dev_cannot_link": True},
    "vH_nearest": {**_B, "dev_cannot_link": True, "dev_nearest_eligible": True},
    "vFG2": {**_B, "dev_cannot_link": True, "dev_switch_proximity": True, "dev_switch_max_dist_heights": 2.0},
}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--variant",required=True); ap.add_argument("--output-root",type=Path,required=True)
    ap.add_argument("--sequences-file",type=Path,required=True); ap.add_argument("--shard",default="0/1"); ap.add_argument("--trace-dir",type=Path,default=None)
    a=ap.parse_args()
    flags=dict(VARIANTS[a.variant])
    encoder=flags.pop("__encoder__","mars")
    repvgg=None
    if encoder=="repvgg":
        tmap=json.load(open(Path.home()/"tim_vnext_runs/hailo/repvgg_threshold_map.json"))
        flags.update({k: tmap[str(v)] for k,v in MAPPED_FIELDS.items()})
        repvgg=HailoRepVggBackend()
    _wts.tim_mars_authority_maps=_traced_authority_maps
    frozen=read_committed_frozen_inputs(repository_root=MAIN,
        protocol_path=MAIN/"docs/data/external_benchmark_v2/visdrone_selected_person_protocol_v1.json",
        manifest_path=MAIN/"docs/data/external_benchmark_v2/visdrone_gt_only_episode_manifest_v1.json")
    protocol,manifest=frozen["protocol"],frozen["manifest"]
    hashes=protocol["pre_result_implementation_hashes_draft"]
    canonical=load_canonical_parameters(MAIN/"ros2_ws/src/thesis_bringup/config/tim_mars_canonical.yaml")
    si,sn=map(int,a.shard.split("/"))
    todo=[l.split()[:2] for l in open(a.sequences_file) if l.strip()][si::sn]
    for split,seq in todo:
        out=a.output_root/a.variant/split/f"{seq}.json"
        if out.exists(): continue
        entry=[e for e in manifest["sequence_inventory"] if e["split"]==split and e["sequence_name"]==seq][0]
        root=MAIN/"data/datasets/external/visdrone_mot"
        image_paths=image_paths_by_source_frame(root/split/"sequences"/seq); nums=sorted(image_paths)
        cache=MAIN/"artifacts/reports/p125_shared_detector_cache"/split/f"{seq}.json"
        rp=MAIN/"artifacts/reports/p125_raw_tracker_replay/bytetrack_raw"/split/f"{seq}.json"
        frames=validate_raw_replay(json.loads(rp.read_text()),arm="bytetrack_raw",split=split,sequence_name=seq,
            source_frame_numbers=nums,protocol_sha256=frozen["protocol_sha256"],manifest_sha256=frozen["manifest_sha256"],
            freeze_commit=frozen["freeze_commit"],detector_cache_sha256=sha256_file(cache),
            tracker_config_sha256=hashes[ARM_CONFIGS["bytetrack_raw"]])
        rows=load_sequence_rows(split=split,sequence_name=seq,annotation_path=root/split/"annotations"/f"{seq}.txt",
            image_width=int(entry["image_width"]),image_height=int(entry["image_height"]))
        base=build_runtime(canonical,argparse.Namespace(appearance_enabled=None,appearance_request_policy=None,
            appearance_compute_min_interval_ms=None,image_width=float(entry["image_width"]),image_height=float(entry["image_height"]),
            tracks_are_normalized=False,selected_track_id=0,model=MAIN/"models/reid/mars-small128.pb"))
        if repvgg is not None: base.mars_backend=repvgg
        def factory(sid,base=base):
            mem=replace(copy.deepcopy(base.config.memory),**flags)
            return TimMarsRuntime(config=replace(base.config,memory=mem,selected_track_id=sid),mars_backend=base.mars_backend)
        def img(fr,entry=entry,image_paths=image_paths):
            im=cv2.imread(str(image_paths[int(fr["source_frame_number"])]),cv2.IMREAD_COLOR)
            assert im is not None; return im
        eps=[e for e in manifest["episodes"] if e["split"]==split and e["sequence_name"]==seq]
        TRACE.clear()
        res=score_tim_mars_episodes(split=split,sequence_name=seq,episodes=eps,gt_rows=rows,tracker_frames=frames,
            initialization_rules=protocol["initialization_draft"],evaluation_rules=protocol["evaluation_draft"],
            runtime_factory=factory,image_for_frame=img)
        if a.trace_dir:
            a.trace_dir.mkdir(parents=True,exist_ok=True); (a.trace_dir/f"{seq}.json").write_text(json.dumps(TRACE))
        out.parent.mkdir(parents=True,exist_ok=True)
        k=0
        for r in res:
            if r["initialization"]["success"]:
                r["dev"]={"outputs":TRACE[k]["outputs"],"counters":TRACE[k]["counters"],"selected_id":TRACE[k]["selected"]}
                k+=1
        assert k==len(TRACE)
        out.write_text(json.dumps({"variant":a.variant,"flags":flags,"split":split,"sequence_name":seq,"episodes":res}))
        print("done",a.variant,seq,flush=True)
if __name__ == "__main__":
    main()
