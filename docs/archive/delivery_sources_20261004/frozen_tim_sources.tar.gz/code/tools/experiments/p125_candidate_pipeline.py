#!/usr/bin/env python3
"""Development-only candidate pipeline for the selected-person benchmark episodes.

One deterministic function chain used on development data and, unchanged, for the independent
test-dev confirmation:

  shared ByteTrack tracks -> TIM-MARS (default-off development guards, optional Hailo RepVGG encoder)
  -> visual-track bridge (sparse optical flow with background camera-motion compensation; coasting
  disabled unless explicitly requested) -> controller-facing output stream per episode.

The stream is produced for every source frame from the confirmation frame to the last target
observation plus a tail (`--tail-frames`, default 90) so that output after the target has left the
scene (target-absent output) can be measured. Scoring frames and rules are the frozen Issue #125
scorer, unchanged; the tail only adds a separate count.

Arms: tim_canonical (canonical TIM-MARS, no bridge), tim_fg2x (guards only), candidate (guards + bridge),
candidate_repvgg (same with Hailo RepVGG as the appearance encoder, thresholds mapped by equal FPR).
"""
import argparse
import copy
import json
import os
import sys
import time
from dataclasses import asdict, replace
from pathlib import Path

import cv2
import numpy as np

cv2.setNumThreads(1)
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import run_p125_tim_variant as rv  # noqa: E402  (binds the development worktree thesis_bringup first)
import run_p125_flow_bridge_probe as fb  # noqa: E402
from visual_track_bridge import StreamingBridge, gray as bridge_gray  # noqa: E402
from visual_track_bridge_authority import BridgeAuthority, TimFrame, classify_reason  # noqa: E402
from audit_visdrone_selected_person_corpus import load_sequence_rows  # noqa: E402
from controller_output_adapter import from_tim_mars  # noqa: E402
from evaluate_visdrone_selected_person import AttributionConfig, evaluate_episode  # noqa: E402
from resolve_episode_initialization import resolve_initialization  # noqa: E402
from score_raw_tracker_sequence import validate_raw_replay  # noqa: E402
from shared_detector_cache import read_committed_frozen_inputs  # noqa: E402
from target_reid_episode import track_message  # noqa: E402
from write_raw_tracker_replay import ARM_CONFIGS, sha256_file  # noqa: E402
from write_shared_detector_cache import image_paths_by_source_frame  # noqa: E402
from run_deterministic_tim_replay import build_runtime, load_canonical_parameters  # noqa: E402
from thesis_bringup.tim_mars.runtime import TimMarsRuntime  # noqa: E402
from thesis_bringup.perception.preprocessing import ImageTransform  # noqa: E402

MAIN = rv.MAIN

# Audit of positive-memory reinforcement: how many trusted/adaptive updates one source observation caused.
from collections import Counter  # noqa: E402
from thesis_bringup.tim_mars.positive_appearance_memory import PositiveAppearanceMemory  # noqa: E402

REINFORCE = Counter()
_ORIG_UPDATE_TRUSTED = PositiveAppearanceMemory.update_trusted


def _counting_update_trusted(self, *args, **kwargs):
    updated = _ORIG_UPDATE_TRUSTED(self, *args, **kwargs)
    if updated:
        REINFORCE[kwargs.get("source_observation")] += 1
    return updated


PositiveAppearanceMemory.update_trusted = _counting_update_trusted
FG2X_FLAGS = dict(rv.VARIANTS["vFG2x"])
ARMS = {
    "tim_canonical": dict(flags={}, encoder="mars", bridge=0),
    "tim_fg2x": dict(flags=FG2X_FLAGS, encoder="mars", bridge=0),
    "candidate": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30, bridge_width=640),
    "candidate_fullres": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30),
    "cand_w640": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30, bridge_width=640, authority=True),
    "cand_w800": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30, bridge_width=800, authority=True),
    "cand_w960": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30, bridge_width=960, authority=True),
    "cand_full": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30, authority=True),
    "candidate_w960": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30, bridge_width=960),
    "candidate_w800": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30, bridge_width=800),
    "candidate_repvgg": dict(flags=FG2X_FLAGS, encoder="repvgg", bridge=30, bridge_width=640),
    # selective-MARS experiment (train/val only): identical to cand_full except the appearance request policy
    "sync_rec": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30, authority=True, record=True),
    "smr_base": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30, authority=True, record=True),
    # FROZEN CANDIDATE for the independent test-dev confirmation: identical to sync_rec except that the bridge budget is the explicit time contract
    # (1000 ms of source-stamp time since the last TIM-verified frame, checked before publication) instead of the frame count. On the regular 30 Hz
    # benchmark clock (one 33,333,333 ns tick per frame) the two rules coincide frame for frame.
    "candidate_v1": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30, authority=True, record=True, bridge_max_age_ms=1000),
    # asynchronous CPU MARS (virtual-time worker, measured 33.4 ms/crop), otherwise identical to smr_base
    "asy_virtual": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30, authority=True, record=True, async_cpu="virtual",
                        epoch_invalidation=True),
    "asy_virtual_onset": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30, authority=True, record=True,
                              async_cpu="virtual", async_challenge="post_onset", epoch_invalidation=True),
    # gate-first recovery: motion gate before appearance ranking, and only gated candidates encoded in prolonged-LOST recovery
    "gate_first": dict(flags={**FG2X_FLAGS, "dev_gate_first_recovery": True}, encoder="mars", bridge=30, authority=True, record=True,
                       request_policy="gate_first"),
    "smr_sel": dict(flags=FG2X_FLAGS, encoder="mars", bridge=30, authority=True, record=True,
                    request_policy="decision_dependent", epoch_invalidation=True),
}


def tim_stream(frames, src_frames, init, runtime_factory, image_for_frame, end_frame):
    boxes = {fi: None for fi in src_frames}
    ids = {fi: None for fi in src_frames}
    infos = {}
    if not init.success:
        return boxes, ids, infos
    conf = int(init.initialization_frame_index)
    runtime = runtime_factory(int(init.initial_tracker_identity))
    for pos, frame in enumerate(frames):
        fi = src_frames[pos]
        if fi < conf or fi > end_frame:
            continue
        if not runtime.add_image(int(frame["logical_frame_stamp_ns"]), image_for_frame(frame)):
            raise ValueError(f"TIM runtime rejected image at frame {fi}")
        t0 = time.perf_counter()
        result = runtime.process_tracks(track_message(frame))
        wall_ms = (time.perf_counter() - t0) * 1000.0
        out = result.output
        d = result.diagnostics
        observation = from_tim_mars(result)
        best = out.best_score
        infos[fi] = {"control_valid": bool(out.control_valid),
                     "state": out.state.value if hasattr(out.state, "value") else str(out.state),
                     "reason": str(out.reason),
                     "candidate_id": None if best is None else int(best.track_id),
                     "diag": {"wall_ms": wall_ms, "n_tracks": len(frame["tracks"]),
                              "requested": int(d.appearance_request_candidates),
                              "req_reason": str(d.appearance_request_reason),
                              "enc_eligible": int(d.appearance_request_encoding_eligible),
                              "backend_calls": int(d.appearance_backend_calls),
                              "backend_requested": int(d.appearance_backend_requested),
                              "backend_ms": float(d.appearance_backend_wall_ms),
                              "skip": str(d.appearance_skip_reason),
                              "cache_hits": int(d.appearance_cache_hits),
                              "cache_invalidated": int(d.appearance_cache_invalidated),
                              "max_age_ms": max(d.appearance_embedding_age_ms_by_track_id.values(), default=None),
                     "app": bool(best is not None and getattr(best, "appearance_used", False)),
                     "age_best": (None if best is None else d.appearance_embedding_age_ms_by_track_id.get(int(best.track_id))),
                     "age_sel": (None if runtime.memory.target_track_id is None
                                 else d.appearance_embedding_age_ms_by_track_id.get(int(runtime.memory.target_track_id))),
                     "sel_visible": bool(runtime.memory.target_track_id is not None and any(
                         int(t["track_id"]) == int(runtime.memory.target_track_id) for t in frame["tracks"])),
                     "async": ({k: v for k, v in runtime.async_stats.items() if k != "delivery_lag_ms"} if runtime.async_encoder is not None else None)}}
        if observation.bbox_xyxy is not None:
            boxes[fi] = tuple(observation.bbox_xyxy)
            ids[fi] = int(observation.tracker_identity)
    return boxes, ids, infos


def authority_bridge_stream(frames, src_frames, boxes0, ids0, infos, conf, end_frame, images_b, others_b, transform,
                            max_age, period_ns, counters, max_age_ms=None):
    """Visual-track bridge under the authority contract (see visual_track_bridge_authority.py)."""
    to_bridge = (lambda b: list(transform.source_xyxy_to_inference(tuple(b)))) if transform else (lambda b: list(b))
    to_source = (lambda b: list(transform.inference_xyxy_to_source(tuple(b)))) if transform else (lambda b: list(b))
    auth = BridgeAuthority(max_age_frames=max_age, period_ns=period_ns, max_age_ms=max_age_ms)
    boxes, ids, modes = dict(boxes0), dict(ids0), {}
    bridge = None
    seed_pos = None
    for pos, frame in enumerate(frames):
        fi = src_frames[pos]
        if fi < conf or fi > end_frame:
            continue
        info = infos[fi]
        stamp = int(frame["logical_frame_stamp_ns"])
        cands = [tuple(t["bbox_xyxy"]) for t in frame["tracks"]]
        if info["control_valid"]:
            auth.observe(TimFrame(stamp, True, info["state"], info["reason"], 0, True, ids0[fi], boxes0[fi]), cands, None)
            bridge = None
            seed_pos = pos
            continue
        if not auth.can_start() and auth.seed_generation is None:
            continue
        if bridge is None and auth.can_start():
            bridge = StreamingBridge(bridge_gray(images_b(seed_pos)), to_bridge(boxes0[src_frames[seed_pos]]), allow_coast=False)
        proposal = None
        if bridge is not None:
            result = bridge.step(bridge_gray(images_b(pos)), others_b(pos - 1))
            if result is None:
                bridge = None
            else:
                proposal = tuple(to_source(result[0]))
        klass = classify_reason(info["reason"], info["state"])
        rejected = []
        if klass in ("identity_rejection", "hard_negative_conflict", "pending_confirmation") and info["candidate_id"] is not None:
            rejected = [tuple(t["bbox_xyxy"]) for t in frame["tracks"] if int(t["track_id"]) == int(info["candidate_id"])]
        decision = auth.observe(TimFrame(stamp, False, info["state"], info["reason"], 0, True, None, None, tuple(rejected)),
                                cands, proposal)
        counters[f"{decision.code}|{decision.reason_class}"] = counters.get(f"{decision.code}|{decision.reason_class}", 0) + 1
        if decision.allow:
            boxes[fi] = proposal
            ids[fi] = decision.track_id
            modes[fi] = "track"
        if decision.terminated:
            bridge = None
    return boxes, ids, modes


def bridge_runs(frames, src_frames, boxes0, ids0, conf, end_frame, images, others, transform=None):
    """Bridge silent stretches. `images`/`others` are in the bridge image's pixels; `transform` is the
    contract ImageTransform (source <-> bridge image). Every box in and out is in source pixels."""
    to_bridge = (lambda b: list(transform.source_xyxy_to_inference(tuple(b)))) if transform else (lambda b: list(b))
    to_source = (lambda b: list(transform.inference_xyxy_to_source(tuple(b)))) if transform else (lambda b: list(b))
    runs = []
    prev_pub = None
    i = 0
    while i < len(frames):
        fi = src_frames[i]
        if fi > end_frame:
            break
        if boxes0.get(fi) is not None:
            prev_pub = i
        elif prev_pub is not None and fi >= conf:
            run_tid = ids0[src_frames[prev_pub]]
            start_box = to_bridge(boxes0[src_frames[prev_pub]])
            run = fb.simulate_bridge(images, frames, prev_pub, start_box, others)
            cut = []
            for pos, box, mode in run:
                if boxes0.get(src_frames[pos]) is not None or src_frames[pos] > end_frame:
                    break
                cut.append((pos, to_source(box), mode))
            if cut:
                runs.append((run_tid, cut))
            j = i
            while j < len(frames) and boxes0.get(src_frames[j]) is None:
                j += 1
            i = j
            continue
        i += 1
    return runs


def run_sequence(arm_name, split, seq, protocol, manifest, frozen, tail_frames, data_root, cache_root, tracker_root,
                 backend_cache):
    spec = ARMS[arm_name]
    hashes = protocol["pre_result_implementation_hashes_draft"]
    entry = [e for e in manifest["sequence_inventory"] if e["split"] == split and e["sequence_name"] == seq][0]
    image_paths = image_paths_by_source_frame(data_root / split / "sequences" / seq)
    nums = sorted(image_paths)
    cache = cache_root / split / f"{seq}.json"
    rp = tracker_root / "bytetrack_raw" / split / f"{seq}.json"
    if os.environ.get("TRACKER_FRAMES_DIR"):
        # Development only (default off): tracker frames of a development tracker variant, not the frozen replay.
        frames = json.loads((Path(os.environ["TRACKER_FRAMES_DIR"]) / split / f"{seq}.json").read_text())["frames"]
    else:
      frames = validate_raw_replay(
        json.loads(rp.read_text()), arm="bytetrack_raw", split=split, sequence_name=seq,
        source_frame_numbers=nums, protocol_sha256=frozen["protocol_sha256"],
        manifest_sha256=frozen["manifest_sha256"], freeze_commit=frozen["freeze_commit"],
        detector_cache_sha256=sha256_file(cache), tracker_config_sha256=hashes[ARM_CONFIGS["bytetrack_raw"]])
    rows = load_sequence_rows(split=split, sequence_name=seq, annotation_path=data_root / split / "annotations" / f"{seq}.txt",
                              image_width=int(entry["image_width"]), image_height=int(entry["image_height"]))
    src_frames = [int(f["normalized_frame_index"]) for f in frames]
    cache_imgs = {}

    def images(i):
        if i not in cache_imgs:
            if len(cache_imgs) > 6:
                cache_imgs.pop(next(iter(cache_imgs)))
            cache_imgs[i] = cv2.imread(str(image_paths[int(frames[i]["source_frame_number"])]), cv2.IMREAD_COLOR)
        return cache_imgs[i]

    def others(i):
        return [t["bbox_xyxy"] for t in frames[i]["tracks"]]

    canonical = load_canonical_parameters(MAIN / "ros2_ws/src/thesis_bringup/config/tim_mars_canonical.yaml")
    base = build_runtime(canonical, argparse.Namespace(
        appearance_enabled=None, appearance_request_policy=None, appearance_compute_min_interval_ms=None,
        image_width=float(entry["image_width"]), image_height=float(entry["image_height"]),
        tracks_are_normalized=False, selected_track_id=0, model=MAIN / "models/reid/mars-small128.pb"))
    flags = dict(spec["flags"])
    flags.pop("__encoder__", None)
    if spec["encoder"] == "repvgg":
        if "backend" not in backend_cache:
            backend_cache["backend"] = rv.HailoRepVggBackend()
        tmap = json.load(open(Path.home() / "tim_vnext_runs/hailo/repvgg_threshold_map.json"))
        flags.update({k: tmap[str(v)] for k, v in rv.MAPPED_FIELDS.items()})
        base.mars_backend = backend_cache["backend"]

    def factory(sid):
        mem = replace(copy.deepcopy(base.config.memory), **flags)
        cfg = replace(base.config, memory=mem, selected_track_id=sid)
        if spec.get("request_policy"):
            cfg = replace(cfg, appearance_request_policy=spec["request_policy"])
        if spec.get("epoch_invalidation"):
            cfg = replace(cfg, appearance=replace(cfg.appearance, epoch_invalidation=True))
        rt = TimMarsRuntime(config=cfg, mars_backend=base.mars_backend)
        if spec.get("async_cpu"):
            from thesis_bringup.tim_mars.async_cpu_mars import AsyncMarsEncoder
            rt.enable_async_cpu_mars(AsyncMarsEncoder(base.mars_backend, capacity=16, expiry_ns=750_000_000,
                                                      mode=spec["async_cpu"]),
                                     challenge_mode=spec.get("async_challenge", "strict"))
        return rt

    def image_for_frame(frame):
        return cv2.imread(str(image_paths[int(frame["source_frame_number"])]), cv2.IMREAD_COLOR)

    results = []
    for ep in [e for e in manifest["episodes"] if e["split"] == split and e["sequence_name"] == seq]:
        init = resolve_initialization(
            episode=ep, gt_rows=rows, tracker_frames=frames,
            minimum_match_iou=float(protocol["initialization_draft"]["minimum_match_iou"]),
            minimum_match_margin=float(protocol["initialization_draft"]["minimum_match_margin"]),
            confirmation_frames=int(protocol["initialization_draft"]["confirmation_frames"]))
        targets = [int(r.normalized_frame_index) for r in rows if int(r.identity) == int(ep["dataset_identity"])
                   and r.include_as_person_candidate and int(r.normalized_frame_index) >= int(ep["selection_frame_index"])]
        last_target = max(targets)
        end_frame = min(last_target + int(tail_frames), src_frames[-1])
        REINFORCE.clear()
        boxes0, ids0, infos = tim_stream(frames, src_frames, init, factory, image_for_frame, end_frame)
        reinforce = {"updates": int(sum(REINFORCE.values())), "observations": len(REINFORCE),
                     "max_per_observation": max(REINFORCE.values(), default=0),
                     "updates_without_observation_id": int(REINFORCE.get(None, 0))}
        auth_counts = {}
        modes = {}
        boxes, ids = boxes0, ids0
        if init.success and spec["bridge"] > 0:
            bw = spec.get("bridge_width")
            if bw:
                bh = int(round(float(entry["image_height"]) * float(bw) / float(entry["image_width"])))
                transform = ImageTransform.direct_resize(int(entry["image_width"]), int(entry["image_height"]), int(bw), bh)
                imgs_b = lambda i: cv2.resize(images(i), (int(bw), bh), interpolation=cv2.INTER_AREA)
                oth_b = lambda i: [list(transform.source_xyxy_to_inference(tuple(b))) for b in others(i)]
            else:
                transform, imgs_b, oth_b = None, images, others
            if spec.get("authority"):
                boxes, ids, modes = authority_bridge_stream(
                    frames, src_frames, boxes0, ids0, infos, int(init.initialization_frame_index), end_frame, imgs_b, oth_b,
                    transform, int(spec["bridge"]), 33_333_333, auth_counts, max_age_ms=spec.get("bridge_max_age_ms"))
            else:
                runs = bridge_runs(frames, src_frames, boxes0, ids0, int(init.initialization_frame_index), end_frame, imgs_b, oth_b, transform)
                boxes, ids, modes = fb.bridged_maps(frames, boxes0, ids0, runs, int(spec["bridge"]), False)
        evaluation = evaluate_episode(
            split=split, sequence_name=seq, dataset_identity=int(ep["dataset_identity"]),
            selection_frame_index=int(ep["selection_frame_index"]), source_frame_indices=src_frames, gt_rows=rows,
            output_bboxes_by_frame=boxes, output_tracker_ids_by_frame=ids,
            config=AttributionConfig(
                person_iou_threshold=float(protocol["evaluation_draft"]["target_iou_threshold"]),
                unique_iou_margin=float(protocol["evaluation_draft"]["unique_iou_margin"]),
                ambiguous_region_output_coverage=float(
                    protocol["evaluation_draft"]["ambiguous_region_output_coverage_threshold"])))
        tail = [fi for fi in src_frames if last_target < fi <= end_frame]
        results.append({
            "episode": ep, "initialization": asdict(init), "evaluation": evaluation,
            "bridged": {str(k): v for k, v in modes.items()},
            "authority": auth_counts,
            "reinforce": reinforce,
            **({"record": {
                "outputs": {str(fi): [round(float(v), 3) for v in boxes[fi]] + [ids[fi]]
                            for fi in src_frames if boxes.get(fi) is not None},
                "tim": {str(fi): [i["control_valid"], i["state"], i["reason"][:60], i["candidate_id"], i["diag"]]
                        for fi, i in infos.items()}}} if spec.get("record") else {}),
            "tail": {"horizon_frames": int(tail_frames), "tail_frames": len(tail),
                     "output_frames": sum(1 for fi in tail if boxes.get(fi) is not None),
                     "bridged_output_frames": sum(1 for fi in tail if str(fi) in {str(k) for k in modes}),
                     "last_target_observation": last_target}})
    return results


def provenance(arm):
    """Identity of the code, model and runtime that produced a result file (additive; does not affect any decision)."""
    import subprocess

    here = Path(__file__).resolve().parents[2]
    def git(*args):
        try:
            return subprocess.check_output(["git", *args], cwd=here, text=True).strip()
        except Exception:
            return None
    model = os.environ.get("TIM_MARS_ONNX_MODEL")
    return {"arm": arm, "arm_spec": {k: v for k, v in ARMS[arm].items() if k != "flags"}, "tim_guard_flags": ARMS[arm]["flags"],
            "code_head": git("rev-parse", "HEAD"), "tracked_files_modified": bool(git("status", "--porcelain", "--untracked-files=no")),
            "encoder_runtime": "onnxruntime" if model else "tensorflow", "onnx_model": model, "onnx_model_sha256": sha256_file(Path(model)) if model else None,
            "environment": {k: os.environ.get(k) for k in ("TIM_MARS_ONNX_THREADS", "OMP_NUM_THREADS", "TF_NUM_INTRAOP_THREADS", "TF_NUM_INTEROP_THREADS", "TRACKER_FRAMES_DIR")}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", choices=tuple(ARMS), required=True)
    ap.add_argument("--split", required=True)
    ap.add_argument("--sequences-file", type=Path, required=True)
    ap.add_argument("--output-root", type=Path, required=True)
    ap.add_argument("--protocol", type=Path, default=MAIN / "docs/data/external_benchmark_v2/visdrone_selected_person_protocol_v1.json")
    ap.add_argument("--manifest", type=Path, default=MAIN / "docs/data/external_benchmark_v2/visdrone_gt_only_episode_manifest_v1.json")
    ap.add_argument("--repository-root", type=Path, default=MAIN)
    ap.add_argument("--data-root", type=Path, default=MAIN / "data/datasets/external/visdrone_mot")
    ap.add_argument("--cache-root", type=Path, default=MAIN / "artifacts/reports/p125_shared_detector_cache")
    ap.add_argument("--tracker-root", type=Path, default=MAIN / "artifacts/reports/p125_raw_tracker_replay")
    ap.add_argument("--tail-frames", type=int, default=90)
    ap.add_argument("--shard", default="0/1")
    a = ap.parse_args()
    frozen = read_committed_frozen_inputs(repository_root=a.repository_root, protocol_path=a.protocol, manifest_path=a.manifest)
    protocol, manifest = frozen["protocol"], frozen["manifest"]
    si, sn = map(int, a.shard.split("/"))
    todo = [l.split()[:2] for l in open(a.sequences_file) if l.strip()][si::sn]
    backend_cache = {}
    try:
        for split, seq in todo:
            out = a.output_root / a.arm / split / f"{seq}.json"
            if out.exists():
                continue
            res = run_sequence(a.arm, split, seq, protocol, manifest, frozen, a.tail_frames, a.data_root, a.cache_root,
                               a.tracker_root, backend_cache)
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps({"variant": a.arm, "split": split, "sequence_name": seq, "provenance": provenance(a.arm), "episodes": res}))
            print("done", a.arm, seq, flush=True)
    finally:
        if "backend" in backend_cache:
            backend_cache["backend"].close()


if __name__ == "__main__":
    main()
