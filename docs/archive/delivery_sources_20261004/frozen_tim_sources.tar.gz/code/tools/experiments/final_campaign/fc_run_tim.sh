#!/bin/bash
# TIM arms for a list of sequences: retained reference (pipeline arm candidate_v1, FP32 ORT MARS, 4 parallel jobs) then canonical TIM-MARS (frozen writer, TF MARS, 3 parallel). Stops on throttling.
# usage: fc_run_tim.sh <list-file> <out-root> [ref|canon|both]; list lines: "<dataset> <sequence> <shaped_root> <cache_root> <tracker_root> <manifest> [split=val]"
FC=/home/francisco/final_campaign_20261003; DEV=/home/francisco/Desktop/Thesis-Code-tim-vnext2; X=$DEV/tools/experiments/final_campaign/fc_frozen_exec.py; mkdir -p $FC/logs
source /opt/ros/jazzy/setup.bash; source /home/francisco/Desktop/Thesis-Code-frozen-issue125/ros2_ws/install/setup.bash 2>/dev/null; source /home/francisco/tim_vnext_runs/msgs_install/setup.bash
export FROZEN_ROOT=/home/francisco/Desktop/Thesis-Code-frozen-issue125 OMP_NUM_THREADS=1 TF_NUM_INTRAOP_THREADS=1 TF_NUM_INTEROP_THREADS=1 TF_CPP_MIN_LOG_LEVEL=3 OV_D2=1
export PYTHONPATH=$DEV/ros2_ws/src/thesis_bringup:$DEV/ros2_ws/src/thesis_tracker:$PYTHONPATH FC X DEV
LIST=$1; OUT=$2; MODE=${3:-both}; mkdir -p $OUT/ref/trace $OUT/ref/results $OUT/ref/seq $OUT/canonical
ref() { DS=$1; SEQ=$2; ROOT=$3; CACHE=$4; TRK=$5; MAN=$6; SP=${7:-val}
  T=$(vcgencmd get_throttled); case "$T" in *0x0) ;; *) echo "STOP throttled $T" >> $FC/logs/tim_progress.log; return 3;; esac
  [ -f $OUT/ref/results/candidate_v1/$SP/$SEQ.json ] && return 0
  echo "$SP $SEQ 0" > $OUT/ref/seq/$SEQ.txt
  TIM_MARS_ONNX_MODEL=/home/francisco/tim_vnext_runs/venv_onnx_probe/mars.onnx TIM_MARS_ONNX_THREADS=1 OV_TRACE=$OUT/ref/trace/$SEQ.jsonl python3 $DEV/tools/experiments/overnight/ov_trace_pipeline.py --arm candidate_v1 --split dev --sequences-file $OUT/ref/seq/$SEQ.txt --output-root $OUT/ref/results --manifest $MAN --data-root $ROOT --cache-root $CACHE --tracker-root $TRK > $FC/logs/ref_$SEQ.log 2>&1
  echo "$(date +%H:%M:%S) ref $DS/$SEQ exit=$?" >> $FC/logs/tim_progress.log; }
canon() { DS=$1; SEQ=$2; ROOT=$3; CACHE=$4; TRK=$5; MAN=$6; SP=${7:-val}
  [ -f $OUT/canonical/$SP/$SEQ.json ] && return 0
  FC_MANIFEST=$MAN python3 $X write_tim_mars_sequence.py x -- --split $SP --sequence $SEQ --dataset-root $ROOT --cache-root $CACHE --tracker-root $TRK --output-root $OUT/canonical > $FC/logs/canon_$SEQ.log 2>&1
  echo "$(date +%H:%M:%S) canonical $DS/$SEQ exit=$?" >> $FC/logs/tim_progress.log; }
export -f ref canon; export OUT
[ "$MODE" != canon ] && { xargs -P 4 -L1 bash -c 'ref "$@"' _ < $LIST; echo "REF_DONE $(basename $LIST)" >> $FC/logs/tim_progress.log; }
[ "$MODE" != ref ] && { xargs -P 3 -L1 bash -c 'canon "$@"' _ < $LIST; echo "CANON_DONE $(basename $LIST)" >> $FC/logs/tim_progress.log; }
