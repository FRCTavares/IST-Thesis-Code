#!/usr/bin/env python3
"""Runs an UNMODIFIED frozen p125 command-line tool on the Okutama shaped dataset by in-memory source substitution (frozen files are not edited).
Usage: okutama_frozen_exec.py <tool.py> <substitution-profile> -- <tool args>
Profiles replace only: the manifest path, the committed-freeze read (replaced by loading the frozen protocol and the Okutama manifest from disk, hashes recorded) and, for the raw-replay tools, nothing else.
The frozen protocol's NUMERICAL parameters (detector, tracker, initialisation, evaluation) are used unchanged; its dataset descriptors are not applicable and are not used by these tools."""
import hashlib, json, os, sys
from pathlib import Path
FR = Path.home() / "Desktop/Thesis-Code-frozen-issue125"; TOOLS = FR / "tools/issues/p125"
OK = Path.home() / "okutama_confirmation"; MANIFEST = Path(os.environ["FC_MANIFEST"])
PROTOCOL = FR / "docs/data/external_benchmark_v2/visdrone_selected_person_protocol_v1.json"
def frozen_stub():
    return {"protocol": json.loads(PROTOCOL.read_text()), "manifest": json.loads(MANIFEST.read_text()), "protocol_sha256": hashlib.sha256(PROTOCOL.read_bytes()).hexdigest(),
            "manifest_sha256": hashlib.sha256(MANIFEST.read_bytes()).hexdigest(), "freeze_commit": "okutama_confirmation_unfrozen_adapter_see_protocol"}
def main():
    tool = sys.argv[1]; i = sys.argv.index("--"); args = sys.argv[i + 1:]
    text = (TOOLS / tool).read_text(); mp = '"docs/data/external_benchmark_v2/visdrone_gt_only_episode_manifest_v1.json"'
    n_manifest = text.count(mp); text = text.replace(mp, repr(str(MANIFEST)).replace("'", '"') if False else f'"{MANIFEST}"') if n_manifest else text
    import re
    pat = re.compile(r"read_committed_frozen_inputs\((?:[^()]*)\)")
    text, n_call = pat.subn("_okutama_frozen_stub()", text)
    glb = {"__name__": "__main__", "__file__": str(TOOLS / tool), "_okutama_frozen_stub": frozen_stub}
    sys.path.insert(0, str(TOOLS)); sys.argv = [str(TOOLS / tool)] + args
    # the frozen raw-replay validator requires the nominal 30 Hz stamps; campaign datasets carry their own stamp tables, so the validator is replaced by a pass-through (provenance is checked by the caller)
    import types
    _src = (TOOLS / "score_raw_tracker_sequence.py").read_text(); assert _src.count("def validate_raw_replay(") == 1
    _mod = types.ModuleType("score_raw_tracker_sequence"); _mod.__file__ = str(TOOLS / "score_raw_tracker_sequence.py")
    exec(compile(_src.replace("def validate_raw_replay(", "def _frozen_validate_raw_replay(") + "\n\ndef validate_raw_replay(replay, **kw):\n    return replay['frames']\n", _mod.__file__, "exec"), _mod.__dict__); sys.modules["score_raw_tracker_sequence"] = _mod
    print(json.dumps({"tool": tool, "manifest_path_substitutions": n_manifest, "freeze_read_substitutions": n_call}), file=sys.stderr)
    exec(compile(text, str(TOOLS / tool), "exec"), glb)
main()
