#!/usr/bin/env python3
"""Final campaign raw-tracker replay on cached shared detector outputs: SORT, ByteTrack, OC-SORT, DeepSORT (frozen implementations/configs, built by the frozen `build_backend`) and BoT-SORT
(Ultralytics 8.3.227 defaults, `botsort_backend.py`). Identical detections for every tracker (the shared detector cache; each tracker applies its own YAML minimum score), identical decoded frames,
declared stamps: dataset stamp table (video PTS / bag timestamps, relative + 1 s) or the frozen nominal 30 Hz logical tick. Output schema = p125_raw_tracker_sequence_replay_v1 (+ stamp basis).
Usage: fc_tracker_replay.py --arm {sort_raw,bytetrack_raw,ocsort_raw,deepsort_raw,botsort_raw} --root SHAPED_ROOT --cache-root C --out-root O --sequence S [--stamps meta.json]"""
import argparse, hashlib, importlib.util, json, math, os, sys
from pathlib import Path
FR = Path("/home/francisco/Desktop/Thesis-Code-frozen-issue125"); DEV = Path("/home/francisco/Desktop/Thesis-Code-tim-vnext2")
os.environ.setdefault("YOLO_AUTOINSTALL", "False")
sys.path[:0] = [str(FR / "ros2_ws/src/thesis_tracker"), str(FR / "ros2_ws/src/thesis_bringup"), str(FR / "tools/issues/p125"), str(FR / "tools/experiments")]
ap = argparse.ArgumentParser(); ap.add_argument("--arm", required=True); ap.add_argument("--root", type=Path, required=True); ap.add_argument("--cache-root", type=Path, required=True); ap.add_argument("--out-root", type=Path, required=True)
ap.add_argument("--sequence", required=True); ap.add_argument("--stamps", type=Path); ap.add_argument("--split", default="val"); a = ap.parse_args()
from write_shared_detector_cache import image_paths_by_source_frame, write_cache_once
from write_raw_tracker_replay import ARM_CONFIGS, sha256_file, make_deepsort_image_callback
CFG = {**{k: FR / v for k, v in ARM_CONFIGS.items()}, "botsort_raw": DEV / "ros2_ws/src/thesis_bringup/config/tracker_botsort.yaml"}
cfgp = CFG[a.arm]; cache_path = a.cache_root / a.split / f"{a.sequence}.json"; cache = json.loads(cache_path.read_text()); frames = cache["frames"]
images = image_paths_by_source_frame(a.root / a.split / "sequences" / a.sequence)
stamps = json.load(open(a.stamps))["stamps_ns"] if a.stamps else None; TICK = 33_333_333
def stamp_of(n): return int(stamps[str(n)]) if stamps else n * TICK
if a.arm == "botsort_raw":
    import thesis_tracker.backends  # frozen package for the relative imports
    spec = importlib.util.spec_from_file_location("thesis_tracker.backends.botsort_backend", DEV / "ros2_ws/src/thesis_tracker/thesis_tracker/backends/botsort_backend.py"); mod = importlib.util.module_from_spec(spec); mod.__package__ = "thesis_tracker.backends"
    sys.modules["thesis_tracker.backends.botsort_backend"] = mod; spec.loader.exec_module(mod)
    import yaml
    params = yaml.safe_load(open(cfgp))["tracker_node"]["ros__parameters"]; min_score = float(params["min_score"]); backend = mod.BotSortBackend(frame_rate=int(params["frame_rate"]), image_buffer_size=int(params["image_buffer_size"]), max_image_age_ms=float(params["max_image_age_ms"]))
    impl = {"botsort": backend.config}
else:
    from run_deterministic_tracker_replay import build_backend, load_tracker_parameters
    params = load_tracker_parameters(cfgp); mars = FR / "models/reid/mars-small128.pb"
    ttype, min_score, backend = build_backend(params, mars if a.arm == "deepsort_raw" else None); assert ttype == a.arm.removesuffix("_raw"); impl = {"frozen_worktree": "0757e74e"}
before = make_deepsort_image_callback(backend=backend, image_paths=images) if a.arm in ("deepsort_raw", "botsort_raw") else None
replay = []
for fr in frames:
    n = int(fr["source_frame_number"]); st = stamp_of(n)
    if before: before(n, st)
    dets = [d for d in fr["detections"] if float(d["score"]) >= min_score]
    tracks = backend.update([tuple(d["bbox_xyxy"]) for d in dets], [float(d["score"]) for d in dets], st); seen = set(); recs = []
    for t in tracks:
        tid = int(t.track_id); box = tuple(float(v) for v in t.bbox_xyxy)
        if tid <= 0 or tid in seen or not all(math.isfinite(v) for v in box) or box[2] <= box[0] or box[3] <= box[1]: raise ValueError(f"invalid tracker output frame {n}")
        seen.add(tid); recs.append({"track_id": tid, "bbox_xyxy": list(box), "score": float(t.score)})
    replay.append({"source_frame_number": n, "normalized_frame_index": int(fr["normalized_frame_index"]), "logical_frame_stamp_ns": st, "tracks": recs})
doc = {"schema": "p125_raw_tracker_sequence_replay_v1", "arm": a.arm, "split": a.split, "sequence_name": a.sequence, "protocol_sha256": cache["protocol_sha256"], "manifest_sha256": cache["manifest_sha256"], "freeze_commit": cache["freeze_commit"],
       "detector_cache_sha256": sha256_file(cache_path), "tracker_config_sha256": sha256_file(cfgp), "logical_frame_tick_ns": TICK, "logical_tick_is_physical_time": False,
       "stamp_basis": "dataset stamp table" if stamps else "frozen nominal 30 Hz logical tick", "implementation": impl, "min_score": min_score, "frame_count": len(replay), "frames": replay}
out = a.out_root / a.arm / a.split / f"{a.sequence}.json"; print(json.dumps({"output": str(out), "sha256": write_cache_once(out, doc)}))
