from pathlib import Path
FC = Path.home() / "final_campaign_20261003"; ds = ["flight_1_baseline_a","flight_2_candidate","flight_3_baseline_b","may_hard_reentry","june_seq01","june_seq03","june_seq04","h01_exit_reentry","h02_crossing","h03_occlusion_distractor","p064_gate2_hd"]
with open(FC / "list_cvat_tim.txt", "w") as f:
    for d in ds: f.write(f"{d} {d} {FC}/shaped/{d} {FC}/cache/{d} {FC}/tracker/{d} {FC}/audit/{d}_episode_manifest.json\n")
with open(FC / "list_cvat_score.txt", "w") as f:
    for d in ds: f.write(f"{d} {d} {FC}/shaped/{d} {FC}/cache/{d} {FC}/tracker/{d} {FC}/audit/{d}_episode_manifest.json\n")
