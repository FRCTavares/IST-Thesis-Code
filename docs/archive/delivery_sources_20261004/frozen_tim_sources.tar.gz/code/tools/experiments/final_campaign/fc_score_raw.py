#!/usr/bin/env python3
"""Score one raw-tracker replay (any of the six arms, incl. BoT-SORT) for every manifest episode with the UNMODIFIED frozen initialisation rule and evaluator (score_raw_episodes of the frozen
score_raw_tracker_sequence module, the frozen protocol's numeric initialisation/evaluation parameters). Failed initialisation = explicit no-output. Own light validation replaces the frozen
nominal-clock check so that dataset stamp tables are accepted. Usage: fc_score_raw.py --arm A --root R --cache-root C --tracker-root T --out-root O --sequence S --manifest M"""
import argparse, hashlib, json, sys
from pathlib import Path
FR = Path.home() / "Desktop/Thesis-Code-frozen-issue125"; sys.path.insert(0, str(FR / "tools/issues/p125")); sys.path.insert(0, str(FR / "tools/analysis")); sys.path.insert(0, str(FR / "ros2_ws/src/thesis_bringup"))
from audit_visdrone_selected_person_corpus import load_sequence_rows
from score_raw_tracker_sequence import score_raw_episodes
from write_shared_detector_cache import image_paths_by_source_frame, write_cache_once
ap = argparse.ArgumentParser()
for k in ("--arm", "--sequence"): ap.add_argument(k, required=True)
for k in ("--root", "--cache-root", "--tracker-root", "--out-root", "--manifest"): ap.add_argument(k, type=Path, required=True)
ap.add_argument("--split", default="val"); a = ap.parse_args()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
protocol = json.loads((FR / "docs/data/external_benchmark_v2/visdrone_selected_person_protocol_v1.json").read_text()); manifest = json.loads(a.manifest.read_text())
entry = [e for e in manifest["sequence_inventory"] if e["split"] == a.split and e["sequence_name"] == a.sequence][0]
paths = image_paths_by_source_frame(a.root / a.split / "sequences" / a.sequence); nums = sorted(paths)
assert len(nums) == entry["image_frame_count"] and nums[0] == entry["first_source_frame"] and nums[-1] == entry["last_source_frame"], "images differ from the manifest inventory"
ann = a.root / a.split / "annotations" / f"{a.sequence}.txt"; assert sha(ann) == entry["annotation_sha256"], "annotation differs from the manifest inventory"
rows = load_sequence_rows(split=a.split, sequence_name=a.sequence, annotation_path=ann, image_width=int(entry["image_width"]), image_height=int(entry["image_height"]))
rp = a.tracker_root / a.arm / a.split / f"{a.sequence}.json"; replay = json.loads(rp.read_text()); frames = replay["frames"]
assert replay["arm"] == a.arm and replay["sequence_name"] == a.sequence and [f["source_frame_number"] for f in frames] == nums, "tracker replay does not match the sequence"
assert replay["detector_cache_sha256"] == sha(a.cache_root / a.split / f"{a.sequence}.json"), "tracker replay was produced from a different detector cache"
eps = [e for e in manifest["episodes"] if e["split"] == a.split and e["sequence_name"] == a.sequence]
res = score_raw_episodes(split=a.split, sequence_name=a.sequence, episodes=eps, gt_rows=rows, tracker_frames=frames, initialization_rules=protocol["initialization_draft"], evaluation_rules=protocol["evaluation_draft"])
doc = {"schema": "p125_scored_raw_tracker_sequence_v1", "arm": a.arm, "split": a.split, "sequence_name": a.sequence, "manifest_sha256": sha(a.manifest), "tracker_replay_sha256": sha(rp), "episode_count": len(res), "episodes": res}
out = a.out_root / a.arm / a.split / f"{a.sequence}.json"; print(json.dumps({"output": str(out), "sha256": write_cache_once(out, doc), "episodes": len(res)}))
