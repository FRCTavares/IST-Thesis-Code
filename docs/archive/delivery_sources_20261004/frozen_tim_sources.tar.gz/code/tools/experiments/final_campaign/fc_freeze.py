#!/usr/bin/env python3
"""Final campaign freeze record (3 Oct 2026): hashes of every code file, configuration, model, manifest and detector cache that defines the comparison, plus the retained-reference verification (candidate_v1 spec, 1000 ms bridge
contract). Writes docs/data/final_campaign_20261003/FREEZE.json. `--verify` recomputes and compares."""
import hashlib, json, os, subprocess, sys
from pathlib import Path
H = Path.home(); DEV = H / "Desktop/Thesis-Code-tim-vnext2"; FR = H / "Desktop/Thesis-Code-frozen-issue125"; MAIN = H / "Desktop/Thesis-Code"; FC = H / "final_campaign_20261003"
OUT = DEV / "docs/data/final_campaign_20261003/FREEZE.json"
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""): h.update(c)
    return h.hexdigest()
def tree(root, pat):
    return {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob(pat)) if "__pycache__" not in p.parts}
def git(cwd, *a): return subprocess.check_output(["git", *a], cwd=cwd, text=True).strip()
def build():
    sys.path[:0] = [str(DEV / "tools/experiments")]
    code = {str(p.relative_to(DEV)): sha(p) for p in [DEV / "tools/experiments/p125_candidate_pipeline.py", DEV / "tools/experiments/run_p125_tim_variant.py", DEV / "tools/experiments/run_p125_flow_bridge_probe.py", DEV / "tools/experiments/visual_track_bridge.py",
            DEV / "tools/experiments/visual_track_bridge_authority.py", DEV / "tools/experiments/visual_track_bridge_join.py", DEV / "tools/experiments/visual_track_bridge_node.py", DEV / "tools/experiments/replay_camera_node.py", DEV / "tools/experiments/overnight/ov_trace_pipeline.py",
            DEV / "tools/confirmation_testdev/frozen_root_patch.py"] + sorted(q for q in (DEV / "tools/experiments/final_campaign").glob("*") if q.is_file())}
    frozen = {str(p.relative_to(FR)): sha(p) for p in [FR / "tools/issues/p125" / n for n in ["evaluate_visdrone_selected_person.py", "resolve_episode_initialization.py", "analyse_visdrone_selected_person_statistics.py", "audit_visdrone_selected_person_corpus.py",
              "write_shared_detector_cache.py", "shared_detector_cache.py", "write_raw_tracker_replay.py", "replay_shared_detector_cache.py", "score_raw_tracker_sequence.py", "controller_output_adapter.py", "write_tim_mars_sequence.py", "tim_mars_episode.py"]] + [FR / "docs/data/external_benchmark_v2/visdrone_selected_person_protocol_v1.json", FR / "tools/experiments/run_deterministic_tracker_replay.py"]}
    cfgs = {str(p): sha(p) for p in [FR / "ros2_ws/src/thesis_bringup/config" / n for n in ["tracker_sort.yaml", "tracker_bytetrack.yaml", "tracker_ocsort.yaml", "tracker_deepsort.yaml", "tim_mars_canonical.yaml"]] + [DEV / "ros2_ws/src/thesis_bringup/config/tracker_botsort.yaml", H / "tim_vnext_runs/tim_overrides_candidate_full.json"]}
    models = {str(p): sha(p) for p in [FR / "models/reid/mars-small128.pb", FR / "models/hef/yolov8s.hef", H / "tim_vnext_runs/venv_onnx_probe/mars.onnx"]}
    # the arm specification is recorded as source text (importing the pipeline needs the frozen-root patch); the pipeline file hash is in `code`
    import re
    src = (DEV / "tools/experiments/p125_candidate_pipeline.py").read_text(); spec = {"candidate_v1_source_line": re.search(r'^    "candidate_v1": dict\(.*\),?$', src, re.M).group(0).strip(), "bridge_max_age_ms": 1000,
        "FG2X_FLAGS_source": re.search(r'^    "vFG2x": .*$', (DEV / "tools/experiments/run_p125_tim_variant.py").read_text(), re.M).group(0).strip()}
    assert "bridge_max_age_ms=1000" in spec["candidate_v1_source_line"] and "FG2X_FLAGS" in spec["candidate_v1_source_line"]
    import ultralytics
    data = {"manifests": {p.name: sha(p) for p in sorted((FC / "audit").glob("*_episode_manifest.json"))}, "meta": {p.name: sha(p) for p in sorted((FC / "meta").glob("*.json"))},
            "detector_caches": {str(p.relative_to(FC)): sha(p) for p in sorted((FC / "cache").glob("*/val/*.json"))}, "annotation_exports": {k: v["annotation_zip_sha256"] for k, v in json.load(open(FC / "registry_prepare.json")).items()}}
    return {"schema": "final_campaign_freeze_v1", "dev_branch": git(DEV, "rev-parse", "--abbrev-ref", "HEAD"), "dev_head": git(DEV, "rev-parse", "HEAD"), "dev_status_porcelain": git(DEV, "status", "--porcelain"), "frozen_worktree_head": git(FR, "rev-parse", "HEAD"),
            "flight_checkout_head": git(MAIN, "rev-parse", "HEAD"), "ultralytics_version": ultralytics.__version__, "python": sys.version.split()[0],
            "retained_reference": {"name": "TIM vNext candidate_v1 (synchronous guarded TIM-MARS, authority-gated visual-track bridge, FP32 ONNX Runtime MARS)", "pipeline_arm": "candidate_v1", "arm_spec": spec,
                                   "bridge_contract": "BridgeAuthority(max_age_ms=1000): 1000 ms of source-stamp time since the last TIM-verified frame, checked before publication, equality allowed; max_age_frames=30 is superseded; authority period_ns 33,333,333 (continuity gap 2.5 periods)",
                                   "freeze_artefacts": ["docs/results/selected_target_tracking/testdev_confirmation_protocol_20261002.md (Bridge contract (resolved))", "commit c0e4db6e (wire the 1000 ms bridge budget, add candidate_v1)"], "encoder": "TIM_MARS_ONNX_MODEL=mars.onnx, TIM_MARS_ONNX_THREADS=1", "overrides": str(H / "tim_vnext_runs/tim_overrides_candidate_full.json")},
            "code": code, "frozen_tools_and_protocol": frozen, "configs": cfgs, "models": models, "tim_mars_package_dev": tree(DEV / "ros2_ws/src/thesis_bringup/thesis_bringup/tim_mars", "*.py"), "tim_mars_package_frozen": tree(FR / "ros2_ws/src/thesis_bringup/thesis_bringup/tim_mars", "*.py"),
            "tracker_package_frozen": tree(FR / "ros2_ws/src/thesis_tracker/thesis_tracker", "*.py"), "tracker_package_dev": tree(DEV / "ros2_ws/src/thesis_tracker/thesis_tracker", "*.py"), "data": data}
if "--verify" in sys.argv:
    old = json.load(open(OUT)); new = build(); bad = []
    for sec in ("code", "frozen_tools_and_protocol", "configs", "models", "tim_mars_package_dev", "tim_mars_package_frozen", "tracker_package_frozen", "tracker_package_dev"):
        for k, v in old[sec].items():
            if new[sec].get(k) != v: bad.append(sec + ":" + k)
    for sec in ("manifests", "meta", "detector_caches", "annotation_exports"):
        for k, v in old["data"][sec].items():
            if new["data"][sec].get(k) != v: bad.append("data:" + sec + ":" + k)
    for k in ("frozen_worktree_head", "flight_checkout_head"):
        if old[k] != new[k]: bad.append(k)
    print("FREEZE VERIFY:", "OK" if not bad else "CHANGED " + str(bad[:10])); sys.exit(1 if bad else 0)
OUT.parent.mkdir(parents=True, exist_ok=True); b = build(); OUT.write_text(json.dumps(b, indent=1, sort_keys=True) + "\n"); print("freeze written; dev head", b["dev_head"][:8], "dirty:", bool(b["dev_status_porcelain"]), "frozen", b["frozen_worktree_head"][:8], "flight", b["flight_checkout_head"][:8])
