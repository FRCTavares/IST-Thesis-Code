#!/usr/bin/env python3
"""Final campaign input inventory reconciliation: Pi recordings (bags/live_camera, source/*, source_video, datasets, reference) + public datasets + the Mac CVAT list. Every item gets a status and, if it cannot be scored,
the exact blocker. Writes inventory_reconciliation.{json,csv,md} into the repository (docs/data/final_campaign_20261003)."""
import csv, json, re
from pathlib import Path
H = Path.home(); items = json.load(open(H / "pi_recording_inventory.json")); reg = json.load(open(H / "final_campaign_20261003/registry_prepare.json")); mac = json.load(open(H / "final_campaign_20261003/mac_bundle/docs/input_inventory.json"))
ANN = {  # recording-name fragment -> (campaign dataset id, note)
 "2026-05-14__11-03-26__dataset__tim_v1_hard_reentry_id_switch_raw": ("may_hard_reentry", "974 640x640 frames; CVAT export dev_may_hard_reentry (2 identities)"),
 "2026-06-19__12-48-17__source__2026-06-19__official__seq01": ("june_seq01", "1520 frames"),
 "2026-06-19__12-55-58__source__2026-06-19__official__seq03": ("june_seq03", "1931 frames"),
 "2026-06-19__12-59-53__source__2026-06-19__official__seq04": ("june_seq04", "2047 frames"),
 "2026-09-15__16-31-10__source__p027_h01": ("h01_exit_reentry", "1825 frames"), "2026-09-15__16-35-33__source__p027_h02": ("h02_crossing", "1513 frames"), "2026-09-15__16-55-25__source__p027_h03": ("h03_occlusion_distractor", "1460 frames"),
 "2026-08-27__16-34-50__source__p064_gate2_hd_master_r3": ("p064_gate2_hd", "837 frames in the annotated evaluation window 3.0-30.9 s of a 31 s source"),
 "2026-10-02__15-37-40__video__bcb_baseline_a": ("flight_1_baseline_a", "2170 PNG frames decoded from the mkv, PTS manifest"), "2026-10-02__15-49-03__video__bcb_candidate": ("flight_2_candidate", "1474 frames"), "2026-10-02__15-58-43__video__bcb_baseline_b": ("flight_3_baseline_b", "1774 frames"),
}
BLOCK = [
 ("2026-10-02__15-28-36__video__bcb_baseline_a", "excluded", "earlier 15:28 attempt preserved outside the primary three-flight package; no identity annotation; not an independent sequence"),
 ("2026-06-19__12-38-13__source", "unannotated_other_take", "short earlier take of seq01 (29 s); the annotated seq01 is the 12:48:17 take; no annotation, not an independent sequence"),
 ("2026-06-19__12-52-30__source__2026-06-19__official__seq02", "unannotated", "seq02 target re-entry: no completed CVAT annotation (non-final sequence in the project inventory); qualitative/runtime only"),
 ("2026-09-15__16-41-41__source__p027_h03", "unannotated_other_take", "second H03 take; the annotated H03 is 16:55:25; not an independent sequence"),
 ("p064_fhd_floor_smoke", "unannotated", "P064 FHD floor smoke dataset: no identity annotation"),
 ("2026-05-14__hard_reentry__image_raw__tim_good", "duplicate", "image_raw view of the May hard re-entry recording (same scene as the annotated May sequence; counted once)"),
]
import subprocess
def leaves(base):
    out = []
    for m in sorted(Path(base).rglob("metadata.yaml")):
        d = m.parent; t = m.read_text(); dur = re.search(r"duration:\n\s+nanoseconds: (\d+)", t)
        out.append({"group": "source/" + str(d.relative_to(H / "Desktop/Thesis-Code/bags/source")).split("/")[0], "name": d.name, "bytes": int(subprocess.run(["du", "-sb", str(d)], capture_output=True, text=True).stdout.split()[0]), "meta": {"duration_ns": dur.group(1) if dur else None}, "videos": {}})
    return out
items = [r for r in items if r["name"] not in ("2026-09", "2026-06-19", "2026-09-14")] + leaves(H / "Desktop/Thesis-Code/bags/source/held_out") + leaves(H / "Desktop/Thesis-Code/bags/source/official_flights") + leaves(H / "Desktop/Thesis-Code/bags/source/rehearsal")
rows = []
for r in items:
    name = r["name"]; grp = r["group"]; status, ds, note = "unannotated_qualitative_runtime_only", None, "no identity annotation; no scored accuracy"
    for frag, (d, n) in ANN.items():
        if frag in name: status, ds, note = "annotated_scored", d, n
    for frag, st, n in BLOCK:
        if frag in name: status, note = st, n
    if grp in ("reference", "ground"): status, note = "derived_output_not_a_recording", "derived reference/replay evidence, not an input recording"
    if grp.startswith("source/official_flights"): status, note = "unannotated_other_instance", "official June flight instance with MAVROS/full-pipeline bags: no CVAT annotation of this instance; the scored June sequences are the curated image_raw takes"
    v = r.get("videos") or {}; vi = next(iter(v.values()), None) or {}
    rows.append({"group": grp, "recording": name, "bytes": r["bytes"], "duration_s": (int(r["meta"]["duration_ns"]) / 1e9) if r.get("meta") and r["meta"] and r["meta"].get("duration_ns") else None, "video_width": vi.get("width"), "video_height": vi.get("height"), "status": status, "campaign_dataset": ds, "note": note})
for p in ("source/held_out/2026-09", "source/official_flights/2026-06-19", "source/rehearsal/2026-09-14"):
    pass
pub = [{"group": "public", "recording": "VisDrone-MOT train (56 sequences)", "status": "annotated_scored", "campaign_dataset": "visdrone_train", "note": "frozen manifest 1,555 episode candidates (with val and the 7 val sequences); previously accessed development data"},
       {"group": "public", "recording": "VisDrone-MOT val (7 sequences)", "status": "annotated_scored", "campaign_dataset": "visdrone_val", "note": "previously accessed development data"},
       {"group": "public", "recording": "VisDrone-MOT test-dev (17 sequences)", "status": "annotated_scored", "campaign_dataset": "visdrone_testdev", "note": "previously accessed confirmation data; earlier frozen outcome preserved; this comparison is post-access"},
       {"group": "public", "recording": "Okutama-Action test 720p (10 videos, 5 scenarios)", "status": "annotated_scored", "campaign_dataset": "okutama_720p", "note": "existing package only; exploratory, detector-limited; interpolated labels"}]
mac_rows = [{"mac_id": m["id"], "mac_frames": m.get("frames"), "mac_eligibility": m["eligibility"], "pi_reconciliation": reg.get({"development/dev_may_hard_reentry": "may_hard_reentry", "sequences/seq01": "june_seq01", "sequences/seq03_crossing_ambiguity": "june_seq03", "sequences/seq04_occlusion_no_exit": "june_seq04", "heldout/h01_exit_reentry": "h01_exit_reentry", "heldout/h02_crossing": "h02_crossing", "heldout/h03_occlusion_distractor": "h03_occlusion_distractor", "gates/p064_gate2_hd_master_r3": "p064_gate2_hd", "flight_1_baseline_a": "flight_1_baseline_a", "flight_2_candidate": "flight_2_candidate", "flight_3_baseline_b": "flight_3_baseline_b"}.get(m["id"], "-"), {}).get("frames") if reg else None} for m in mac["local_items"]]
out = H / "Desktop/Thesis-Code-tim-vnext2/docs/data/final_campaign_20261003"; out.mkdir(parents=True, exist_ok=True)
json.dump({"pi_recordings": rows, "public_datasets": pub, "mac_inventory_reconciliation": mac_rows}, open(out / "inventory_reconciliation.json", "w"), indent=1)
with open(out / "inventory_reconciliation.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["group", "recording", "bytes", "duration_s", "video_width", "video_height", "status", "campaign_dataset", "note"]); w.writeheader(); w.writerows(rows + [dict(p, bytes="", duration_s="", video_width="", video_height="") for p in pub])
from collections import Counter
c = Counter(r["status"] for r in rows); print(dict(c)); print("annotated:", [r["campaign_dataset"] for r in rows if r["status"] == "annotated_scored"])
