#!/bin/bash
source /opt/ros/jazzy/setup.bash; source /home/francisco/Desktop/Thesis-Code-frozen-issue125/ros2_ws/install/setup.bash 2>/dev/null
export OMP_NUM_THREADS=1 TF_NUM_INTRAOP_THREADS=1 TF_NUM_INTEROP_THREADS=1 TF_CPP_MIN_LOG_LEVEL=3 YOLO_AUTOINSTALL=False
FR=/home/francisco/Desktop/Thesis-Code-frozen-issue125; A=/home/francisco/Desktop/Thesis-Code/artifacts/reports; T=/tmp/fc_verify_replay; rm -rf $T; mkdir -p $T
SEQ=${1:-uav0000309_00000_v}
for ARM in bytetrack_raw sort_raw ocsort_raw deepsort_raw; do
  python3 /home/francisco/Desktop/Thesis-Code-tim-vnext2/tools/experiments/final_campaign/fc_tracker_replay.py --arm $ARM --root $FR/data/datasets/external/visdrone_mot --cache-root $A/p125_shared_detector_cache --out-root $T --sequence $SEQ --split val > $T/$ARM.log 2>&1 || python3 /home/francisco/Desktop/Thesis-Code-tim-vnext2/tools/experiments/final_campaign/fc_tracker_replay.py --arm $ARM --root $FR/data/datasets/external/visdrone_mot --cache-root $A/p125_shared_detector_cache --out-root $T --sequence $SEQ --split train >> $T/$ARM.log 2>&1
done
python3 - <<PY
import json, glob
for arm in ("bytetrack_raw","sort_raw","ocsort_raw","deepsort_raw"):
    new = glob.glob("$T/%s/*/$SEQ.json" % arm); old = glob.glob("$A/p125_raw_tracker_replay/%s/*/$SEQ.json" % arm)
    if not new or not old: print(arm, "missing", new, old); continue
    a = json.load(open(new[0]))["frames"]; b = json.load(open(old[0]))["frames"]
    same = a == b; print(arm, "frames", len(a), "identical to the stored frozen replay:", same)
PY
