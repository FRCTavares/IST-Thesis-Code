#!/usr/bin/env python3
"""Per-dataset GT-only audit + episode manifest for the CVAT datasets, using the UNMODIFIED frozen audit and its eligibility rules (selection height >= 20 px, >= 30 target-present frames,
truncation/occlusion <= 1, 10-frame initialisation window, earliest eligible frame). One episode per dataset: the declared physical target (identity 1). Flights: the declared initialisation point is the
start of the existing `selected_guided_frames` window (operator target selection), not the earliest eligible frame; the episode fields are recomputed from the annotation by the same formulas.
Usage: fc_manifest.py <dataset_id> ..."""
import hashlib, json, sys
from pathlib import Path
FR = Path.home() / "Desktop/Thesis-Code-frozen-issue125"; sys.path.insert(0, str(FR / "tools/issues/p125"))
import audit_visdrone_selected_person_corpus as A
from build_visdrone_gt_only_episode_manifest import load_audit
FC = Path.home() / "final_campaign_20261003"
def run(ds):
    root = FC / "shaped" / ds; cfg = A.EligibilityConfig(); rep = A.audit_split(root, split="val", config=cfg)
    (FC / "audit").mkdir(exist_ok=True); ap = FC / "audit" / f"{ds}_gt_only_audit.json"; ap.write_text(json.dumps(rep, indent=2, sort_keys=True) + "\n")
    audit, sha = load_audit(ap, "val")
    cands = [e for e in audit["episode_candidates"] if e["dataset_identity"] == 1]
    meta = json.load(open(FC / "meta" / f"{ds}.json")); seq = audit["sequence_reports"][0]
    eps = []
    if meta["group"] == "flights":
        sel = meta["selected_guided_frames_1based"][0][0]; rows = [r for r in A.load_sequence_rows(split="val", sequence_name=ds, annotation_path=root / "val/annotations" / f"{ds}.txt", image_width=seq["source"]["image_width"], image_height=seq["source"]["image_height"]) if int(r.identity) == 1]
        rows.sort(key=lambda r: r.normalized_frame_index); idx = {int(r.normalized_frame_index): r for r in rows}; s0 = sel - 1
        if s0 not in idx or not A._selection_annotation_is_eligible(idx[s0], cfg): raise SystemExit(f"{ds}: target not eligible at the declared selection frame {sel}")
        rem = [r for r in rows if r.normalized_frame_index >= s0]; last = max(int(r.normalized_frame_index) for r in rows)
        eps = [{"split": "val", "sequence_name": ds, "dataset_identity": 1, "selection_frame_index": s0, "initialization_end_frame_inclusive": min(s0 + cfg.initialization_window_frames - 1, seq["frame_domain"]["maximum_annotation_frame"]),
                "target_present_frames_from_selection": len(rem), "selection_bbox_height_px": A.bbox_height(idx[s0]), "selection_truncation": idx[s0].truncation, "selection_occlusion": idx[s0].occlusion, "selection_rule": "declared operator selection = start of selected_guided_frames", "primary": True}]
    else:
        if not cands: raise SystemExit(f"{ds}: the target has no eligible episode under the frozen rules")
        # every eligible identity is an episode (frozen rule); identity 1 (the declared physical target) is the PRIMARY episode, the others are the secondary all-identities cohort
        eps = [dict(e, selection_rule="earliest eligible frame (frozen rule)", primary=(e["dataset_identity"] == 1)) for e in audit["episode_candidates"]]
    inv = [{"split": "val", "sequence_name": s["sequence_name"], "image_frame_count": s["frame_domain"]["image_frame_count"], "annotation_frame_count": s["frame_domain"]["annotation_frame_count"], "first_source_frame": s["frame_domain"]["minimum_image_frame"],
            "last_source_frame": s["frame_domain"]["maximum_image_frame"], "image_frames_without_gt_rows": s["frame_domain"]["image_only_frames"], "annotation_sha256": s["source"]["annotation_sha256"], "image_width": s["source"]["image_width"], "image_height": s["source"]["image_height"]} for s in audit["sequence_reports"]]
    man = {"schema": "p125_visdrone_gt_only_episode_manifest_v1", "status": "draft_not_frozen", "dataset": "final_campaign:" + ds, "eligibility_config": audit["eligibility_config"], "source_audits": {"val": {"sha256": sha, "totals": audit["totals"]}},
           "sequence_count": 1, "pedestrian_identity_count": audit["totals"]["pedestrian_identities"], "episode_candidate_count": len(eps), "sequence_inventory": inv, "image_frames_without_gt_rows": [], "episodes": eps,
           "all_eligible_identity_candidates_in_audit": len(audit["episode_candidates"])}
    mp = FC / "audit" / f"{ds}_episode_manifest.json"; mp.write_text(json.dumps(man, indent=2, sort_keys=True) + "\n")
    print(ds, "episodes", len(eps), "primary", {k: [e for e in eps if e["primary"]][0][k] for k in ("selection_frame_index", "target_present_frames_from_selection", "selection_bbox_height_px", "selection_occlusion")}, "audit candidates", len(audit["episode_candidates"]), hashlib.sha256(mp.read_bytes()).hexdigest()[:12])
for d in sys.argv[1:]: run(d)
