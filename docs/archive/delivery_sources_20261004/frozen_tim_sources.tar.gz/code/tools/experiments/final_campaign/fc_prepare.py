#!/usr/bin/env python3
"""Final campaign (3 Oct 2026): frame acquisition + ground-truth conversion for the annotated CVAT datasets (May, June seq01/03/04, H01-H03, P064 gate2 HD, Flights 1-3).
Frames: the exact CVAT PNG frames (existing image zips) or, where no image archive survives, a deterministic re-extraction from the source bag verified against the frame manifest
(count and every source timestamp). Ground truth: the completed CVAT exports unchanged -> VisDrone-MOT-shaped rows (target=1, distractors 2..; occluded boxes dropped as in the qualified
physical reference v2 `allow_occluded_geometry: false`). Everything is read-only with respect to the Mac bundle, the flight checkout and the recordings. Writes ~/final_campaign_20261003/{frames,shaped,meta}."""
import csv, hashlib, json, os, re, sys, zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
H = Path.home(); FC = H / "final_campaign_20261003"; B = FC / "mac_bundle/datasets"; TC = H / "Desktop/Thesis-Code"
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""): h.update(c)
    return h.hexdigest()
D = {
 "may_hard_reentry": dict(group="development", mac="development/dev_may_hard_reentry", ann="dev_may_hard_reentry_annotations_cvat_images_1_1_20260826.zip", frames=("zip", TC / "data/datasets/processed/cvat/physical_reference/dev_may_hard_reentry/dev_may_hard_reentry_cvat_images.zip"), size=(640, 640)),
 "june_seq01": dict(group="june", mac="sequences/seq01", ann="seq01_completed_cvat_1_1.zip", frames=("zip", TC / "data/datasets/processed/cvat/physical_reference/june_seq01_clean/june_seq01_clean_cvat_images.zip"), size=(640, 480)),
 "june_seq03": dict(group="june", mac="sequences/seq03_crossing_ambiguity", ann="june_seq03_crossing_ambiguity_completed_cvat_images_1_1_20260828.zip", frames=("bag", None), size=(640, 480)),
 "june_seq04": dict(group="june", mac="sequences/seq04_occlusion_no_exit", ann="june_seq04_occlusion_no_exit_annotations_cvat_images_1_1_20260828.zip", frames=("bag", None), size=(640, 480)),
 "h01_exit_reentry": dict(group="heldout", mac="heldout/h01_exit_reentry", ann="heldout_h01_exit_reentry_cvat_for_images_1_1_raw.zip", frames=("bag", None), size=(640, 480)),
 "h02_crossing": dict(group="heldout", mac="heldout/h02_crossing", ann="heldout_h02_crossing_cvat_for_images_1_1_raw.zip", frames=("bag", None), size=(640, 480)),
 "h03_occlusion_distractor": dict(group="heldout", mac="heldout/h03_occlusion_distractor", ann="heldout_h03_occlusion_distractor_cvat_for_images_1_1_raw.zip", frames=("bag", None), size=(640, 480)),
 "p064_gate2_hd": dict(group="gates", mac="gates/p064_gate2_hd_master_r3", ann="p064_gate2_hd_master_r3_completed_cvat_images_1_1_corrected_20260827.zip", frames=("bag", None), size=(1280, 720)),
 "flight_1_baseline_a": dict(group="flights", mac="flights_20261002/flight_1_baseline_a", ann="../flight_1_baseline_a_annotations.zip", frames=("zip", B / "flights_20261002/flight_1_baseline_a_images.zip"), size=(640, 480)),
 "flight_2_candidate": dict(group="flights", mac="flights_20261002/flight_2_candidate", ann="../flight_2_candidate_annotations.zip", frames=("zip", B / "flights_20261002/flight_2_candidate_images.zip"), size=(640, 480)),
 "flight_3_baseline_b": dict(group="flights", mac="flights_20261002/flight_3_baseline_b", ann="../flight_3_baseline_b_annotations.zip", frames=("zip", B / "flights_20261002/flight_3_baseline_b_images.zip"), size=(640, 480)),
}
def manifest_rows(m):
    fr = m["frames"]; out = []
    for i, r in enumerate(fr):
        if "video_pts_seconds" in r: t = int(round(float(r["video_pts_seconds"]) * 1e9)); src = None
        else: t = int(r["bag_relative_timestamp_ns"]); src = r.get("source_timestamp_ns")
        out.append({"i": int(r.get("cvat_frame", r.get("cvat_frame_index", i))), "name": r.get("filename", r.get("media_filename")), "t_ns": t, "src_ts": src, "w": r.get("width"), "h": r.get("height")})
    return out
def regen_from_bag(ds, spec, m, out_images):
    sys.path[:0] = []
    import cv2, rosbag2_py
    from rclpy.serialization import deserialize_message
    from rosidl_runtime_py.utilities import get_message
    prep_path = B / spec["mac"] / "preparation_config.json"; prep = json.load(open(prep_path)) if prep_path.exists() else {}
    bagrel = m.get("source_bag_path") or prep["source_bag_path"]; bag = TC / bagrel
    topic = prep.get("source_image_topic", "/camera/image_raw"); win = prep.get("evaluation_window") or m.get("evaluation_window"); origin = prep.get("source_time_origin_ns") or m.get("source_time_origin_ns")
    rd = rosbag2_py.SequentialReader(); rd.open(rosbag2_py.StorageOptions(uri=str(bag), storage_id="mcap"), rosbag2_py.ConverterOptions("cdr", "cdr"))
    types = {x.name: x.type for x in rd.get_all_topics_and_types()}; cls = get_message(types[topic]); rows = []; first = None
    st = en = None
    if win and origin: st = origin + round(float(win["start_s"]) * 1e9); en = origin + round(float(win["end_s"]) * 1e9)
    while rd.has_next():
        tp, raw, rec = rd.read_next()
        if tp != topic: continue
        msg = deserialize_message(raw, cls); s = msg.header.stamp; header = int(s.sec) * 10**9 + int(s.nanosec); ts = header or int(rec); first = ts if first is None else first
        if st is not None and (ts < st or ts > en): continue
        enc = msg.encoding; a = __import__("numpy").frombuffer(bytes(msg.data), dtype="uint8").reshape(msg.height, msg.width, -1)
        im = a[:, :, ::-1] if enc == "rgb8" else a
        assert enc in ("bgr8", "rgb8"), enc
        i = len(rows); cv2.imwrite(str(out_images / f"frame_{i:06d}.png"), __import__("numpy").ascontiguousarray(im), [cv2.IMWRITE_PNG_COMPRESSION, 3]); rows.append(ts)
    want = [r["src_ts"] for r in manifest_rows(m)]
    ok = len(rows) == len(want) and all(int(a) == int(b) for a, b in zip(rows, want) if b is not None)
    return ok, len(rows), len(want)
def parse_xml(path):
    root = ET.parse(path).getroot(); frames = {}
    for im in root.findall("image"):
        i = int(im.get("id")); rows = []
        for b in im.findall("box"):
            lab = b.get("label"); ref = None
            for a in b.findall("attribute"):
                if a.get("name") == "physical_ref": ref = (a.text or "").strip()
            role = ref if ref else lab
            rows.append((role, float(b.get("xtl")), float(b.get("ytl")), float(b.get("xbr")), float(b.get("ybr")), int(b.get("occluded", "0"))))
        frames[i] = rows
    return frames, {"w": root.find("image").get("width"), "h": root.find("image").get("height"), "n": len(frames)}
def role_id(role):
    if role == "target": return 1
    m = re.search(r"(\d+)$", role)
    return (int(m.group(1)) + 1) if m else 99
def main(only=None):
    reg = {}
    for ds, spec in D.items():
        if only and ds not in only: continue
        mac = B / spec["mac"]
        if (mac / "frame_manifest.json").exists(): m = json.load(open(mac / "frame_manifest.json")); rows = manifest_rows(m)
        else:   # May: no frame manifest survives; rows from the source bag image timestamps (header stamp, else record), in message order
            import rosbag2_py
            prep = json.load(open(mac / "preparation_config.json")); rd = rosbag2_py.SequentialReader(); rd.open(rosbag2_py.StorageOptions(uri=str(TC / prep["source_bag_path"]), storage_id="mcap"), rosbag2_py.ConverterOptions("cdr", "cdr"))
            from rclpy.serialization import deserialize_message
            from rosidl_runtime_py.utilities import get_message
            types = {x.name: x.type for x in rd.get_all_topics_and_types()}; cls = get_message(types[prep["source_image_topic"]]); ts = []
            while rd.has_next():
                tp, raw, rec = rd.read_next()
                if tp == prep["source_image_topic"]:
                    st = deserialize_message(raw, cls).header.stamp; hd = int(st.sec) * 10**9 + int(st.nanosec); ts.append(hd or int(rec))
            m = {"frames": [{"cvat_frame_index": i, "media_filename": f"frame_{i:06d}.png", "bag_relative_timestamp_ns": t - ts[0], "source_timestamp_ns": t, "width": prep["source_width"], "height": prep["source_height"]} for i, t in enumerate(ts)], "source_bag_path": prep["source_bag_path"]}
            rows = manifest_rows(m)
        n = len(rows)
        fdir = FC / "frames" / ds / "images"; sdir = FC / "shaped" / ds / "val" / "sequences" / ds; adir = FC / "shaped" / ds / "val" / "annotations"; (FC / "meta").mkdir(parents=True, exist_ok=True)
        info = {"dataset": ds, "frame_manifest_sha256": sha(mac / "frame_manifest.json") if (mac / "frame_manifest.json").exists() else "derived_from_bag_timestamps", "frames": n, "size": spec["size"]}
        if not (fdir.exists() and len(list(fdir.glob("*.png"))) == n):
            fdir.mkdir(parents=True, exist_ok=True)
            if spec["frames"][0] == "zip":
                with zipfile.ZipFile(spec["frames"][1]) as z:
                    names = sorted(x for x in z.namelist() if x.lower().endswith(".png")); assert len(names) == n, (len(names), n)
                    for x in names: (fdir / os.path.basename(x)).write_bytes(z.read(x))
                info["frame_source"] = {"kind": "cvat_image_zip", "path": str(spec["frames"][1]), "sha256": sha(spec["frames"][1])}
            else:
                ok, got, want = regen_from_bag(ds, spec, m, fdir); info["frame_source"] = {"kind": "bag_reextraction", "verified_against_manifest_timestamps": ok, "frames": got, "manifest_frames": want}
                if not ok: raise SystemExit(f"{ds}: re-extraction does not match the frame manifest ({got} vs {want})")
        else: info["frame_source"] = {"kind": "already_extracted"}
        # shaped sequence dir (symlinks, 1-based 7-digit)
        sdir.mkdir(parents=True, exist_ok=True); adir.mkdir(parents=True, exist_ok=True)
        for r in rows:
            link = sdir / f"{r['i'] + 1:07d}.png"
            if not link.exists(): link.symlink_to(fdir / r["name"])
        ann = mac / spec["ann"]; xml_path = FC / "frames" / ds / "annotations.xml"
        with zipfile.ZipFile(ann) as z: xml_path.write_bytes(z.read("annotations.xml"))
        info["annotation_zip_sha256"] = sha(ann); frames_gt, xinfo = parse_xml(xml_path); info["xml"] = xinfo
        assert xinfo["n"] == n, (xinfo, n)
        occ = drop = 0; roles = {}; cnt = 0
        with open(adir / f"{ds}.txt", "w") as out:
            for i in sorted(frames_gt):
                for role, x1, y1, x2, y2, o in frames_gt[i]:
                    roles[role] = roles.get(role, 0) + 1
                    if o: occ += 1; continue
                    out.write(f"{i + 1},{role_id(role)},{x1:.4f},{y1:.4f},{x2 - x1:.4f},{y2 - y1:.4f},1,1,0,0\n"); cnt += 1
        info["gt"] = {"rows_written": cnt, "occluded_boxes_dropped": occ, "boxes_by_role": roles, "role_ids": {r: role_id(r) for r in roles}}
        # metadata: stamps, absence, windows
        meta = {"dataset": ds, "group": spec["group"], "frames": n, "size": spec["size"], "stamps_ns": {str(r["i"] + 1): r["t_ns"] + 1_000_000_000 for r in rows}, "stamp_basis": ("video packet PTS (not camera source time)" if "video_pts_seconds" in m["frames"][0] else "bag header/record timestamps relative to first frame")}
        cfgp = mac / ("conversion_config_reviewed.json" if (mac / "conversion_config_reviewed.json").exists() else "conversion_config.json"); cfg = json.load(open(cfgp)) if cfgp.exists() else {}
        sem = cfg.get("semantic_intervals") or []; meta["confirmed_absent_frames_1based"] = [[a["start_frame"] + 1, a["end_frame"] + 1] for a in sem if a.get("identity_state") == "absent"]
        meta["semantic_intervals_source"] = str(cfgp.relative_to(B)) if cfgp.exists() else None
        if spec["group"] == "flights":
            ev = mac / "evaluation_20261003"; w = json.load(open(ev / "flight_windows.json")); cs = json.load(open(ev / "completion_status.json")); hr = json.load(open(ev / "human_review_addendum.json")) if (ev / "human_review_addendum.json").exists() else {}
            meta["selected_guided_frames_1based"] = [[a + 1, b + 1] for a, b in w["selected_guided_frames"]]; meta["conditional_armed_frames_1based"] = [[a + 1, b + 1] for a, b in w["conditional_packet_receipt_armed_frames"]]
            ca = cs.get("confirmed_absent_frames") or hr.get("confirmed_target_absent_interval") or []
            meta["confirmed_absent_frames_1based"] = [[ca[0] + 1, ca[1] + 1]] if ca else []
            meta["window_qualification"] = w["qualification"]; meta["evaluation_package_sha256"] = {f.name: sha(f) for f in sorted(ev.glob("*.json"))}
        json.dump(meta, open(FC / "meta" / f"{ds}.json", "w")); info["meta"] = {k: meta[k] for k in meta if k != "stamps_ns"}; reg[ds] = info
        print(ds, n, "frames; rows", cnt, "occluded dropped", occ, "frame source", info["frame_source"]["kind"], info["frame_source"].get("verified_against_manifest_timestamps", ""))
    old = json.load(open(FC / "registry_prepare.json")) if (FC / "registry_prepare.json").exists() else {}; old.update(reg); json.dump(old, open(FC / "registry_prepare.json", "w"), indent=1, default=str)
if __name__ == "__main__": main(sys.argv[1:] or None)
