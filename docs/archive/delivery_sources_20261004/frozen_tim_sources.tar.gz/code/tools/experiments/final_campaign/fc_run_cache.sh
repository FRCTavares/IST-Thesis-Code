#!/bin/bash
# Shared detector cache (frozen YOLOv8s HEF, direct Hailo engine, frozen preprocessing/filter) for the final-campaign CVAT datasets; sequential (one Hailo device); stops on throttling or low disk.
FC=/home/francisco/final_campaign_20261003; X=/home/francisco/Desktop/Thesis-Code-tim-vnext2/tools/experiments/final_campaign/fc_frozen_exec.py; mkdir -p $FC/logs
source /opt/ros/jazzy/setup.bash; source /home/francisco/Desktop/Thesis-Code-frozen-issue125/ros2_ws/install/setup.bash 2>/dev/null
export OMP_NUM_THREADS=1 PYTHONPATH=/home/francisco/Desktop/Thesis-Code-frozen-issue125/ros2_ws/src/thesis_bringup:$PYTHONPATH
for DS in "$@"; do
  [ -f $FC/cache/$DS/val/$DS.json ] && { echo "$(date +%H:%M:%S) $DS cached" >> $FC/logs/cache_progress.log; continue; }
  T=$(vcgencmd get_throttled); case "$T" in *0x0) ;; *) echo "STOP throttled $T" >> $FC/logs/cache_progress.log; exit 3;; esac
  FREE=$(df --output=avail -B1 / | tail -1); [ "$FREE" -lt $((6*1024*1024*1024)) ] && { echo "STOP disk" >> $FC/logs/cache_progress.log; exit 4; }
  FC_MANIFEST=$FC/audit/${DS}_episode_manifest.json python3 $X write_shared_detector_cache.py x -- --split val --sequence $DS --dataset-root $FC/shaped/$DS --output-root $FC/cache/$DS > $FC/logs/cache_$DS.log 2>&1
  echo "$(date +%H:%M:%S) $DS exit=$? $(tail -1 $FC/logs/cache_$DS.log | cut -c1-160)" >> $FC/logs/cache_progress.log
done
echo CACHE_DONE >> $FC/logs/cache_progress.log
