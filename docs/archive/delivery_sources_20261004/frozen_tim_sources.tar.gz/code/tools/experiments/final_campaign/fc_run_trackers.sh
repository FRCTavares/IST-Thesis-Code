#!/bin/bash
# Raw tracker replays (6 arms incl. BoT-SORT) on cached detections; usage: fc_run_trackers.sh <stamp-mode:meta|nominal> <root-dir> <dataset-or-sequence-list-file> ; 3 parallel jobs; stops on throttling.
# list file lines: "<dataset_id> <sequence> <shaped_root> <cache_root> <out_root> [stamps_json]"
FC=/home/francisco/final_campaign_20261003; X=/home/francisco/Desktop/Thesis-Code-tim-vnext2/tools/experiments/final_campaign/fc_tracker_replay.py; mkdir -p $FC/logs
source /opt/ros/jazzy/setup.bash; source /home/francisco/Desktop/Thesis-Code-frozen-issue125/ros2_ws/install/setup.bash 2>/dev/null
export OMP_NUM_THREADS=1 TF_NUM_INTRAOP_THREADS=1 TF_NUM_INTEROP_THREADS=1 TF_CPP_MIN_LOG_LEVEL=3 YOLO_AUTOINSTALL=False
export FC X
job() { ARM=$1; DS=$2; SEQ=$3; ROOT=$4; CACHE=$5; OUT=$6; ST=$7
  T=$(vcgencmd get_throttled); case "$T" in *0x0) ;; *) echo "STOP throttled $T $ARM $SEQ" >> $FC/logs/tracker_progress.log; return 3;; esac
  [ -f $OUT/$ARM/val/$SEQ.json ] && { echo "$(date +%H:%M:%S) $ARM $DS/$SEQ exists" >> $FC/logs/tracker_progress.log; return 0; }
  python3 $X --arm $ARM --root $ROOT --cache-root $CACHE --out-root $OUT --sequence $SEQ ${ST:+--stamps $ST} > $FC/logs/trk_${ARM}_${SEQ}.log 2>&1; echo "$(date +%H:%M:%S) $ARM $DS/$SEQ exit=$?" >> $FC/logs/tracker_progress.log; }
export -f job
LIST=$1; ARMS=${2:-"bytetrack_raw sort_raw ocsort_raw botsort_raw deepsort_raw"}
for A in $ARMS; do while read DS SEQ ROOT CACHE OUT ST; do echo "$A $DS $SEQ $ROOT $CACHE $OUT $ST"; done < $LIST; done | xargs -P 3 -L1 bash -c 'job "$@"' _
echo "TRACKERS_DONE $(basename $LIST)" >> $FC/logs/tracker_progress.log
