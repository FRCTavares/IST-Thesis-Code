#!/usr/bin/env python3
"""Development-only probe: independent RGB visual track of the selected person.

While the raw ByteTrack selected ID is silent, propagate the last published box with sparse
Lucas-Kanade optical flow on the person, using background camera-motion compensation
(RANSAC partial-affine fit on features outside all tracked persons). Coasting on camera motion
plus the last relative velocity is allowed only for a short, bounded time. The visual track
never re-enters any appearance memory; it only bridges detector/tracker dropouts.

Reads frozen #125 inputs from the main checkout (read-only) and writes only to --output-root.
Results are exploratory development evidence, not part of the frozen benchmark.
"""
import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path

import cv2
import numpy as np

cv2.setNumThreads(1)

MAIN = Path("/home/francisco/Desktop/Thesis-Code")
sys.path.insert(0, str(MAIN / "tools/issues/p125"))
sys.path.insert(0, str(MAIN / "tools/analysis"))

from audit_visdrone_selected_person_corpus import load_sequence_rows  # noqa: E402
from controller_output_adapter import observation_maps, ControllerObservation  # noqa: E402
from evaluate_visdrone_selected_person import AttributionConfig, evaluate_episode  # noqa: E402
from resolve_episode_initialization import raw_authority_maps, resolve_initialization  # noqa: E402
from score_raw_tracker_sequence import validate_raw_replay  # noqa: E402
from shared_detector_cache import read_committed_frozen_inputs  # noqa: E402
from write_raw_tracker_replay import ARM_CONFIGS, sha256_file  # noqa: E402
from write_shared_detector_cache import image_paths_by_source_frame  # noqa: E402

from visual_track_bridge import (  # noqa: E402
    COAST_MAX, LK, MAX_AGE, apply_affine, box_mask, bridged_maps, camera_motion, gray,
    lk_forward_backward, person_features, simulate_bridge)

VARIANT_SPECS = {
    "flow15": (15, False),
    "flow30": (30, False),
    "flow60": (60, False),
    "flow30c": (30, True),
}
BASES = ("raw", "fg2")
FG2_ROOT = Path("/home/francisco/tim_vnext_runs/results_v2/vFG2x")


def load_fg2(split, seq):
    path = FG2_ROOT / split / f"{seq}.json"
    if not path.exists():
        raise FileNotFoundError(f"FG2 base outputs missing: {path}")
    out = {}
    for e in json.loads(path.read_text())["episodes"]:
        if e["initialization"]["success"]:
            ep = e["episode"]
            out[(int(ep["dataset_identity"]), int(ep["selection_frame_index"]))] = {
                int(k): v for k, v in e["dev"]["outputs"].items()}
    return out


def main():
    cv2.setNumThreads(1)
    ap = argparse.ArgumentParser()
    ap.add_argument("--output-root", type=Path, required=True)
    ap.add_argument("--sequences-file", type=Path, required=True)
    ap.add_argument("--shard", default="0/1")
    ap.add_argument("--bases", default="raw,fg2")
    a = ap.parse_args()
    bases = [b for b in a.bases.split(",") if b]
    names = [f"{b}_{v}" for b in bases for v in VARIANT_SPECS]
    frozen = read_committed_frozen_inputs(
        repository_root=MAIN,
        protocol_path=MAIN / "docs/data/external_benchmark_v2/visdrone_selected_person_protocol_v1.json",
        manifest_path=MAIN / "docs/data/external_benchmark_v2/visdrone_gt_only_episode_manifest_v1.json")
    protocol, manifest = frozen["protocol"], frozen["manifest"]
    hashes = protocol["pre_result_implementation_hashes_draft"]
    si, sn = map(int, a.shard.split("/"))
    todo = [l.split()[:2] for l in open(a.sequences_file) if l.strip()][si::sn]
    for split, seq in todo:
        if all((a.output_root / n / split / f"{seq}.json").exists() for n in names):
            continue
        entry = [e for e in manifest["sequence_inventory"] if e["split"] == split and e["sequence_name"] == seq][0]
        root = MAIN / "data/datasets/external/visdrone_mot"
        image_paths = image_paths_by_source_frame(root / split / "sequences" / seq)
        nums = sorted(image_paths)
        cache = MAIN / "artifacts/reports/p125_shared_detector_cache" / split / f"{seq}.json"
        rp = MAIN / "artifacts/reports/p125_raw_tracker_replay/bytetrack_raw" / split / f"{seq}.json"
        frames = validate_raw_replay(
            json.loads(rp.read_text()), arm="bytetrack_raw", split=split, sequence_name=seq,
            source_frame_numbers=nums, protocol_sha256=frozen["protocol_sha256"],
            manifest_sha256=frozen["manifest_sha256"], freeze_commit=frozen["freeze_commit"],
            detector_cache_sha256=sha256_file(cache), tracker_config_sha256=hashes[ARM_CONFIGS["bytetrack_raw"]])
        rows = load_sequence_rows(split=split, sequence_name=seq, annotation_path=root / split / "annotations" / f"{seq}.txt",
                                  image_width=int(entry["image_width"]), image_height=int(entry["image_height"]))
        src_frames = [int(f["normalized_frame_index"]) for f in frames]
        cache_imgs = {}

        def images(i):
            if i not in cache_imgs:
                if len(cache_imgs) > 6:
                    cache_imgs.pop(next(iter(cache_imgs)))
                cache_imgs[i] = cv2.imread(str(image_paths[int(frames[i]["source_frame_number"])]), cv2.IMREAD_COLOR)
            return cache_imgs[i]

        def others(i):
            return [t["bbox_xyxy"] for t in frames[i]["tracks"]]

        fg2 = load_fg2(split, seq) if "fg2" in bases else None
        results = {n: [] for n in names}
        episodes = [e for e in manifest["episodes"] if e["split"] == split and e["sequence_name"] == seq]
        for ep in episodes:
            init = resolve_initialization(
                episode=ep, gt_rows=rows, tracker_frames=frames,
                minimum_match_iou=float(protocol["initialization_draft"]["minimum_match_iou"]),
                minimum_match_margin=float(protocol["initialization_draft"]["minimum_match_margin"]),
                confirmation_frames=int(protocol["initialization_draft"]["confirmation_frames"]))
            raw_boxes, raw_ids = raw_authority_maps(tracker_frames=frames, initialization=init)
            for base in bases:
                if base == "raw" or not init.success:
                    boxes0, ids0 = raw_boxes, raw_ids
                else:
                    out = fg2[(int(ep["dataset_identity"]), int(ep["selection_frame_index"]))]
                    boxes0 = {fi: (tuple(out[fi][:4]) if out.get(fi) else None) for fi in src_frames}
                    ids0 = {fi: (int(out[fi][4]) if out.get(fi) else None) for fi in src_frames}
                runs = []
                if init.success:
                    targets = [int(r.normalized_frame_index) for r in rows
                               if int(r.identity) == int(ep["dataset_identity"]) and r.include_as_person_candidate
                               and int(r.normalized_frame_index) >= int(ep["selection_frame_index"])]
                    last_target = max(targets)
                    prev_pub = None
                    i = 0
                    while i < len(frames):
                        fi = src_frames[i]
                        if fi > last_target:
                            break
                        if boxes0.get(fi) is not None:
                            prev_pub = i
                        elif prev_pub is not None and fi >= int(ep["selection_frame_index"]):
                            run_tid = ids0[src_frames[prev_pub]]
                            run = simulate_bridge(images, frames, prev_pub, boxes0[src_frames[prev_pub]], others)
                            cut = []
                            for pos, box, mode in run:
                                if boxes0.get(src_frames[pos]) is not None or src_frames[pos] > last_target:
                                    break
                                cut.append((pos, box, mode))
                            if cut:
                                runs.append((run_tid, cut))
                            j = i
                            while j < len(frames) and boxes0.get(src_frames[j]) is None:
                                j += 1
                            i = j
                            continue
                        i += 1
                for vname, (max_age, allow_coast) in VARIANT_SPECS.items():
                    if init.success:
                        boxes, ids, modes = bridged_maps(frames, boxes0, ids0, runs, max_age, allow_coast)
                    else:
                        boxes, ids, modes = boxes0, ids0, {}
                    evaluation = evaluate_episode(
                        split=split, sequence_name=seq, dataset_identity=int(ep["dataset_identity"]),
                        selection_frame_index=int(ep["selection_frame_index"]), source_frame_indices=src_frames,
                        gt_rows=rows, output_bboxes_by_frame=boxes, output_tracker_ids_by_frame=ids,
                        config=AttributionConfig(
                            person_iou_threshold=float(protocol["evaluation_draft"]["target_iou_threshold"]),
                            unique_iou_margin=float(protocol["evaluation_draft"]["unique_iou_margin"]),
                            ambiguous_region_output_coverage=float(
                                protocol["evaluation_draft"]["ambiguous_region_output_coverage_threshold"])))
                    results[f"{base}_{vname}"].append({
                        "episode": ep, "initialization": asdict(init), "evaluation": evaluation,
                        "bridged": {str(k): v for k, v in modes.items()}})
        for n in names:
            out_path = a.output_root / n / split / f"{seq}.json"
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(json.dumps({"variant": n, "split": split, "sequence_name": seq, "episodes": results[n]}))
        print("done", seq, flush=True)


if __name__ == "__main__":
    main()
