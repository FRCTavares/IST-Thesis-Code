#!/usr/bin/env python3
"""Read-only candidate-scoring trace of the UNMODIFIED pinned pipeline (in-memory hooks only; the replay must reproduce the saved outputs exactly).
Logs, per TIM output decision, the reason and TIM's own scored candidate list (geometry, appearance vs anchor/gallery, ranking) so rejected candidates can be labelled against ground truth AFTERWARDS (analysis only).
Env: OV_TRACE=path.jsonl, OV_ARM (default sync_rec). Usage: ov_trace_pipeline.py <pipeline args>"""
import json, os, sys
from pathlib import Path
EXP = Path.home() / "Desktop/Thesis-Code-tim-vnext2/tools/experiments"
sys.path.insert(0, str(EXP)); sys.path.insert(0, str(EXP.parent / "confirmation_testdev"))
import frozen_root_patch  # path-only in-memory substitution (FROZEN_ROOT); no pinned file is edited
frozen_root_patch.install()
path = EXP / "p125_candidate_pipeline.py"; text = path.read_text()
if os.environ.get("OV_D2"):   # exploratory derived-manifest cohort (D2): in-memory pass-through of the frozen-input hash checks only
    S1 = "frozen = read_committed_frozen_inputs(repository_root=a.repository_root, protocol_path=a.protocol, manifest_path=a.manifest)"
    S2 = "frames = validate_raw_replay("
    assert text.count(S1) == 1 and text.count(S2) == 1
    text = text.replace(S1, 'frozen = {"protocol": json.loads(a.protocol.read_text()), "manifest": json.loads(a.manifest.read_text()), "protocol_sha256": "d2", "manifest_sha256": "d2", "freeze_commit": "d2"}')
    text = text.replace(S2, "frames = _d2_passthrough(")
    text = text.replace("def main():", "def _d2_passthrough(replay, **kw):\n    return replay[\"frames\"]\n\n\ndef main():", 1)
ANCHOR = "PositiveAppearanceMemory.update_trusted = _counting_update_trusted\n"
assert text.count(ANCHOR) == 1
text = text.replace(ANCHOR, ANCHOR + "OV_INSTALL()\n")
TRACE = open(os.environ["OV_TRACE"], "a", buffering=1); ST = {"ord": 0, "frame_id": None}
def emit(**kw): TRACE.write(json.dumps(kw, default=float) + "\n")
def cand(s):
    g = lambda k: getattr(s, k, None)
    return {"id": int(s.track_id), "iou": g("iou"), "dist": g("distance"), "geom": g("geometry_score"), "rank": g("ranking_score"), "idb": g("id_bonus"), "app": g("appearance_raw"), "app_av": g("appearance_available"),
            "anchor": g("protected_anchor_similarity"), "gal": g("trusted_gallery_similarity"), "adapt": g("adaptive_similarity"), "pos": g("positive_similarity"), "src": g("positive_support_source"), "hn": g("hard_negative_reject")}
def install():
    from thesis_bringup.tim_mars.target_memory import TargetIdentityMemory as T
    o_sel, o_up, o_mk = T.select, T.update, T._make_output
    def select(self, track, **kw):
        ST["ord"] = 1; out = o_sel(self, track, **kw); emit(ev="select", ord=1, track_id=int(track.track_id), frame_id=kw.get("frame_id")); return out
    def update(self, candidates, **kw):
        ST["ord"] += 1; ST["frame_id"] = kw.get("frame_id"); ST["cands"] = [(int(c.track_id), tuple(c.bbox)) for c in candidates]; return o_up(self, candidates, **kw)
    def mk(self, *, reason, visible, reacquired, best_score=None, all_scores=None, **kw):
        r = o_mk(self, reason=reason, visible=visible, reacquired=reacquired, best_score=best_score, all_scores=all_scores, **kw)
        full = not (visible and reason in ("accepted_candidate",))
        rec = {"ev": "out", "ord": ST["ord"], "reason": (reason or "")[:130], "visible": bool(visible), "reacq": bool(reacquired), "state": str(getattr(r, "state", "")), "sel": self._m.track_id,
               "best": None if best_score is None else cand(best_score), "n": len(all_scores or [])}
        bb = getattr(self._m, "bbox", None); rec["last_bbox"] = None if bb is None else [float(x) for x in bb]
        rec["frames_since_seen"] = getattr(self._m, "frames_since_seen", None)
        pm = self._positive_appearance
        rec["mem"] = {"anchor": pm.protected_anchor is not None, "gallery_n": len(pm.trusted_gallery), "adaptive": pm.adaptive_prototype is not None, "lineage_trusted": bool(pm.lineage_trusted)}
        if full: rec["cands"] = [cand(s) for s in (all_scores or [])]; rec["tracks"] = [[i, [float(x) for x in b]] for i, b in ST.get("cands", [])]
        emit(**rec); return r
    T.select, T.update, T._make_output = select, update, mk
glb = {"__name__": "__main__", "__file__": str(path), "OV_INSTALL": install}
sys.argv = [str(path)] + sys.argv[1:]
exec(compile(text, str(path), "exec"), glb)
