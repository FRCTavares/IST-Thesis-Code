"""Path-only helper shared by frozen_pipeline_runner.py and verify_freeze.py. install() replaces, in memory, the single hardcoded default-path literal of the two hash-pinned files
run_p125_tim_variant.py and run_p125_flow_bridge_probe.py by FROZEN_ROOT and registers the patched modules in sys.modules before the pinned pipeline is imported. No file is modified.
With FROZEN_ROOT unset (or equal to the default) it does nothing."""
import os
import sys
import types
from pathlib import Path

DEFAULT = "/home/francisco/Desktop/Thesis-Code"
EXP = Path(__file__).resolve().parents[1] / "experiments"
SUBS = {"run_p125_tim_variant": f'MAIN=Path("{DEFAULT}")', "run_p125_flow_bridge_probe": f'MAIN = Path("{DEFAULT}")'}


def install():
    root = os.environ.get("FROZEN_ROOT", DEFAULT)
    if str(EXP) not in sys.path:
        sys.path.insert(0, str(EXP))
    if root == DEFAULT:
        return root
    for name, anchor in SUBS.items():
        path = EXP / f"{name}.py"
        text = path.read_text()
        if text.count(anchor) != 1:
            raise SystemExit(f"{name}: path anchor not found exactly once; the pinned source changed or this helper is wrong")
        module = types.ModuleType(name)
        module.__file__ = str(path)
        sys.modules[name] = module
        exec(compile(text.replace(anchor, anchor.replace(DEFAULT, root)), str(path), "exec"), module.__dict__)
    return root
