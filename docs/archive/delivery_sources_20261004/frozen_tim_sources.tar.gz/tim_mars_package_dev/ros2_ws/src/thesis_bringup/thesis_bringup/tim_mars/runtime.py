"""Shared ROS-free processing runtime for TIM-MARS.

This module owns the deterministic conversion of tracker messages into
CandidateTrack objects, causal image selection, appearance attachment, and
TargetIdentityMemory updates.

It contains no subscriptions, publishers, timers, sleeps, or wall-clock
synchronisation. The ROS node and deterministic offline replay runner should
both delegate their algorithmic processing to this runtime.
"""

from __future__ import annotations

from bisect import bisect_right
from dataclasses import dataclass, field, replace
from typing import Any, Optional, Sequence

from thesis_bringup.tim_mars.appearance_attachment import (
    AppearanceAttachmentConfig,
    AppearanceAttachmentInput,
    AppearanceAttachmentState,
    AppearanceCacheEntry,
    AppearanceEncoder,
    attach_appearance_features,
    map_bbox_to_appearance_image,
    reconcile_appearance_track_lifecycle,
    reset_appearance_lifecycle,
)
from thesis_bringup.tim_mars.appearance_request_policy import (
    AppearanceRequestDecision,
    AppearanceRequestPolicy,
    select_appearance_request_candidates,
)
from thesis_bringup.tim_mars.appearance_request_producer import (
    AppearanceRequestCrop,
    build_appearance_request_crops,
)
from thesis_bringup.tim_mars.async_cpu_mars import (
    AsyncMarsEncoder,
    AsyncMarsJob,
)
from thesis_bringup.tim_mars.crop_quality import (
    AppearanceCropQuality,
)
from thesis_bringup.tim_mars.target_memory import (
    BBox,
    CandidateTrack,
    TargetIdentityMemory,
    TargetMemoryConfig,
    TargetMemoryOutput,
    TargetState,
)


@dataclass(frozen=True)
class TimMarsRuntimeConfig:
    """Configuration required by the shared TIM-MARS processing runtime."""

    memory: TargetMemoryConfig
    appearance: AppearanceAttachmentConfig
    image_width: float
    image_height: float
    appearance_request_policy: (
        AppearanceRequestPolicy | str
    ) = AppearanceRequestPolicy.ALL_CANDIDATES
    tracks_are_normalized: bool = False
    selected_track_id: int = 0
    auto_select_largest: bool = False
    image_buffer_size: int = 64
    appearance_async_request_crops_enabled: bool = False

    # Development-only mechanism-ablation controls. These are intentionally
    # not TargetMemoryConfig/ROS/canonical-YAML parameters.
    development_ablation_disable_forced_same_id_challenge: bool = False
    development_ablation_restore_same_id_general_negative_exemption: bool = False
    development_ablation_disable_same_id_positive_support_reject: bool = False
    development_ablation_disable_conservative_final_filter: bool = False
    development_ablation_disable_trusted_gallery_storage: bool = False
    development_ablation_disable_adaptive_positive_memory: bool = False
    development_ablation_prevent_repeated_source_adaptive_update: bool = False
    development_ablation_retire_overage_hard_negatives_pre_score: bool = False
    development_ablation_require_distinct_source_for_persistence: bool = False


@dataclass(frozen=True)
class AppearanceFrame:
    """Timestamped appearance image."""

    stamp_ns: int
    image_bgr: Any


@dataclass(frozen=True)
class TimMarsRuntimeDiagnostics:
    """Frame-level evidence correspondence and appearance diagnostics."""

    track_timestamp_ns: Optional[int]
    selected_image_timestamp_ns: Optional[int]
    image_track_offset_ms: Optional[float]
    appearance_candidates: int
    appearance_request_policy: str
    appearance_request_reason: str
    appearance_request_candidates: int
    appearance_request_track_ids: tuple[int, ...]
    appearance_request_encoding_eligible: int
    appearance_features_valid: int
    appearance_skip_reason: str
    appearance_warning: Optional[str]
    appearance_cache_size: int
    appearance_cache_lookups: int
    appearance_cache_hits: int
    appearance_cache_misses: int
    appearance_cache_expired: int
    appearance_cache_invalidated: int
    appearance_embedding_age_ms_by_track_id: dict[int, float]
    appearance_crop_quality_by_track_id: dict[
        int,
        AppearanceCropQuality,
    ]
    appearance_encoding_rejected: int
    appearance_memory_update_ineligible: int
    appearance_encoding_eligible: int
    appearance_backend_calls: int
    appearance_backend_requested: int
    appearance_backend_returned: int
    appearance_backend_valid: int
    appearance_backend_wall_ms: float
    appearance_update_cooldown_remaining: int
    candidate_track_ids: tuple[int, ...]


@dataclass(frozen=True)
class TimMarsRuntimeResult:
    """One deterministic TIM-MARS update result."""

    output: TargetMemoryOutput
    candidates: tuple[CandidateTrack, ...]
    diagnostics: TimMarsRuntimeDiagnostics
    appearance_request_crops: tuple[
        AppearanceRequestCrop,
        ...,
    ] = ()


@dataclass
class TimMarsRuntime:
    """ROS-free stateful TIM-MARS processor."""

    config: TimMarsRuntimeConfig
    mars_backend: AppearanceEncoder | None = None
    memory: TargetIdentityMemory = field(init=False)
    appearance_state: AppearanceAttachmentState = field(
        default_factory=AppearanceAttachmentState,
        init=False,
    )
    pending_select_id: Optional[int] = field(init=False)
    _images: list[AppearanceFrame] = field(default_factory=list, init=False)
    # Development, default off: bounded asynchronous CPU-MARS (see
    # async_cpu_mars.py). None means the synchronous baseline.
    async_encoder: Optional[AsyncMarsEncoder] = field(default=None, init=False)
    async_stats: dict = field(default_factory=dict, init=False)
    # "strict": a same-ID fresh challenge needs evidence from the current
    # frame, which asynchronous evidence can never be, so the challenge fails
    # (conservative, no weakening). "post_onset": evidence computed from a frame
    # at or after the frame on which the challenge arose, at most
    # async_challenge_max_age_ms old, may answer it (explicitly weaker).
    async_challenge_mode: str = field(default="strict", init=False)
    async_challenge_max_age_ms: float = field(default=200.0, init=False)
    _challenge_onset: dict = field(default_factory=dict, init=False)
    _challenge_last: dict = field(default_factory=dict, init=False)
    async_challenge_hold_ms: float = field(default=300.0, init=False)

    def enable_async_cpu_mars(
        self,
        encoder: AsyncMarsEncoder,
        challenge_mode: str = "strict",
        challenge_max_age_ms: float = 200.0,
    ) -> None:
        """Enable the asynchronous encoder (development, default off).

        Epoch invalidation is mandatory with it: a select or clear must drop the
        cache at once, never let evidence from the previous selection be reused.
        """
        if challenge_mode not in ("strict", "post_onset"):
            raise ValueError("challenge_mode must be strict or post_onset")
        self.async_challenge_mode = challenge_mode
        self.async_challenge_max_age_ms = float(challenge_max_age_ms)
        self.async_encoder = encoder
        self.async_stats = {}
        self.config = replace(
            self.config,
            appearance=replace(self.config.appearance, epoch_invalidation=True),
        )

    def __post_init__(self) -> None:
        self.memory = TargetIdentityMemory(
            self.config.memory,
            development_ablation_disable_forced_same_id_challenge=bool(
                self.config.development_ablation_disable_forced_same_id_challenge
            ),
            development_ablation_restore_same_id_general_negative_exemption=bool(
                self.config.development_ablation_restore_same_id_general_negative_exemption
            ),
            development_ablation_disable_same_id_positive_support_reject=bool(
                self.config.development_ablation_disable_same_id_positive_support_reject
            ),
            development_ablation_disable_conservative_final_filter=bool(
                self.config.development_ablation_disable_conservative_final_filter
            ),
            development_ablation_disable_trusted_gallery_storage=bool(
                self.config.development_ablation_disable_trusted_gallery_storage
            ),
            development_ablation_disable_adaptive_positive_memory=bool(
                self.config.development_ablation_disable_adaptive_positive_memory
            ),
            development_ablation_prevent_repeated_source_adaptive_update=bool(
                self.config.development_ablation_prevent_repeated_source_adaptive_update
            ),
            development_ablation_retire_overage_hard_negatives_pre_score=bool(
                self.config.development_ablation_retire_overage_hard_negatives_pre_score
            ),
            development_ablation_require_distinct_source_for_persistence=bool(
                self.config.development_ablation_require_distinct_source_for_persistence
            ),
        )
        selected_id = int(self.config.selected_track_id)
        self.pending_select_id = selected_id if selected_id > 0 else None

    @staticmethod
    def stamp_to_ns(stamp: Any) -> int:
        """Convert a ROS-style sec/nanosec timestamp to integer nanoseconds."""
        return int(stamp.sec) * 1_000_000_000 + int(stamp.nanosec)

    @classmethod
    def track_time_ns(cls, tracks_msg: Any) -> Optional[int]:
        """Resolve the trustworthy timestamp of a tracker message."""
        header = getattr(tracks_msg, "header", None)
        stamp = getattr(header, "stamp", None)

        if stamp is not None:
            header_ns = cls.stamp_to_ns(stamp)
            if header_ns > 0:
                return header_ns

        source_ns = int(getattr(tracks_msg, "src_stamp_ns", 0))
        if source_ns > 0:
            return source_ns

        return None

    def add_image(self, stamp_ns: int, image_bgr: Any) -> bool:
        """Insert or replace a timestamped image in deterministic stamp order."""
        stamp_ns = int(stamp_ns)
        if stamp_ns <= 0:
            return False

        stamps = [frame.stamp_ns for frame in self._images]
        index = bisect_right(stamps, stamp_ns)

        if index > 0 and self._images[index - 1].stamp_ns == stamp_ns:
            self._images[index - 1] = AppearanceFrame(stamp_ns, image_bgr)
        else:
            self._images.insert(index, AppearanceFrame(stamp_ns, image_bgr))

        max_size = max(1, int(self.config.image_buffer_size))
        if len(self._images) > max_size:
            self._images = self._images[-max_size:]

        return True

    def replace_images(
        self,
        images: Sequence[tuple[int, Any]],
    ) -> None:
        """Replace images with a complete deterministic offline timeline.

        Unlike add_image(), this method does not apply the live buffer-size
        limit. It is intended for offline replay where every causal image must
        remain available for the complete track-message timeline.

        Duplicate timestamps are resolved deterministically using the final
        supplied value for that timestamp. Invalid timestamps are discarded.
        """
        images_by_stamp: dict[int, Any] = {}

        for stamp_ns, image_bgr in images:
            stamp_ns = int(stamp_ns)
            if stamp_ns <= 0:
                continue

            images_by_stamp[stamp_ns] = image_bgr

        self._images = [
            AppearanceFrame(stamp_ns, images_by_stamp[stamp_ns])
            for stamp_ns in sorted(images_by_stamp)
        ]

    def select_causal_image(
        self,
        track_timestamp_ns: int,
    ) -> Optional[AppearanceFrame]:
        """Select the latest image whose timestamp is not after the tracks."""
        if not self._images:
            return None

        stamps = [frame.stamp_ns for frame in self._images]
        index = bisect_right(stamps, int(track_timestamp_ns)) - 1

        if index < 0:
            return None

        return self._images[index]

    def request_selection(self, track_id: int) -> None:
        """Request selection of a tracker ID when it next becomes visible."""
        track_id = int(track_id)

        if track_id <= 0:
            self.clear()
            return

        self.appearance_state.advance_selection_epoch(
            self.config.appearance.epoch_invalidation
        )
        if self.async_encoder is not None:
            self.async_encoder.cancel_all("operator_select")
        self.pending_select_id = track_id

    def clear(self) -> TargetMemoryOutput:
        """Clear target memory and pending selection state."""
        self.appearance_state.advance_selection_epoch(
            self.config.appearance.epoch_invalidation
        )
        if self.async_encoder is not None:
            self.async_encoder.cancel_all("operator_clear")
        self.pending_select_id = None
        return self.memory.clear()

    def candidate_from_track(
        self,
        track: Any,
        *,
        frame_id: int | None = None,
        timestamp_ns: int | None = None,
    ) -> CandidateTrack:
        """Convert one tracker observation with timeline provenance."""
        cx = float(track.cx)
        cy = float(track.cy)
        width = float(track.w)
        height = float(track.h)

        if self.config.tracks_are_normalized:
            cx *= self.config.image_width
            width *= self.config.image_width
            cy *= self.config.image_height
            height *= self.config.image_height

        unclipped_bbox = (
            cx - 0.5 * width,
            cy - 0.5 * height,
            cx + 0.5 * width,
            cy + 0.5 * height,
        )
        bbox = self.clip_bbox(unclipped_bbox)

        return CandidateTrack(
            track_id=int(track.id),
            bbox=bbox,
            score=float(track.score),
            tracker_frame_id=(
                int(frame_id)
                if frame_id is not None
                else None
            ),
            tracker_timestamp_ns=(
                int(timestamp_ns)
                if timestamp_ns is not None
                else None
            ),
            unclipped_bbox=unclipped_bbox,
        )

    def process_tracks(self, tracks_msg: Any) -> TimMarsRuntimeResult:
        """Process one tracker message using deterministic causal evidence."""
        track_frame_id = int(
            getattr(tracks_msg, "frame_id", 0)
        )

        track_timestamp_ns = self.track_time_ns(tracks_msg)
        candidates = [
            self.candidate_from_track(
                track,
                frame_id=track_frame_id,
                timestamp_ns=track_timestamp_ns,
            )
            for track in tracks_msg.tracks
        ]
        selected_image = (
            self.select_causal_image(track_timestamp_ns)
            if track_timestamp_ns is not None
            else None
        )

        appearance_request = (
            select_appearance_request_candidates(
                policy=self.config.appearance_request_policy,
                candidates=candidates,
                target_state=self.memory.state,
                reference_bbox=self.memory.bbox,
                current_track_id=self.memory.target_track_id,
                target_config=self.config.memory,
                pending_select_id=self.pending_select_id,
                auto_select_largest=(
                    self.config.auto_select_largest
                ),
                frames_since_seen=self.memory.frames_since_seen,
                reference_memory_available=(
                    self.memory.appearance_reference_available
                ),
            )
        )

        candidates, appearance_diagnostics = self._attach_appearance(
            candidates=candidates,
            track_timestamp_ns=track_timestamp_ns,
            selected_image=selected_image,
            frame_id=track_frame_id,
            appearance_request=appearance_request,
        )

        appearance_request_crops: tuple[
            AppearanceRequestCrop,
            ...,
        ] = ()

        if (
            self.config.appearance_async_request_crops_enabled
            and selected_image is not None
            and track_timestamp_ns is not None
            and track_frame_id > 0
            and self.appearance_state.frame_generation > 0
            and appearance_diagnostics.backend_calls > 0
        ):
            appearance_request_crops = (
                build_appearance_request_crops(
                    candidates=candidates,
                    requested_candidate_indices=(
                        appearance_request.requested_indices
                    ),
                    crop_quality_by_track_id=(
                        appearance_diagnostics
                        .crop_quality_by_track_id
                    ),
                    image_bgr=selected_image.image_bgr,
                    candidate_frame_width=(
                        self.config.image_width
                    ),
                    candidate_frame_height=(
                        self.config.image_height
                    ),
                    source_frame_id=track_frame_id,
                    track_timestamp_ns=(
                        track_timestamp_ns
                    ),
                    source_image_timestamp_ns=(
                        selected_image.stamp_ns
                    ),
                    source_image_seq=(
                        selected_image.stamp_ns
                    ),
                    frame_generation=(
                        self.appearance_state
                        .frame_generation
                    ),
                    track_generation_by_id=(
                        self.appearance_state
                        .track_generation_by_id
                    ),
                )
            )

        selected_candidate = None
        if self.pending_select_id is not None:
            selected_candidate = self.find_candidate(
                candidates,
                self.pending_select_id,
            )

        if selected_candidate is not None:
            output = self.memory.select(
                selected_candidate,
                frame_id=track_frame_id,
                timestamp_ns=track_timestamp_ns,
            )
            self.pending_select_id = None
        elif (
            self.pending_select_id is not None
            and self.memory.state == TargetState.NO_TARGET
        ):
            output = self.memory.update(
                [],
                frame_id=track_frame_id,
                timestamp_ns=track_timestamp_ns,
            )
            output.reason = (
                "pending_selection_track_not_visible:"
                f"{self.pending_select_id}"
            )
        elif (
            self.memory.state == TargetState.NO_TARGET
            and self.config.auto_select_largest
            and candidates
        ):
            largest = max(
                candidates,
                key=lambda candidate: self.bbox_area(candidate.bbox),
            )
            output = self.memory.select(
                largest,
                frame_id=track_frame_id,
                timestamp_ns=track_timestamp_ns,
            )
        else:
            output = self.memory.update(
                candidates,
                frame_id=track_frame_id,
                timestamp_ns=track_timestamp_ns,
            )

        selected_image_ns = (
            selected_image.stamp_ns
            if selected_image is not None
            else None
        )
        offset_ms = (
            float(track_timestamp_ns - selected_image_ns) / 1e6
            if (
                track_timestamp_ns is not None
                and selected_image_ns is not None
            )
            else None
        )

        self._enrich_positive_memory_bootstrap_event(
            output=output,
            candidates=candidates,
            frame_id=track_frame_id,
            track_timestamp_ns=track_timestamp_ns,
            selected_image_timestamp_ns=selected_image_ns,
            image_track_offset_ms=offset_ms,
        )

        diagnostics = TimMarsRuntimeDiagnostics(
            track_timestamp_ns=track_timestamp_ns,
            selected_image_timestamp_ns=selected_image_ns,
            image_track_offset_ms=offset_ms,
            appearance_candidates=appearance_diagnostics.candidates,
            appearance_request_policy=(
                appearance_request.policy.value
            ),
            appearance_request_reason=(
                appearance_request.reason
            ),
            appearance_request_candidates=len(
                appearance_request.requested_indices
            ),
            appearance_request_track_ids=tuple(
                appearance_request.requested_track_ids
            ),
            appearance_request_encoding_eligible=int(
                appearance_diagnostics
                .request_encoding_eligible
            ),
            appearance_features_valid=(
                appearance_diagnostics.features_valid
            ),
            appearance_skip_reason=appearance_diagnostics.skip_reason,
            appearance_warning=appearance_diagnostics.warning,
            appearance_cache_size=len(
                self.appearance_state.cache_by_track_id
            ),
            appearance_cache_lookups=int(
                appearance_diagnostics.cache_lookups
            ),
            appearance_cache_hits=int(
                appearance_diagnostics.cache_hits
            ),
            appearance_cache_misses=int(
                appearance_diagnostics.cache_misses
            ),
            appearance_cache_expired=int(
                appearance_diagnostics.cache_expired
            ),
            appearance_cache_invalidated=int(
                appearance_diagnostics.cache_invalidated
            ),
            appearance_embedding_age_ms_by_track_id=dict(
                appearance_diagnostics.embedding_age_ms_by_track_id
            ),
            appearance_crop_quality_by_track_id=dict(
                appearance_diagnostics.crop_quality_by_track_id
            ),
            appearance_encoding_rejected=int(
                appearance_diagnostics.encoding_rejected
            ),
            appearance_memory_update_ineligible=int(
                appearance_diagnostics.memory_update_ineligible
            ),
            appearance_encoding_eligible=int(
                appearance_diagnostics.encoding_eligible
            ),
            appearance_backend_calls=int(
                appearance_diagnostics.backend_calls
            ),
            appearance_backend_requested=int(
                appearance_diagnostics.backend_requested
            ),
            appearance_backend_returned=int(
                appearance_diagnostics.backend_returned
            ),
            appearance_backend_valid=int(
                appearance_diagnostics.backend_valid
            ),
            appearance_backend_wall_ms=float(
                appearance_diagnostics.backend_wall_ms
            ),
            appearance_update_cooldown_remaining=(
                self.memory.appearance_update_cooldown_frames_remaining
            ),
            candidate_track_ids=tuple(
                int(candidate.track_id)
                for candidate in candidates
            ),
        )

        return TimMarsRuntimeResult(
            output=output,
            candidates=tuple(candidates),
            diagnostics=diagnostics,
            appearance_request_crops=(
                appearance_request_crops
            ),
        )

    def _enrich_positive_memory_bootstrap_event(
        self,
        *,
        output: TargetMemoryOutput,
        candidates: Sequence[CandidateTrack],
        frame_id: int,
        track_timestamp_ns: Optional[int],
        selected_image_timestamp_ns: Optional[int],
        image_track_offset_ms: Optional[float],
    ) -> None:
        """Attach accepted-frame and embedding-source correspondence."""
        event = getattr(
            output,
            "positive_memory_bootstrap_event",
            None,
        )
        if event is None:
            return

        candidate = self.find_candidate(
            candidates,
            event.track_id,
        )
        provenance = (
            candidate.appearance_provenance
            if candidate is not None
            else None
        )

        resolved_frame_id = int(frame_id)
        output.positive_memory_bootstrap_event = replace(
            event,
            frame_id=(
                resolved_frame_id
                if resolved_frame_id > 0
                else None
            ),
            track_timestamp_ns=(
                int(track_timestamp_ns)
                if track_timestamp_ns is not None
                else None
            ),
            selected_image_timestamp_ns=(
                int(selected_image_timestamp_ns)
                if selected_image_timestamp_ns is not None
                else None
            ),
            image_track_offset_ms=(
                float(image_track_offset_ms)
                if image_track_offset_ms is not None
                else None
            ),
            appearance_source_frame_id=(
                provenance.source_frame_id
                if provenance is not None
                else None
            ),
            appearance_source_image_timestamp_ns=(
                provenance.source_image_timestamp_ns
                if provenance is not None
                else None
            ),
            appearance_embedded_ns=(
                provenance.embedded_ns
                if provenance is not None
                else None
            ),
            appearance_embedding_age_ms=(
                provenance.embedding_age_ms
                if provenance is not None
                else None
            ),
            appearance_frame_generation=(
                provenance.frame_generation
                if provenance is not None
                else None
            ),
            appearance_track_generation=(
                provenance.track_generation
                if provenance is not None
                else None
            ),
            appearance_source_bbox=(
                provenance.source_bbox
                if provenance is not None
                else None
            ),
            appearance_source_crop_quality=(
                provenance.source_crop_quality
                if provenance is not None
                else None
            ),
        )

    def _attach_appearance(
        self,
        *,
        candidates: list[CandidateTrack],
        track_timestamp_ns: Optional[int],
        selected_image: Optional[AppearanceFrame],
        frame_id: int,
        appearance_request: AppearanceRequestDecision,
    ):
        if track_timestamp_ns is None:
            reset_appearance_lifecycle(
                self.appearance_state
            )
            from thesis_bringup.tim_mars.appearance_attachment import (
                AppearanceAttachmentDiagnostics,
            )

            return (
                candidates,
                AppearanceAttachmentDiagnostics(
                    candidates=len(candidates),
                    features_valid=0,
                    image_age_ms=None,
                    skip_reason="invalid_track_timestamp",
                    cache_size=len(
                        self.appearance_state.cache_by_track_id
                    ),
                    embedding_age_ms_by_track_id={},
                    request_candidates=len(
                        appearance_request.requested_indices
                    ),
                    request_encoding_eligible=0,
                ),
            )

        asynchronous = self.async_encoder is not None
        bootstrap_indices: tuple[int, ...] = ()
        if asynchronous:
            self._async_deliver(candidates, track_timestamp_ns, frame_id)
            bootstrap_indices = self._async_bootstrap_indices(candidates)
        challenged_ids = self.memory.appearance_challenge_track_ids(candidates)
        if asynchronous:
            self._update_challenge_onset(challenged_ids, int(track_timestamp_ns))
        forced_indices = tuple(
            index for index, candidate in enumerate(candidates)
            if candidate.track_id in challenged_ids
        )
        result = attach_appearance_features(
            config=self.config.appearance,
            state=self.appearance_state,
            data=AppearanceAttachmentInput(
                candidates=candidates,
                now_ns=track_timestamp_ns,
                latest_image_bgr=(
                    selected_image.image_bgr
                    if selected_image is not None
                    else None
                ),
                latest_image_seen_ns=(
                    selected_image.stamp_ns
                    if selected_image is not None
                    else None
                ),
                latest_image_seq=(
                    selected_image.stamp_ns
                    if selected_image is not None
                    else -1
                ),
                mars_backend=(
                    None
                    if asynchronous and not bootstrap_indices
                    else self.mars_backend
                ),
                candidate_frame_width=self.config.image_width,
                candidate_frame_height=self.config.image_height,
                frame_id=frame_id,
                requested_candidate_indices=(
                    bootstrap_indices
                    if bootstrap_indices
                    else tuple(sorted(set(
                        appearance_request.requested_indices + forced_indices
                    )))
                ),
                forced_candidate_indices=forced_indices,
            ),
        )

        self.appearance_state = result.state
        if bootstrap_indices:
            self._async_count(
                "bootstrap_sync_crops",
                int(result.diagnostics.backend_requested),
            )
        if asynchronous:
            self._async_submit(
                result, candidates, selected_image, track_timestamp_ns,
                frame_id, appearance_request, forced_indices,
            )
        unavailable_image = result.diagnostics.skip_reason in {
            "cached_same_image", "stale_image", "no_image",
        }
        keep_existing_evidence = bool(
            self.config.memory.same_id_challenge_available_images_only
            and unavailable_image
        )
        if challenged_ids and not keep_existing_evidence:
            result.candidates = [
                replace(
                    candidate,
                    appearance=None,
                    appearance_memory_update_eligible=False,
                    appearance_challenge_failed=True,
                )
                if (
                    candidate.track_id in challenged_ids
                    and not self._post_onset_evidence_ok(candidate)
                    and not (
                        result.diagnostics.skip_reason in {
                            "ok", "fresh_identity_challenge",
                        }
                        and result.diagnostics.embedding_age_ms_by_track_id.get(
                            candidate.track_id
                        ) == 0.0
                    )
                ) else candidate
                for candidate in result.candidates
            ]
        return result.candidates, result.diagnostics

    def _async_bootstrap_indices(self, candidates) -> tuple[int, ...]:
        """Return the one candidate whose evidence must be fresh at selection.

        The protected anchor is created from the selected person at the moment
        of selection, so that single crop (about 33 ms) is encoded
        synchronously, bounded by the normal 250 ms interval, until a reference
        memory exists. Everything else stays asynchronous.
        """
        wanted = self.pending_select_id
        if wanted is None and not self.memory.appearance_reference_available:
            wanted = self.memory.target_track_id
        if wanted is None:
            return ()
        for index, candidate in enumerate(candidates):
            if int(candidate.track_id) == int(wanted):
                return (index,)
        return ()

    def _update_challenge_onset(self, challenged_ids, now_ns: int) -> None:
        """Track when each same-ID challenge arose, holding it across a brief gap.

        A failed challenge leaves LOCKED for a frame, during which the challenge
        is not raised again; the onset is kept for ``async_challenge_hold_ms`` so
        evidence computed after the original onset can still answer it.
        """
        hold_ns = int(self.async_challenge_hold_ms * 1e6)
        for challenged in challenged_ids:
            self._challenge_onset.setdefault(int(challenged), now_ns)
            self._challenge_last[int(challenged)] = now_ns
        for track_id in list(self._challenge_onset):
            if now_ns - self._challenge_last.get(track_id, now_ns) > hold_ns:
                del self._challenge_onset[track_id]
                self._challenge_last.pop(track_id, None)

    def _post_onset_evidence_ok(self, candidate) -> bool:
        """Return whether post-onset async evidence may answer a same-ID challenge."""
        if (
            self.async_encoder is None
            or self.async_challenge_mode != "post_onset"
            or candidate.appearance is None
        ):
            return False
        provenance = candidate.appearance_provenance
        onset = self._challenge_onset.get(int(candidate.track_id))
        ok = bool(
            provenance is not None
            and provenance.source_image_timestamp_ns is not None
            and onset is not None
            and int(provenance.source_image_timestamp_ns) >= int(onset)
            and float(provenance.embedding_age_ms)
            <= self.async_challenge_max_age_ms
        )
        self._async_count(
            "challenge_answered_post_onset" if ok else "challenge_unanswered"
        )
        return ok

    # ------------------------------------------------------------------
    # Asynchronous CPU MARS (development)
    def _async_count(self, key: str, n: int = 1) -> None:
        self.async_stats[key] = self.async_stats.get(key, 0) + n

    def _async_reject_reason(self, result, state, active, now_ns):
        """Return why a delivered result must not become evidence, or None."""
        job = result.job
        if job.source_image_timestamp_ns > now_ns:
            # Cannot happen by construction; asserted rather than assumed.
            return "future_evidence"
        if result.embedding is None:
            return "no_embedding"
        if job.selection_epoch != state.selection_epoch:
            return "stale_epoch"
        if job.frame_generation != state.frame_generation:
            return "stale_frame_generation"
        if job.track_id not in active:
            return "track_absent"
        if job.track_generation != state.track_generation_by_id.get(
            job.track_id, 0
        ):
            return "stale_track_generation"
        if now_ns - job.source_image_timestamp_ns > self.async_encoder.expiry_ns:
            return "expired"
        current = state.cache_by_track_id.get(job.track_id)
        if (
            isinstance(current, AppearanceCacheEntry)
            and current.source_image_timestamp_ns is not None
            and current.source_image_timestamp_ns
            >= job.source_image_timestamp_ns
        ):
            return "superseded_by_newer_observation"
        return None

    def _async_deliver(self, candidates, now_ns: int, frame_id: int) -> None:
        """Insert visible results into the cache, rejecting every late or stale one."""
        state = self.appearance_state
        reconcile_appearance_track_lifecycle(
            config=self.config.appearance,
            state=state,
            candidates=candidates,
            frame_id=frame_id,
            image_width=self.config.image_width,
            image_height=self.config.image_height,
        )
        active = {int(c.track_id) for c in candidates}
        for result in self.async_encoder.poll(int(now_ns)):
            job = result.job
            reason = self._async_reject_reason(result, state, active, now_ns)
            if reason is not None:
                self._async_count("rejected_" + reason)
                continue
            # Age is measured from capture, not from delivery.
            state.cache_by_track_id[job.track_id] = AppearanceCacheEntry(
                appearance=result.embedding,
                embedded_ns=int(job.source_image_timestamp_ns),
                source_frame_id=int(job.source_frame_id),
                frame_generation=int(job.frame_generation),
                track_generation=int(job.track_generation),
                source_bbox=job.source_bbox,
                crop_quality=job.crop_quality,
                source_image_timestamp_ns=int(job.source_image_timestamp_ns),
                selection_epoch=int(job.selection_epoch),
            )
            state.cache_seen_ns[job.track_id] = int(job.source_image_timestamp_ns)
            # Evidence from a crop that may not update memory is still usable
            # by decisions, as in the synchronous path; the cache lookup keeps
            # appearance_memory_update_eligible False for it.
            self._async_count(
                "delivered"
                if job.crop_quality.memory_update_eligible
                else "delivered_decision_only"
            )
            self.async_stats.setdefault("delivery_lag_ms", []).append(
                (int(now_ns) - int(job.source_image_timestamp_ns)) / 1e6
            )

    def _async_priority(self, candidate, index, selected_id, reference, forced):
        if int(candidate.track_id) == selected_id or index in forced:
            return 0
        if reference is None:
            return 1
        cx = (candidate.bbox[0] + candidate.bbox[2]) / 2
        cy = (candidate.bbox[1] + candidate.bbox[3]) / 2
        rx = (reference[0] + reference[2]) / 2
        ry = (reference[1] + reference[3]) / 2
        return 1 + int(((cx - rx) ** 2 + (cy - ry) ** 2) ** 0.5)

    def _async_submit(
        self,
        result,
        candidates,
        selected_image,
        now_ns,
        frame_id,
        request,
        forced_indices,
    ) -> None:
        """Queue this frame's crops without blocking the decision."""
        state = self.appearance_state
        qualities = result.diagnostics.crop_quality_by_track_id
        if selected_image is None or not qualities:
            return
        elapsed_ms = (now_ns - state.last_mars_compute_ns) / 1e6
        interval_ms = self.config.appearance.compute_min_interval_ms
        due = state.last_mars_compute_ns <= 0 or elapsed_ms >= interval_ms
        if state.last_mars_image_seq == selected_image.stamp_ns:
            return
        if not (due or forced_indices):
            return
        wanted = set(request.requested_indices) | set(forced_indices)
        reference = self.memory.bbox
        selected_id = self.memory.target_track_id
        height, width = selected_image.image_bgr.shape[:2]
        jobs = []
        for index in sorted(wanted):
            candidate = candidates[index]
            quality = qualities.get(int(candidate.track_id))
            if quality is None or not quality.encoding_eligible:
                continue
            box = map_bbox_to_appearance_image(
                (
                    candidate.unclipped_bbox
                    if candidate.unclipped_bbox is not None
                    else candidate.bbox
                ),
                candidate_frame_width=self.config.image_width,
                candidate_frame_height=self.config.image_height,
                image_width=int(width),
                image_height=int(height),
            )
            track_id = int(candidate.track_id)
            jobs.append(
                AsyncMarsJob(
                    job_id=self.async_encoder.new_job_id(),
                    source_frame_id=int(frame_id),
                    track_timestamp_ns=int(now_ns),
                    source_image_timestamp_ns=int(selected_image.stamp_ns),
                    frame_generation=int(state.frame_generation),
                    selection_epoch=int(state.selection_epoch),
                    track_id=track_id,
                    track_generation=int(
                        state.track_generation_by_id.get(track_id, 0)
                    ),
                    source_bbox=candidate.bbox,
                    mapped_box=box,
                    crop_quality=quality,
                    submit_ns=int(now_ns),
                    priority=self._async_priority(
                        candidate, index, selected_id, reference, forced_indices
                    ),
                    image_bgr=selected_image.image_bgr,
                )
            )
        if not jobs:
            return
        report = self.async_encoder.submit(jobs)
        self._async_count("submitted", report["accepted"])
        self._async_count("superseded", report["superseded"])
        self._async_count("overflow", report["overflow"])
        state.last_mars_compute_ns = int(now_ns)
        state.last_mars_image_seq = selected_image.stamp_ns

    def clip_bbox(self, bbox: BBox) -> BBox:
        """Clip a bbox to the configured candidate coordinate frame."""
        x1, y1, x2, y2 = bbox

        return (
            max(0.0, min(self.config.image_width, x1)),
            max(0.0, min(self.config.image_height, y1)),
            max(0.0, min(self.config.image_width, x2)),
            max(0.0, min(self.config.image_height, y2)),
        )

    @staticmethod
    def bbox_area(bbox: BBox) -> float:
        x1, y1, x2, y2 = bbox
        return max(0.0, x2 - x1) * max(0.0, y2 - y1)

    @staticmethod
    def find_candidate(
        candidates: Sequence[CandidateTrack],
        track_id: int,
    ) -> Optional[CandidateTrack]:
        for candidate in candidates:
            if int(candidate.track_id) == int(track_id):
                return candidate

        return None
