"""Pure CPU candidate-request policy for TIM-MARS appearance encoding.

This module decides which current tracker candidates should request an
appearance embedding. It is deliberately ROS-free and side-effect-free.

The policy may inspect public selected-target state and stateless geometry
scores. It must not mutate TargetIdentityMemory, candidate objects, appearance
cache state, or backend state.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Sequence

from thesis_bringup.tim_mars.appearance_policy import (
    geometry_allows_appearance,
)
from thesis_bringup.tim_mars.geometry_scoring import (
    bbox_area,
    score_candidate,
)
from thesis_bringup.tim_mars.types import (
    BBox,
    CandidateScore,
    CandidateTrack,
    TargetMemoryConfig,
    TargetState,
)


class AppearanceRequestPolicy(str, Enum):
    """Available pre-embedding candidate-selection policies."""

    ALL_CANDIDATES = "all_candidates"
    GEOMETRY_WINNER = "geometry_winner"
    AMBIGUITY_GUARDED = "ambiguity_guarded"
    DECISION_DEPENDENT = "decision_dependent"
    GATE_FIRST = "gate_first"


@dataclass(frozen=True)
class AppearanceRequestCandidateRank:
    """One geometry-only candidate rank produced without state mutation."""

    input_index: int
    track_id: int
    score: CandidateScore
    meets_minimum_score: bool
    geometry_plausible: bool


@dataclass(frozen=True)
class AppearanceRequestDecision:
    """Auditable result of one pure candidate-request decision."""

    policy: AppearanceRequestPolicy
    target_state: TargetState
    requested_indices: tuple[int, ...]
    requested_track_ids: tuple[int, ...]
    reason: str
    ranked_candidates: tuple[
        AppearanceRequestCandidateRank,
        ...,
    ] = ()


def _coerce_policy(
    policy: AppearanceRequestPolicy | str,
) -> AppearanceRequestPolicy:
    if isinstance(policy, AppearanceRequestPolicy):
        return policy

    try:
        return AppearanceRequestPolicy(str(policy))
    except ValueError as exc:
        supported = ", ".join(
            item.value
            for item in AppearanceRequestPolicy
        )
        raise ValueError(
            "unsupported appearance request policy "
            f"{policy!r}; expected one of: {supported}"
        ) from exc


def _validate_unique_track_ids(
    candidates: Sequence[CandidateTrack],
) -> None:
    seen: set[int] = set()
    duplicates: set[int] = set()

    for candidate in candidates:
        track_id = int(candidate.track_id)

        if track_id in seen:
            duplicates.add(track_id)

        seen.add(track_id)

    if duplicates:
        rendered = ", ".join(
            str(track_id)
            for track_id in sorted(duplicates)
        )
        raise ValueError(
            "appearance request policy requires unique "
            f"track IDs; duplicates: {rendered}"
        )


def _single_request(
    *,
    policy: AppearanceRequestPolicy,
    target_state: TargetState,
    index: int,
    candidate: CandidateTrack,
    reason: str,
    ranked_candidates: tuple[
        AppearanceRequestCandidateRank,
        ...,
    ] = (),
) -> AppearanceRequestDecision:
    return AppearanceRequestDecision(
        policy=policy,
        target_state=target_state,
        requested_indices=(int(index),),
        requested_track_ids=(int(candidate.track_id),),
        reason=str(reason),
        ranked_candidates=ranked_candidates,
    )


def _multi_request(
    *,
    policy: AppearanceRequestPolicy,
    target_state: TargetState,
    selected_ranks: tuple[
        AppearanceRequestCandidateRank,
        ...,
    ],
    ranked_candidates: tuple[
        AppearanceRequestCandidateRank,
        ...,
    ],
    reason: str,
) -> AppearanceRequestDecision:
    """Return a deterministic multi-candidate request decision."""
    return AppearanceRequestDecision(
        policy=policy,
        target_state=target_state,
        requested_indices=tuple(
            int(item.input_index)
            for item in selected_ranks
        ),
        requested_track_ids=tuple(
            int(item.track_id)
            for item in selected_ranks
        ),
        reason=reason,
        ranked_candidates=ranked_candidates,
    )


def _empty_request(
    *,
    policy: AppearanceRequestPolicy,
    target_state: TargetState,
    reason: str,
    ranked_candidates: tuple[
        AppearanceRequestCandidateRank,
        ...,
    ] = (),
) -> AppearanceRequestDecision:
    return AppearanceRequestDecision(
        policy=policy,
        target_state=target_state,
        requested_indices=(),
        requested_track_ids=(),
        reason=str(reason),
        ranked_candidates=ranked_candidates,
    )


def _decision_dependent_request(
    *,
    candidates: tuple[CandidateTrack, ...],
    target_state: TargetState,
    reference_bbox: BBox | None,
    current_track_id: int | None,
    target_config: TargetMemoryConfig,
    pending_select_id: int | None,
    frames_since_seen: int | None,
    reference_memory_available: bool,
) -> AppearanceRequestDecision:
    policy = AppearanceRequestPolicy.DECISION_DEPENDENT
    _validate_unique_track_ids(candidates)

    def everything(reason: str) -> AppearanceRequestDecision:
        return AppearanceRequestDecision(
            policy=policy,
            target_state=target_state,
            requested_indices=tuple(range(len(candidates))),
            requested_track_ids=tuple(int(c.track_id) for c in candidates),
            reason=reason,
        )

    if pending_select_id is not None and int(pending_select_id) > 0:
        return everything("decision_dependent_all:pending_operator_selection")
    if (
        target_state == TargetState.NO_TARGET
        or reference_bbox is None
        or current_track_id is None
    ):
        return everything("decision_dependent_all:no_selected_target")
    if not reference_memory_available:
        return everything("decision_dependent_all:no_reference_memory")
    if (
        target_state == TargetState.LOST
        and bool(target_config.global_reacquisition_enabled)
        and frames_since_seen is not None
        and int(frames_since_seen)
        >= max(1, int(target_config.global_reacquisition_after_missed_frames))
    ):
        return everything("decision_dependent_all:global_identity_recovery_ranks_every_candidate")

    requested: list[int] = []
    for index, candidate in enumerate(candidates):
        if int(candidate.track_id) == int(current_track_id):
            requested.append(index)
            continue
        score = score_candidate(
            reference_bbox, candidate, int(current_track_id), target_config,
        )
        meets_minimum = bool(
            float(score.geometry_score) >= float(target_config.min_candidate_score)
        )
        if meets_minimum and geometry_allows_appearance(score):
            requested.append(index)
    return AppearanceRequestDecision(
        policy=policy,
        target_state=target_state,
        requested_indices=tuple(requested),
        requested_track_ids=tuple(int(candidates[i].track_id) for i in requested),
        reason="decision_dependent_selective",
    )


def _gate_first_request(
    *,
    candidates: tuple[CandidateTrack, ...],
    target_state: TargetState,
    reference_bbox: BBox | None,
    current_track_id: int | None,
    target_config: TargetMemoryConfig,
    pending_select_id: int | None,
    frames_since_seen: int | None,
    reference_memory_available: bool,
) -> AppearanceRequestDecision:
    """Request only the gated candidates during prolonged-LOST recovery.

    Everywhere else every candidate is requested (unchanged). In prolonged
    LOST the recovery decision itself ranks only candidates inside the
    switch-proximity gate (``dev_gate_first_recovery``), so a candidate outside
    the gate cannot affect it by construction; a candidate that enters the
    gate later simply has no embedding until the next encode and is not
    accepted without appearance evidence (the safe direction).
    """
    policy = AppearanceRequestPolicy.GATE_FIRST
    _validate_unique_track_ids(candidates)

    def everything(reason: str) -> AppearanceRequestDecision:
        return AppearanceRequestDecision(
            policy=policy,
            target_state=target_state,
            requested_indices=tuple(range(len(candidates))),
            requested_track_ids=tuple(int(c.track_id) for c in candidates),
            reason=reason,
        )

    prolonged = bool(
        target_state == TargetState.LOST
        and target_config.global_reacquisition_enabled
        and target_config.dev_gate_first_recovery
        and target_config.dev_switch_proximity
        and reference_memory_available
        and reference_bbox is not None
        and current_track_id is not None
        and (pending_select_id is None or int(pending_select_id) <= 0)
        and frames_since_seen is not None
        and int(frames_since_seen)
        >= max(1, int(target_config.global_reacquisition_after_missed_frames))
    )
    if not prolonged:
        return everything("gate_first_all:not_prolonged_lost_recovery")

    height = max(1.0, float(reference_bbox[3]) - float(reference_bbox[1]))
    rx = (reference_bbox[0] + reference_bbox[2]) / 2.0
    ry = (reference_bbox[1] + reference_bbox[3]) / 2.0
    allowed = float(target_config.dev_switch_max_dist_heights) + float(
        target_config.dev_switch_dist_per_gap
    ) * int(frames_since_seen)
    requested = []
    for index, candidate in enumerate(candidates):
        if int(candidate.track_id) == int(current_track_id):
            requested.append(index)
            continue
        cx = (candidate.bbox[0] + candidate.bbox[2]) / 2.0
        cy = (candidate.bbox[1] + candidate.bbox[3]) / 2.0
        if (((cx - rx) ** 2 + (cy - ry) ** 2) ** 0.5) / height <= allowed:
            requested.append(index)
    return AppearanceRequestDecision(
        policy=policy,
        target_state=target_state,
        requested_indices=tuple(requested),
        requested_track_ids=tuple(int(candidates[i].track_id) for i in requested),
        reason="gate_first_gated",
    )


def select_appearance_request_candidates(
    *,
    policy: AppearanceRequestPolicy | str,
    candidates: Sequence[CandidateTrack],
    target_state: TargetState,
    reference_bbox: BBox | None,
    current_track_id: int | None,
    target_config: TargetMemoryConfig,
    pending_select_id: int | None = None,
    auto_select_largest: bool = False,
    frames_since_seen: int | None = None,
    reference_memory_available: bool = True,
) -> AppearanceRequestDecision:
    """Choose candidate indices that may request an embedding.

    ``decision_dependent`` (development, default off) requests exactly the
    embeddings the identity decision can consume, by traced dependency (see
    docs/algorithm/selective_mars_dependency_trace.md): every candidate whenever
    the decision ranks all candidates (no selected target or no reference
    memory yet, a pending operator selection, or prolonged-LOST global identity
    recovery, which scores every candidate and takes the second-best across all
    of them); otherwise the selected track plus candidates whose geometry
    admits appearance evidence (the same predicate that gates appearance use in
    candidate scoring), which also covers every nearby rival used by the
    local-ambiguity check.

    ``all_candidates`` preserves the existing pre-crop policy by forwarding
    every tracker candidate. Crop-quality filtering remains the attachment
    layer's responsibility.

    ``geometry_winner`` performs a stateless CPU geometry pass and requests at
    most one candidate:

    1. a visible pending operator selection has priority;
    2. before target initialisation, optional auto-selection uses bbox area;
    3. otherwise the highest geometry-only ranking score wins;
    4. candidates below the minimum score or outside the existing appearance
       geometry gate are not requested.

    Candidate ordering, objects, target memory, and configuration are never
    mutated.
    """
    resolved_policy = _coerce_policy(policy)
    candidate_tuple = tuple(candidates)
    resolved_state = TargetState(target_state)

    if not candidate_tuple:
        return _empty_request(
            policy=resolved_policy,
            target_state=resolved_state,
            reason="no_candidates",
        )

    if resolved_policy == AppearanceRequestPolicy.ALL_CANDIDATES:
        return AppearanceRequestDecision(
            policy=resolved_policy,
            target_state=resolved_state,
            requested_indices=tuple(
                range(len(candidate_tuple))
            ),
            requested_track_ids=tuple(
                int(candidate.track_id)
                for candidate in candidate_tuple
            ),
            reason="all_candidates",
        )

    if resolved_policy == AppearanceRequestPolicy.GATE_FIRST:
        return _gate_first_request(
            candidates=candidate_tuple,
            target_state=resolved_state,
            reference_bbox=reference_bbox,
            current_track_id=current_track_id,
            target_config=target_config,
            pending_select_id=pending_select_id,
            frames_since_seen=frames_since_seen,
            reference_memory_available=reference_memory_available,
        )

    if resolved_policy == AppearanceRequestPolicy.DECISION_DEPENDENT:
        return _decision_dependent_request(
            candidates=candidate_tuple,
            target_state=resolved_state,
            reference_bbox=reference_bbox,
            current_track_id=current_track_id,
            target_config=target_config,
            pending_select_id=pending_select_id,
            frames_since_seen=frames_since_seen,
            reference_memory_available=reference_memory_available,
        )

    # The unchanged all-candidate baseline forwards the tracker output
    # exactly as supplied. Experimental selective policies require unique
    # tracker IDs because their decision is keyed by identity.
    _validate_unique_track_ids(candidate_tuple)

    resolved_pending_id = (
        int(pending_select_id)
        if (
            pending_select_id is not None
            and int(pending_select_id) > 0
        )
        else None
    )

    if resolved_pending_id is not None:
        for index, candidate in enumerate(candidate_tuple):
            if int(candidate.track_id) == resolved_pending_id:
                return _single_request(
                    policy=resolved_policy,
                    target_state=resolved_state,
                    index=index,
                    candidate=candidate,
                    reason="pending_operator_selection",
                )

        return _empty_request(
            policy=resolved_policy,
            target_state=resolved_state,
            reason="pending_operator_selection_not_visible",
        )

    has_selected_reference = bool(
        resolved_state != TargetState.NO_TARGET
        and reference_bbox is not None
        and current_track_id is not None
    )

    if not has_selected_reference:
        if not auto_select_largest:
            return _empty_request(
                policy=resolved_policy,
                target_state=resolved_state,
                reason="no_selected_target",
            )

        winner_index, winner = max(
            enumerate(candidate_tuple),
            key=lambda item: (
                bbox_area(item[1].bbox),
                float(item[1].score),
                -int(item[0]),
            ),
        )

        return _single_request(
            policy=resolved_policy,
            target_state=resolved_state,
            index=winner_index,
            candidate=winner,
            reason="auto_select_largest",
        )

    assert reference_bbox is not None
    assert current_track_id is not None

    ranks: list[AppearanceRequestCandidateRank] = []

    for index, candidate in enumerate(candidate_tuple):
        score = score_candidate(
            reference_bbox,
            candidate,
            int(current_track_id),
            target_config,
        )
        meets_minimum = bool(
            float(score.geometry_score)
            >= float(target_config.min_candidate_score)
        )
        plausible = bool(
            meets_minimum
            and geometry_allows_appearance(score)
        )

        ranks.append(
            AppearanceRequestCandidateRank(
                input_index=int(index),
                track_id=int(candidate.track_id),
                score=score,
                meets_minimum_score=meets_minimum,
                geometry_plausible=plausible,
            )
        )

    ranked = tuple(
        sorted(
            ranks,
            key=lambda item: (
                -float(item.score.ranking_score),
                int(item.input_index),
            ),
        )
    )

    plausible = tuple(
        item
        for item in ranked
        if item.geometry_plausible
    )

    if not plausible:
        return _empty_request(
            policy=resolved_policy,
            target_state=resolved_state,
            reason="no_geometry_plausible_candidate",
            ranked_candidates=ranked,
        )

    if (
        resolved_policy
        == AppearanceRequestPolicy.AMBIGUITY_GUARDED
    ):
        winner_rank = plausible[0]
        current_is_geometry_winner = (
            int(winner_rank.track_id)
            == int(current_track_id)
        )

        clear_geometry_margin = (
            len(plausible) == 1
            or (
                float(
                    plausible[0]
                    .score
                    .ranking_score
                )
                - float(
                    plausible[1]
                    .score
                    .ranking_score
                )
                > float(
                    target_config.ambiguity_margin
                )
            )
        )

        if (
            resolved_state == TargetState.LOCKED
            and current_is_geometry_winner
            and clear_geometry_margin
        ):
            winner = candidate_tuple[
                winner_rank.input_index
            ]

            return _single_request(
                policy=resolved_policy,
                target_state=resolved_state,
                index=winner_rank.input_index,
                candidate=winner,
                reason=(
                    "ambiguity_guarded_stable_current"
                ),
                ranked_candidates=ranked,
            )

        return _multi_request(
            policy=resolved_policy,
            target_state=resolved_state,
            selected_ranks=plausible,
            ranked_candidates=ranked,
            reason="ambiguity_guarded_fallback",
        )

    winner_rank = plausible[0]
    winner = candidate_tuple[winner_rank.input_index]

    return _single_request(
        policy=resolved_policy,
        target_state=resolved_state,
        index=winner_rank.input_index,
        candidate=winner,
        reason="geometry_winner",
        ranked_candidates=ranked,
    )


__all__ = [
    "AppearanceRequestCandidateRank",
    "AppearanceRequestDecision",
    "AppearanceRequestPolicy",
    "select_appearance_request_candidates",
]
