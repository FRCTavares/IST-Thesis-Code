"""MARS ReID backend wrapper used by TIM-MARS.

This module wraps the DeepSORT MARS-small128 extractor so TIM-MARS can reuse the
same validated ReID embedding path as the tracker experiments. It stays small
and ROS-free.

The backend only encodes image crops. It does not cache embeddings, select
targets, update memory, or publish ROS messages.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import numpy as np

from thesis_bringup.tim_mars.target_memory import BBox
from thesis_tracker.backends.deepsort_core_backend import MarsSmall128Extractor


class MarsReIdBackend:
    """Thin wrapper around the DeepSORT MARS-small128 extractor."""

    def __init__(self, model_path: str | Path, batch_size: int = 32) -> None:
        self.model_path = str(model_path)
        self.batch_size = max(1, int(batch_size))
        # Development only, default off: same weights through ONNX Runtime.
        onnx_model = os.environ.get("TIM_MARS_ONNX_MODEL") or None
        self._extractor = MarsSmall128Extractor(
            self.model_path,
            batch_size=self.batch_size,
            onnx_model_path=onnx_model,
            onnx_threads=int(os.environ.get("TIM_MARS_ONNX_THREADS", "4")),
        )
        # Development only, default off: per-call encode trace (crop count and durations).
        self._extractor.trace_path = os.environ.get("TIM_MARS_ENCODE_TRACE") or None

    def encode(
        self,
        image_bgr: np.ndarray,
        boxes_xyxy: list[BBox],
    ) -> list[Optional[np.ndarray]]:
        """Return one L2-normalised 128D embedding per bbox, or None."""
        if image_bgr is None:
            return [None] * len(boxes_xyxy)

        if image_bgr.ndim != 3 or image_bgr.shape[2] != 3:
            return [None] * len(boxes_xyxy)

        return self._extractor.encode(image_bgr, boxes_xyxy)
