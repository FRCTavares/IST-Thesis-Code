"""Bounded asynchronous CPU-MARS encoder for TIM-MARS (development, default off).

The synchronous baseline encodes every requested crop inside the TIM callback, so
a crowded frame blocks the decision for hundreds of milliseconds (CPU MARS costs
about 33 ms per crop on the Pi). The asynchronous mode moves the encoding to one
bounded worker. A decision never waits for it: it uses the embeddings whose
results were delivered before the decision started, each carrying the frame it
was computed from, so a decision can only ever use evidence from its own or an
earlier frame, and the age of that evidence is explicit.

Rules enforced here (each has a test):

* every job carries source frame id, source-image and track timestamps, frame
  generation, track id and generation and the selection epoch it was created in;
* the queue is bounded (``capacity`` crops); a newer job for the same track
  supersedes an older queued one; overflow drops the lowest priority, oldest
  job; the selected track has priority;
* jobs expire (``expiry_ns`` after their source image) before starting, and
  results expire before delivery;
* ``cancel_all`` (select/clear, i.e. a new selection epoch) drops the queue at
  once and any result still in flight is rejected on delivery;
* a result is delivered exactly once.

Two execution modes share the same rules. ``virtual`` runs the encoder inline but
delivers each result at ``start + service_ns_per_crop`` on the track timeline,
which makes accuracy experiments deterministic and independent of host load (the
service time is the measured idle-Pi cost). ``thread`` runs a real worker thread
against ``clock_ns`` and is used in the live-path replay.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
import threading
import time
from typing import Any, Callable, Optional

import numpy as np


@dataclass(frozen=True)
class AsyncMarsJob:
    """One crop to embed, with complete causal provenance."""

    job_id: int
    source_frame_id: int
    track_timestamp_ns: int
    source_image_timestamp_ns: int
    frame_generation: int
    selection_epoch: int
    track_id: int
    track_generation: int
    source_bbox: tuple
    mapped_box: tuple
    crop_quality: Any
    submit_ns: int
    priority: int
    image_bgr: Any = field(repr=False, compare=False, default=None)


@dataclass(frozen=True)
class AsyncMarsResult:
    """One computed embedding and when it became available."""

    job: AsyncMarsJob
    embedding: Optional[np.ndarray]
    started_ns: int
    completed_ns: int


class AsyncMarsEncoder:
    """Single bounded worker with causal delivery."""

    def __init__(
        self,
        backend,
        *,
        capacity: int = 16,
        expiry_ns: int = 750_000_000,
        mode: str = "virtual",
        service_ns_per_crop: int = 33_400_000,
        clock_ns: Callable[[], int] = time.monotonic_ns,
    ) -> None:
        """Create the encoder; ``thread`` mode starts its worker immediately."""
        if mode not in ("virtual", "thread"):
            raise ValueError("mode must be virtual or thread")
        if int(capacity) <= 0 or int(expiry_ns) <= 0:
            raise ValueError("capacity and expiry must be positive")
        self.backend = backend
        self.capacity = int(capacity)
        self.expiry_ns = int(expiry_ns)
        self.mode = mode
        self.service_ns = int(service_ns_per_crop)
        self.clock_ns = clock_ns
        self._lock = threading.Lock()
        self._queue: list[AsyncMarsJob] = []
        # Computed results, delivered by poll() once they are visible.
        self._done: list[AsyncMarsResult] = []
        self._busy_until_ns = 0
        self._next_job_id = 1
        # Bumped by cancel_all: results of older generations are dropped.
        self._generation = 0
        self.counters: Counter = Counter()
        self.max_queue_depth = 0
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._wake = threading.Event()
        if mode == "thread":
            self._thread = threading.Thread(
                target=self._worker, name="async-mars", daemon=True
            )
            self._thread.start()

    def new_job_id(self) -> int:
        """Return a fresh job id."""
        with self._lock:
            job_id = self._next_job_id
            self._next_job_id += 1
            return job_id

    def submit(self, jobs: list[AsyncMarsJob]) -> dict:
        """Queue jobs; supersede older jobs of the same track; bound the queue."""
        report = {"accepted": 0, "superseded": 0, "overflow": 0}
        with self._lock:
            for job in sorted(jobs, key=lambda j: j.priority):
                kept = []
                for queued in self._queue:
                    if queued.track_id == job.track_id:
                        report["superseded"] += 1
                        self.counters["superseded"] += 1
                    else:
                        kept.append(queued)
                self._queue = kept
                self._queue.append(job)
                report["accepted"] += 1
                self.counters["submitted"] += 1
            while len(self._queue) > self.capacity:
                worst = max(
                    range(len(self._queue)),
                    key=lambda i: (
                        self._queue[i].priority,
                        -self._queue[i].submit_ns,
                    ),
                )
                self._queue.pop(worst)
                report["overflow"] += 1
                self.counters["dropped_overflow"] += 1
            self.max_queue_depth = max(self.max_queue_depth, len(self._queue))
        if self.mode == "thread":
            self._wake.set()
        return report

    def cancel_all(self, reason: str) -> int:
        """Drop all queued and computed work now; in-flight results are rejected."""
        with self._lock:
            dropped = len(self._queue)
            self._queue.clear()
            self._generation += 1
            discarded = len(self._done)
            self._done.clear()
            self.counters["cancelled_queued"] += dropped
            self.counters["cancelled_computed"] += discarded
            self.counters["cancel_events"] += 1
            self._busy_until_ns = 0
        return dropped + discarded

    def _encode(self, job: AsyncMarsJob) -> Optional[np.ndarray]:
        try:
            out = self.backend.encode(job.image_bgr, [job.mapped_box])
            return out[0] if out else None
        except Exception:
            # A failed crop is simply no evidence.
            self.counters["encode_error"] += 1
            return None

    def _advance_virtual(self, now_ns: int) -> None:
        """Run, on the track timeline, every job that has started by ``now_ns``."""
        while True:
            with self._lock:
                if not self._queue:
                    return
                self._queue.sort(key=lambda j: (j.priority, j.submit_ns))
                job = self._queue[0]
                start = max(self._busy_until_ns, job.submit_ns)
                if start > now_ns:
                    return
                self._queue.pop(0)
                generation = self._generation
                if start - job.source_image_timestamp_ns > self.expiry_ns:
                    self.counters["expired_before_start"] += 1
                    continue
            embedding = self._encode(job)
            completed = start + self.service_ns
            with self._lock:
                if generation != self._generation:
                    self.counters["cancelled_in_flight"] += 1
                    continue
                self._busy_until_ns = completed
                self._done.append(AsyncMarsResult(job, embedding, start, completed))
                self.counters["computed"] += 1

    def _worker(self) -> None:
        while not self._stop.is_set():
            self._wake.wait(timeout=0.05)
            self._wake.clear()
            while not self._stop.is_set():
                with self._lock:
                    if not self._queue:
                        break
                    self._queue.sort(key=lambda j: (j.priority, j.submit_ns))
                    job = self._queue.pop(0)
                    generation = self._generation
                started = int(self.clock_ns())
                if started - job.source_image_timestamp_ns > self.expiry_ns:
                    with self._lock:
                        self.counters["expired_before_start"] += 1
                    continue
                embedding = self._encode(job)
                completed = int(self.clock_ns())
                with self._lock:
                    if generation != self._generation:
                        self.counters["cancelled_in_flight"] += 1
                        continue
                    self._done.append(
                        AsyncMarsResult(job, embedding, started, completed)
                    )
                    self.counters["computed"] += 1

    def poll(self, now_ns: int) -> list[AsyncMarsResult]:
        """Return results visible to a decision starting at ``now_ns``, once each."""
        if self.mode == "virtual":
            self._advance_virtual(now_ns)
        else:
            # The decision starts now: everything completed so far is visible.
            now_ns = int(self.clock_ns())
        with self._lock:
            ready = [r for r in self._done if r.completed_ns <= now_ns]
            self._done = [r for r in self._done if r.completed_ns > now_ns]
        ready.sort(key=lambda r: r.completed_ns)
        return ready

    def diagnostics(self) -> dict:
        """Return queue depth and accounting counters."""
        with self._lock:
            return {
                "queued": len(self._queue),
                "computed_pending_delivery": len(self._done),
                "max_queue_depth": self.max_queue_depth,
                **dict(self.counters),
            }

    def close(self) -> None:
        """Stop the worker thread."""
        self._stop.set()
        self._wake.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
